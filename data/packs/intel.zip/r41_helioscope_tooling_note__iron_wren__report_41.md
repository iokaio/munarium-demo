# Helioscope Labs Tooling Note HL-2025-0818-41

- Vendor: Helioscope Labs
- Date: 2025-08-18
- TLP: AMBER
- Tracked actor: IRON WREN
- Campaign: Operation COPPERVEIL
- Report class: Tooling note

## Summary

This tooling note documents DUSKREACH, the loader Helioscope Labs recovered from multiple Operation COPPERVEIL victims and attributes to IRON WREN. DUSKREACH is the component that bridges IRON WREN's edge-appliance foothold and its second-stage implant: a compact, memory-resident loader engineered for stealth on hardened carrier hosts. Based on code characteristics, deployment context, and the absence of the loader in any other campaign we track, Helioscope Labs assesses that DUSKREACH is exclusive IRON WREN tooling. This note describes the loader's behavior, its evasion features, and detection opportunities.

## Findings

DUSKREACH is a small loader — under 40 kilobytes in the samples we recovered — written in a systems language and compiled per-target with a rotating configuration blob. Its role is narrow and deliberate: decrypt, map, and execute a second-stage payload entirely in memory, leaving minimal forensic residue on disk. Across the samples, DUSKREACH never wrote the decrypted second stage to the filesystem, relying instead on reflective mapping into a host process it selects from a short allowlist of signed system binaries. This design is why several victims detected no malware on disk despite active IRON WREN presence.

Execution begins with an environment-keying check. DUSKREACH derives a decryption key from host-specific attributes — appliance serial, primary interface hardware address, and a build-time salt — so a sample recovered from one victim will not detonate its payload in an analyst sandbox or on any other host. This anti-analysis binding frustrated our initial detonation attempts and required us to reconstruct the keying scheme from the loader logic before we could recover the second stage. Once keyed, DUSKREACH decrypts its configuration blob, which specifies the command-and-control endpoint, a retry schedule, and the target process for injection.

Network behavior is consistent with the COPPERVEIL infrastructure documented in our annex. DUSKREACH retrieves its second stage over TLS from the campaign's staging tier, and in recovered configurations the retrieval endpoint pointed to `hxxps://cdn-sync[.]example` with a fallback to `203.0.113[.]44`. The loader authenticates the server with a pinned certificate thumbprint embedded in the configuration, rejecting any endpoint that does not match — a self-protection measure that also, usefully, ties DUSKREACH samples to the certificate fingerprints in our infrastructure annex.

Persistence is not DUSKREACH's responsibility. The loader is deployed by IRON WREN's living-off-the-land toolkit after appliance compromise and is re-staged as needed rather than installed permanently, consistent with the actor's preference for out-of-band appliance persistence over host-based autoruns. We recovered DUSKREACH from three victims; in each, the loader was functionally identical but carried a distinct per-target configuration and keying salt, indicating a build pipeline that recompiles per operation.

Detection opportunities exist despite the loader's stealth. The reflective mapping into signed system binaries produces a recognizable memory anomaly — executable private memory in a process that has no legitimate reason to allocate it — that endpoint sensors can surface. The environment-keying routine also leaves a distinctive constant-folding pattern in the binary that we captured in a YARA rule accompanying this note. Finally, the pinned-thumbprint TLS retrieval to the staging tier gives network defenders a behavioral signature independent of specific domains.

## Assessment

Helioscope Labs assesses with high confidence that DUSKREACH is a purpose-built IRON WREN loader and a core component of Operation COPPERVEIL. The per-target compilation, environment-keyed payload binding, certificate-pinned retrieval from campaign staging infrastructure, and exclusive appearance within confirmed IRON WREN intrusions together support attribution and the judgment that DUSKREACH is exclusive IRON WREN tooling. We have not observed the loader shared with, sold to, or reused by any other actor.

Defenders should deploy the accompanying YARA and memory-anomaly detections, hunt for reflective execution in signed system binaries on carrier appliances and jump hosts, and correlate any DUSKREACH indicator with the infrastructure annex. Helioscope Labs will publish a follow-on analysis of the second-stage implant that DUSKREACH delivers.
