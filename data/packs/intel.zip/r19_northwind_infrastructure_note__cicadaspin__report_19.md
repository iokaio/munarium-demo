# Northwind CTI Infrastructure Note NW-IN-2025-47

- Vendor: Northwind CTI
- Date: 2025-10-22
- TLP: AMBER
- Tracked actor: CicadaSpin
- Campaign: SILKNOTE

## Summary

Northwind CTI is publishing corroborating infrastructure observations for
CicadaSpin activity within the SILKNOTE campaign. This note reinforces
findings from other vendors tracking the same actor and highlights a
persistent domain-naming convention that Northwind assesses as a durable
hunting signal. Consistent with Northwind practice, all indicators are
published in plain, fanged form.

## Findings

Northwind sensor telemetry through mid-October corroborates the continued
operation of CicadaSpin's logical command-and-control endpoint. We observed
implant traffic resolving to and returning from update-cdn.example, the same
rendezvous domain reported by partner vendors, confirming it remains in
active use despite repeated changes to its underlying hosting. The domain
most recently mapped to 203.0.113.41 in our passive-DNS collection before
rotating again, consistent with the fast hosting churn other vendors have
described. Northwind independently confirmed the phase-two staging server at
203.0.113.77 handling outbound archive transfers during two of our
investigations.

Beyond the individual addresses, Northwind's principal contribution this
period is characterizing CicadaSpin's domain-naming convention, which has
held remarkably stable across the campaign. The actor consistently registers
second-level domains that impersonate benign software-delivery and content-
distribution services — strings such as update, cdn, patch, mirror, and
telemetry, combined into plausible service hostnames on low-cost generic
TLDs. update-cdn.example is the archetype: a concatenation of a legitimate-
sounding update function with a content-delivery term, designed to survive a
casual analyst's glance and to blend with the constant background of genuine
CDN and auto-update traffic in an enterprise network.

Northwind catalogued additional domains sharing this construction and this
registrar footprint during the reporting window. They were registered in
small batches through privacy-protected registrars, used short-lived TLS
certificates from a common free certificate authority, and pointed at
reverse-proxy front ends that concealed their true origins — the same
operational pattern seen across CicadaSpin infrastructure. The naming
convention, the batch registration behavior, and the certificate issuance
pattern together form a registration fingerprint that Northwind is using to
surface new CicadaSpin domains before they appear in victim telemetry.

Northwind also notes that the actor reuses URI structure across front ends:
manifest-style GET paths for tasking and telemetry-style POST paths for
exfiltration, mirroring the application-layer behavior reported elsewhere.
This URI consistency, layered on top of the naming convention, gives
defenders two independent and durable pivots even as IP addresses and
certificates churn.

## Assessment

Northwind CTI assesses with high confidence that these observations
corroborate ongoing CicadaSpin operations under the SILKNOTE campaign and
that our findings align with those of other vendors tracking the same actor.
The most actionable takeaway is the stability of the domain-naming
convention: while CicadaSpin rotates IPs and certificates aggressively, its
choice of software-delivery-themed hostnames on cheap TLDs, registered in
batches through privacy services, has not changed. Northwind recommends
defenders build detection around this registration fingerprint and the
reused URI structure rather than chasing individual addresses, and treat
any newly observed lookalike software-update domain in this pattern as a
candidate CicadaSpin indicator pending confirmation. Northwind will share
newly surfaced candidate domains with trusted partners as they are
validated.
