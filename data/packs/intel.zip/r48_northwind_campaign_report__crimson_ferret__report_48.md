# Northwind CTI Campaign Report NW-2025-0701-48

- Vendor: Northwind CTI
- Date: 2025-07-01
- TLP: AMBER
- Tracked actor: CRIMSON FERRET
- Campaign: GRAYFROST intrusion set

## Summary

This campaign report consolidates Northwind CTI's understanding of the GRAYFROST
intrusion set following our June flash (NW-2025-0605-47) and four additional confirmed
victims. Northwind CTI attributes the GRAYFROST intrusion set to CRIMSON FERRET, a
financially motivated ransomware and extortion operation that has focused exclusively on
the manufacturing sector since it was first observed in spring 2025. The purpose of this
report is to describe the actor's extortion business model, document the maturing
tradecraft, and provide partners with an updated, plain-text indicator set for detection.

## Findings

Across nine confirmed intrusions, CRIMSON FERRET has followed a stable operational
playbook. Initial access is obtained through exposed remote-access appliances and valid
credentials harvested from commodity infostealer logs. Operators then escalate through
Active Directory, disable endpoint defenses using a signed vulnerable driver, and stage
victim data for exfiltration before any encryption occurs. Encryption is deployed last,
typically from a domain controller, maximizing the leverage of the stolen-data threat.

The extortion model is deliberate and consistent. CRIMSON FERRET runs a double-extortion
program: data is exfiltrated first, encryption follows, and the victim is presented with
a single combined demand covering both a decryptor and a promise to delete the stolen
archive. Victims are directed to a Tor-hosted negotiation portal and given a seven-day
window before sample data is posted to the public GRAYFROST leak site. Northwind CTI has
observed a staged pressure ladder: an initial private countdown, a public "unnamed
victim" teaser, then full victim naming with document samples. Demands are revenue-scaled
and, in the confirmed set, have ranged from roughly USD 400,000 to USD 3.4 million.
Operators have shown willingness to negotiate, with several cases settling well below the
opening figure, reinforcing that the objective is payment rather than disruption.

Updated indicators, published plain per Northwind CTI convention:

- Negotiation portal reference: https://grayfrost-support.example/victim
- Leak-site mirror: https://grayfrost-leaks.example/directory
- C2: 203.0.113.130 and 203.0.113.131 over HTTPS
- Exfiltration relay: 198.51.100.61
- Payload SHA-256: 7b2e5c19d0a4f83617cc90bb2e5f4a71d8c360912ea7b45f0d19c6a8e3f2107b
- Ransom-note filename: RESTORE-GRAYFROST-FILES.txt

## Assessment

Northwind CTI assesses with high confidence that CRIMSON FERRET is a financially
motivated criminal enterprise and that the GRAYFROST intrusion set is its primary
branded operation. The uniform leak-site infrastructure, negotiation template, and
demand-scaling behavior across unrelated victims indicate a single coordinated team
rather than loosely affiliated operators. The persistent focus on manufacturing is
almost certainly a payout-optimization choice: production downtime is expensive and
time-sensitive, which strengthens the operators' negotiating position.

Northwind CTI expects CRIMSON FERRET to continue refining its extortion program,
including faster public-naming timelines and possible introduction of denial-of-service
pressure as a third extortion lever. We reiterate that some tooling used in these
intrusions is commodity and shared with unrelated activity; attribution to CRIMSON
FERRET should rest on the composite of leak-site branding, negotiation tradecraft, and
victim-selection pattern rather than any single tool. A dedicated tooling note follows in
a later report. Manufacturing partners should enforce multi-factor authentication on all
external access, monitor for the indicators above, and rehearse an extortion-response
plan that accounts for the data-theft dimension, not just recovery from encryption.
