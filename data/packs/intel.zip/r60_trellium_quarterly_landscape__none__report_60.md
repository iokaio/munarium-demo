# Trellium H1 2025 Threat Landscape TR-LS-2025-H1

- Vendor: Trellium
- Date: 2025-07-01
- TLP: GREEN
- Tracked actor: (none — sector overview)
- Campaign: (none)

## Summary

Trellium's first-half 2025 landscape offers a strategic read on the threat
environment observed across Trellium's customer base between January and June
2025. This is an overview document: it names no single actor and carries no
indicators. Where Trellium references infrastructure conventions elsewhere, it
defangs; this report contains no technical indicators to defang. The audience is
strategic — security leadership and risk owners planning for the second half of
the year.

## Strategic Themes

The defining feature of H1 2025 was the industrialization of initial access.
Trellium observed a mature marketplace in which specialized operators harvested
and sold footholds — valid credentials, session cookies, and appliance
compromises — to a downstream population that carried out the eventual objective.
This division of labor compressed the time between exposure of a vulnerability and
its weaponization, and it decoupled the sophistication of the entry from the
sophistication of the actor who ultimately used it.

A parallel theme was the continued pressure on edge and remote-access
infrastructure. Internet-facing appliances, remote-access gateways, and file-
transfer utilities remained disproportionately represented in Trellium's
incident data. These systems sit at the perimeter, are difficult to patch on
short notice, and often lack the endpoint visibility deployed deeper in the
environment — a combination that made them the preferred entry point across
multiple unrelated intrusion clusters.

Trellium also noted a steady rise in the abuse of legitimate cloud and identity
services. Rather than deploying novel malware, many actors in H1 operated through
sanctioned administrative tooling, OAuth application consent, and cloud-native
automation, minimizing their footprint and complicating detection. This
living-off-the-cloud pattern mirrors the earlier living-off-the-land shift and
raises the bar for defenders whose telemetry is still endpoint-centric.

Finally, extortion economics continued to evolve. Trellium observed sustained
movement away from encryption-only models toward data-theft-led extortion, in
which the leverage is exposure rather than availability. This shift lowered the
technical barrier — no reliable encryptor is required — and broadened the set of
actors capable of monetizing an intrusion.

## Recommendations

Trellium recommends that organizations plan the second half of 2025 around three
priorities: reducing external attack surface with particular attention to edge and
remote-access appliances; extending detection into cloud and identity control
planes rather than relying on endpoint telemetry alone; and rehearsing
data-theft-led extortion in tabletop exercises, since availability-focused
playbooks do not cover exposure-based leverage.

This landscape publishes no indicators. Trellium's actor-tracking and
infrastructure reporting, which does carry defanged indicators, is available
separately to subscribers.
