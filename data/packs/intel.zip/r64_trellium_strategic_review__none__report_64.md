# Trellium Annual Strategic Threat Review TR-SR-2025

- Vendor: Trellium
- Date: 2026-01-12
- TLP: GREEN
- Tracked actor: (none — sector overview)
- Campaign: (none)

## Summary

Trellium's annual strategic review looks back across 2025 and forward into 2026,
synthesizing the year's dominant threat dynamics into a single leadership-oriented
narrative. It is a strategic document: it names no single actor and publishes no
indicators. Trellium defangs indicators in its technical reporting, but this review
contains none. The intended readers are executives, boards, and risk owners
setting security strategy and investment for the coming year.

## The Year in Review

If 2025 had a single organizing theme, it was the maturation of the intrusion
supply chain. The year confirmed that offensive capability has become modular and
tradeable: access is acquired from one specialist, tooling rented from another,
and monetization handled by a third. Trellium's incident data across the year
showed this division of labor compressing the interval between exposure and
exploitation and decoupling the sophistication of an attack from the identity of
its ultimate operator. Any strategy premised on profiling a fixed adversary aged
poorly against this reality.

The year also completed the transition of extortion leverage from availability to
exposure. Data-theft-led extortion, an emerging pattern at the start of 2025,
was the default model by year's end. The strategic implication is significant:
resilience investments centered on backup and recovery, while still necessary, no
longer address the primary threat, because the leverage is publication, not
downtime.

Identity remained the decisive terrain throughout. The most consequential
intrusions of 2025 turned on the abuse of legitimate credentials, session tokens,
and application consent rather than on novel malware. Correspondingly, the
organizations that fared best were those that had moved their control center of
gravity from the network perimeter to the identity layer and had extended
detection into cloud and identity control planes.

## Outlook for 2026

Trellium expects the supply-chain model to deepen further, keeping the barrier to
capable intrusion low and making behavioral, actor-agnostic defense more valuable
than adversary-specific tracking. Data-theft-led extortion will remain the
dominant monetization model, and Trellium anticipates continued professionalization
of pressure operations around it. Edge and identity will remain the two contested
frontiers: exposed appliances as the entry point of choice, and identity as the
control plane attackers most want to subvert.

## Recommendations

Trellium recommends that 2026 strategy prioritize three durable investments:
identity as the primary control plane, with phishing-resistant authentication and
session-theft detection; external attack-surface management with disciplined edge-
appliance maintenance; and incident-response planning that treats data exposure,
not just availability loss, as the central extortion scenario. Because the threat
environment rewards behavioral defense over adversary profiling, detection
programs should continue shifting investment toward behavior- and identity-centric
telemetry.

This review publishes no indicators. Trellium's actor and infrastructure
reporting, which carries defanged technical indicators, is available separately to
subscribers.
