# Helioscope Labs Reconciliation Note HL-2026-0110-36

- Vendor: Helioscope Labs
- Date: 2026-01-10
- TLP: AMBER
- Tracked actor: AMBER LANTERN
- Campaign: Operation TIDEGLASS

## Summary

This note addresses the divergence in community assessments of Operation
TIDEGLASS following a peer vendor's revision of its motivation judgment to
financially motivated. Helioscope Labs has reviewed the newly published
evidence against our own dataset. We acknowledge the competing assessment and
explain our reasoning here, but on balance we maintain our state-nexus
AMBER LANTERN attribution for Operation TIDEGLASS. Indicators in this note are
defanged.

## Findings

We take the peer reporting seriously. The recovered extortion correspondence,
the cryptocurrency wallet-tracking note, and the ransom-negotiation chat
fragment described by that vendor are genuine artifacts, and we do not dispute
their authenticity. Considered on their own, they are consistent with a
financially motivated operation, and we have re-examined our own TIDEGLASS
engagements specifically for comparable monetization evidence.

Our review did not change our conclusion. Across the intrusions in Helioscope's
dataset, the TIDECLASP implant's module set remains exclusively collection- and
access-oriented, with no ransomware, wiper, or extortion functionality; the
tasking we observed consistently prioritized settlement, correspondent-bank,
and clearing-integration intelligence over data most useful for extortion
leverage; and the durable infrastructure, including `cloud-sync[.]example` and
the staging server at `203.0.113[.]88`, reflects an investment in long-term
access rather than fast monetization. We assess it is plausible that the
recovered monetization artifacts represent a secondary financial activity, an
attempt at misdirection, or the behavior of a subset of operators, none of
which would overturn a primary state collection mandate. We hold this view with
moderate confidence and regard the question as legitimately contested.

## Assessment

Helioscope Labs acknowledges the competing motivation assessment and the
evidence behind it, and we welcome the continued community exchange. On the
weight of our own evidence — the collection-only TIDECLASP toolset, the
intelligence-oriented tasking profile, the durable infrastructure investment,
and the code lineage tying the implant to prior AMBER LANTERN operations — we
maintain that Operation TIDEGLASS is best explained as state-directed
espionage, and we retain our AMBER LANTERN attribution. We are not retracting or
softening that attribution on the basis of the currently available
monetization artifacts.

We recognize that reasonable analysts weighing the same evidence differently may
reach a financial-motivation conclusion, and we will revisit our assessment if
further evidence — for example, monetization functionality embedded in the
implant itself, or a consistent pattern of extortion across the victim set —
comes to light. In the interim we emphasize that the two hypotheses are not
mutually exclusive: a state-nexus operation may tolerate or incorporate
opportunistic monetization by its operators without ceasing to serve a
collection mandate, and defenders lose nothing by maintaining a posture that
addresses both. For that reason we align on the same mitigations recommended
across the community, and we regard the motivation debate as a matter for
analysts rather than a fork in the required defensive response. Helioscope Labs
will continue to track AMBER LANTERN and Operation TIDEGLASS and to publish
updates as our understanding develops, and we thank our peers for the
constructive exchange of evidence that made this reconciliation possible.
