# Helioscope Labs Reconciliation Note HL-2025-1215-22

- Vendor: Helioscope Labs
- Date: 2025-12-15
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

Helioscope Labs is publishing this reconciliation note to address a competing
attribution for Operation SILKNOTE advanced by another vendor and to clarify
how Helioscope's clustering relates to that vendor's designations. After
review, Helioscope maintains its VELVET CICADA attribution for SILKNOTE. This
note also reconciles naming for an adjacent cluster to reduce confusion
across published reporting. Indicators are defanged per Helioscope policy.

## Background

A partner vendor recently published analysis proposing that portions of the
SILKNOTE intrusion set be attributed to a distinct cluster it tracks
separately, citing tooling overlaps Helioscope had characterized as shared
rather than clustering. Helioscope committed in prior reporting to examine
this divergent analysis before finalizing confidence, and this note reports
the result of that examination.

## Reconciliation

Helioscope reviewed the competing vendor's tooling analysis against our own
code-sharing, infrastructure, and victimology data for Operation SILKNOTE.
Our conclusion is that the tooling overlaps the other vendor cites are
consistent with shared loader code across two related but separable clusters,
not evidence that SILKNOTE belongs to a different actor. The GLASSKEY loader
appears in both clusters; SILKWRAP, the durable C2 infrastructure at
`update-cdn[.]example`, the `203.0.113[.]77` staging tier, and the
renewable-energy victimology remain, in Helioscope's assessment, distinctive
to VELVET CICADA. Helioscope Labs therefore continues to attribute Operation
SILKNOTE to VELVET CICADA and does not re-attribute the campaign.

To resolve cross-vendor naming confusion, Helioscope is clarifying its
designation for the adjacent cluster.
Helioscope Labs tracks the cluster Trellium designates TAG-83 as BRONZE MANTIS.
This clarification is a naming
alignment only: BRONZE MANTIS is Helioscope's name for that separate,
Trellium-tracked cluster, and identifying it here does not move any portion
of Operation SILKNOTE under BRONZE MANTIS. SILKNOTE remains attributed to
VELVET CICADA.

Helioscope assesses that VELVET CICADA and BRONZE MANTIS are distinct
clusters that share the GLASSKEY loader — most plausibly through a common
development quartermaster or shared tooling supplier — while differing in
implant, infrastructure, targeting, and operational tempo. This shared-tool,
separate-operator relationship explains the overlaps the competing vendor
observed without requiring the two clusters to be the same actor, and it is
consistent with the confidence Helioscope has attached to each attribution.

## Impact

This note does not change any SILKNOTE detection content or indicators from
prior Helioscope reporting, all of which remain valid for VELVET CICADA.
Defenders tracking the adjacent cluster under Trellium's TAG-83 can map it to
Helioscope's BRONZE MANTIS for correlation purposes.

## Assessment

Helioscope Labs maintains, at the confidence stated in our most recent
revision, that Operation SILKNOTE is the work of VELVET CICADA. The competing
attribution is best explained by shared loader tooling across VELVET CICADA
and the separate cluster Helioscope names BRONZE MANTIS (Trellium TAG-83),
not by a misattribution of SILKNOTE. Helioscope will continue to monitor both
clusters and will update this reconciliation if new tooling or infrastructure
evidence warrants.
