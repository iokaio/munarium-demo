# Trellium Strategic Assessment TR-2025-12-05-45

- Vendor: Trellium
- Date: 2025-12-05
- TLP: AMBER
- Tracked actor: TAG-58
- Campaign: COPPERVEIL intrusion set
- Report class: Strategic assessment

## Summary

This strategic assessment presents Trellium's judgment on the intent and sponsorship of TAG-58, the intrusion set behind the COPPERVEIL activity targeting telecommunications operators. Where our prior reporting documented victimology and infrastructure, this assessment addresses the harder question of who is behind TAG-58 and why. On the strength of the campaign's targeting logic, tradecraft, operational tempo, and collection focus, Trellium assesses that TAG-58 is a state-sponsored actor conducting telecom collection tasking on behalf of a national intelligence service. We present the reasoning, our confidence levels, and the intelligence gaps that temper higher-order attribution.

## Findings

The single strongest indicator of intent is TAG-58's collection focus. Across the confirmed victim population, the actor consistently reached the systems that matter for communications intelligence: subscriber-provisioning databases that map identities to numbers and devices, lawful-intercept mediation platforms that broker targeted collection, and, at transit providers, the routing and peering configuration that governs how traffic flows between networks. This is not the target set of a financially motivated actor. There is no ransomware, no cryptomining, no fraud staging, and no data-extortion posture anywhere in the confirmed intrusions. The exclusive interest in communications-metadata and intercept infrastructure is the signature of intelligence collection.

Tradecraft reinforces the assessment. TAG-58 exhibits sustained operational discipline — memory-resident tooling, environment-keyed payloads, selective log pruning, credential rotation, and lateral movement timed to victim business hours — that requires patient, well-resourced operators rather than opportunistic criminals. The actor invests in staying quiet and dwelling long, which is rational only for a mission that values persistent access over immediate monetary return. Compartmentalized, purpose-registered infrastructure with anonymous billing further indicates a professional operation.

Target selection shows strategic logic consistent with state tasking. TAG-58 repeatedly chose aggregation points — a managed-services firm administering OSS/BSS for multiple downstream carriers, a satellite backhaul operator — that maximize collection breadth per intrusion. An actor that deliberately targets choke points in the telecommunications supply chain is optimizing for coverage of communications across a region, which aligns with a national intelligence requirement rather than any commercial objective.

Operational tempo supports a sustained program. The campaign has run steadily since at least March 2025, adding victims roughly monthly without the burst-and-vanish pattern of contractors chasing a fixed deliverable. This endurance implies stable funding and standing tasking. Finally, the campaign's geographic clustering is consistent with a defined collection remit rather than indiscriminate targeting.

Intelligence gaps remain. Trellium has not recovered evidence that directly ties TAG-58 to a named state sponsor — no operator-attributable artifacts, language or timezone leakage sufficient for confident geolocation, or infrastructure overlap with previously attributed state clusters. Our sponsorship judgment therefore rests on capability, intent, and targeting logic rather than direct attribution evidence, and we hold it at moderate confidence.

## Assessment

Trellium assesses with high confidence that TAG-58 is conducting an intelligence-collection mission against the telecommunications sector, and with moderate confidence that TAG-58 is state-sponsored and operating under national telecom collection tasking. The exclusive focus on provisioning, lawful-intercept, and routing systems; the disciplined, long-dwell tradecraft; the deliberate targeting of supply-chain aggregation points; and the sustained monthly tempo collectively point to a professional, state-aligned collection program rather than criminal activity. We stop short of naming a specific sponsor pending direct attribution evidence.

For defenders, the strategic takeaway is that TAG-58 will persist and adapt, because its mission is standing rather than transactional. Telecom operators should treat provisioning and lawful-intercept platforms as crown-jewel assets, instrument them accordingly, and assume that documented infrastructure will be replaced. Trellium will continue tracking the COPPERVEIL intrusion set and will update this assessment if attribution evidence emerges.
