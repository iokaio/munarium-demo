# Northwind CTI Actor Profile NW-2025-0918-29

- Vendor: Northwind CTI
- Date: 2025-09-18
- TLP: AMBER
- Tracked actor: LanternGlow
- Campaign: TIDEGLASS

## Summary

Northwind CTI is publishing a consolidated actor profile for the threat group
we track as LanternGlow, whose activity we associate with the TIDEGLASS
campaign against the financial-services sector. This profile synthesizes our
telemetry, incident-response findings, and infrastructure analysis from spring
through late summer 2025. Northwind CTI publishes indicators in plain,
non-defanged form; consumers should apply their own handling controls.

## Findings

LanternGlow is a capable, tightly scoped intrusion actor focused on
financial-services and fintech organizations, particularly those involved in
payment settlement, cross-border transfers, and digital lending. The group's
signature initial-access technique is spearphishing using vendor-onboarding and
regulatory-compliance lures that direct recipients to credential-harvesting
pages mirroring the victim's own identity provider. The phishing kit performs
real-time authentication proxying to capture session tokens and defeat one-time
passcodes, a hallmark that distinguishes LanternGlow operations from generic
credential theft.

Post-access, LanternGlow deploys a modular implant consistent with the
TIDECLASP family, persisting through a scheduled task that impersonates a
software-update service and communicating over HTTPS. The group's tasking is
selective: operators pursue reconciliation records, counterparty and
correspondent-bank data, and settlement metadata rather than bulk collection,
and they reliably remove staging artifacts on exit.

Infrastructure analysis is central to this profile. LanternGlow maintains a
durable command-and-control identity in the C2 domain `cloud-sync.example`,
which fronts the group's implant tasking channel. Across our observation window
`cloud-sync.example` rotated across hosting providers while preserving a stable
check-in cadence over `https://`, with implants beaconing to it exclusively
after retrieval from a separate staging tier. We assess `cloud-sync.example` to
be an actor-controlled, long-lived node rather than a compromised third party,
based on its provisioning history and dedicated use.

LanternGlow operator activity clusters into a consistent daily window, and the
group has repeatedly re-entered remediated environments within hours of
credential resets, indicating strong persistence discipline. Victimology is
uniform across the financial-services sector, with several victims sharing a
common managed-file-transfer supplier that we assess is being abused as a
lateral-movement trust bridge.

## Assessment

Northwind CTI assesses with high confidence that LanternGlow is a distinct,
well-resourced actor conducting a sustained collection campaign against the
financial-services sector under the TIDEGLASS banner. The combination of
selective financial-intelligence tasking, the absence of any monetization or
extortion behavior in our data, disciplined persistence, and durable
infrastructure such as `cloud-sync.example` is most consistent with a
state-nexus collection mandate. We assess a state nexus with moderate-to-high
confidence.

Financial-services defenders should block and alert on `cloud-sync.example`,
enforce phishing-resistant multi-factor authentication that resists real-time
proxying, and audit OAuth grants, mailbox rules, and managed-file-transfer
trust paths. Northwind CTI will continue to profile LanternGlow and will
publish infrastructure and landscape follow-ups as our visibility develops.
