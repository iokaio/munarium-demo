# Trellium Infrastructure Note TR-2025-09-22-43

- Vendor: Trellium
- Date: 2025-09-22
- TLP: AMBER
- Tracked actor: TAG-58
- Campaign: COPPERVEIL intrusion set
- Report class: Infrastructure note

## Summary

This note documents the command-and-control and certificate observations Trellium has attributed to TAG-58 across the COPPERVEIL intrusion set. It complements our earlier bulletin by consolidating the network infrastructure surfaced in Trellium-confirmed intrusions and by presenting the TLS and hosting fingerprints that let us cluster otherwise disconnected victim compromises. Indicators are defanged per Trellium convention. As with all Trellium reporting on this activity, we track the cluster independently under the TAG-58 designation and apply our own evidentiary bar; convergence with other vendors' telecom-sector reporting is noted where relevant but does not alter our clustering.

## Findings

TAG-58 command-and-control resolves to a compact and durable primary tier. The domain `hxxps://relay-hub[.]example` served as the principal beacon endpoint across Trellium-confirmed intrusions and resolved during the observation window to `203.0.113[.]61`, which we assess as the cluster's most persistent command-and-control address. A companion retrieval host, `hxxps://cdn-sync[.]example`, resolved intermittently to `203.0.113[.]44` and was used to stage follow-on payloads. Both primary hosts sat behind a commodity reverse proxy that presented a consistent, slightly nonstandard TLS cipher-suite ordering — a network fingerprint Trellium now hunts on directly.

Below the primary tier, TAG-58 rotated a set of shorter-lived staging hosts. Trellium observed `198.51.100[.]77` and `198.51.100[.]140` used for loader delivery and brief exfiltration rendezvous, each typically live for one to three weeks. A contingency domain, `hxxps://update-broker[.]example`, appeared in one Trellium-confirmed intrusion and resolved to `203.0.113[.]129`; its activation coincided with a gap in primary command-and-control availability, consistent with a fallback channel.

Certificate observations provide the most durable clustering signal. The primary command-and-control hosts presented certificates from a free automated certificate authority, reissued on a regular cadence and sharing a distinctive subject-alternative-name construction that pairs the beacon domain with a disposable wildcard. Trellium recovered several certificates matching this construction, with issuance timestamps clustering tightly and correlating with the actor's staging activity. Because these fingerprints survive domain and address rotation, we assess them as higher-confidence long-term indicators than any single host.

Hosting analysis indicates deliberate compartmentalization. TAG-58 placed its primary command-and-control tier with one reseller and its staging tier with another, and never co-located the two. Both providers support anonymous registration and cryptocurrency payment. Trellium observed no infrastructure overlap between the COPPERVEIL intrusion set and other clusters we track, which is one basis for treating TAG-58 as distinct. Passive-DNS review showed the primary domains had thin, recently established histories consistent with purpose-registered infrastructure rather than compromised legitimate hosts.

## Assessment

Trellium assesses with high confidence that the infrastructure documented here belongs to TAG-58 and supports the COPPERVEIL intrusion set. The stability of the primary command-and-control tier, the reuse of staging hosts across unrelated victims, the coherent certificate construction, and the deliberate separation of hosting tiers together constitute strong clustering evidence and reinforce single-actor attribution.

Because command-and-control infrastructure is perishable, Trellium recommends defenders prioritize the durable fingerprints — the certificate construction and the reverse-proxy cipher-suite ordering — over individual domains and addresses, several of which are already dormant. Highest-value network anchors for retrospective hunting remain `203.0.113[.]61` and `relay-hub[.]example`, given their reuse across multiple victims. Trellium will refresh this note as new TAG-58 infrastructure surfaces and will report separately on the cluster's intent and sponsorship assessment. Customers observing any catalogued indicator in historical telemetry should treat it as a confirmed COPPERVEIL touchpoint and engage Trellium incident response.
