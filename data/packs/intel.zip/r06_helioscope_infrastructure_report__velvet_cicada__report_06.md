# Helioscope Labs Infrastructure Report HL-2025-0923-06

- Vendor: Helioscope Labs
- Date: 2025-09-23
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

This report documents the Operation SILKNOTE phase-two staging layer and the
loader observed delivering SILKWRAP since August 2025. Indicators are
defanged per Helioscope publication policy.

## Findings

Exfiltration archives from three September victims were staged to a
phase-two staging server at 203.0.113[.]77 before onward transfer. The
server presents as a generic object-storage gateway and rotates its TLS
certificate weekly.

Since August, SILKWRAP deployments have been preceded by a lightweight
loader Helioscope Labs designates GLASSKEY. GLASSKEY performs environment
checks, disables endpoint telemetry sampling, and retrieves SILKWRAP from
the staging layer.

## Assessment

GLASSKEY is exclusive VELVET CICADA tooling: the loader has appeared only in
VELVET CICADA intrusions, and its build timestamps cluster in the actor's
established working hours. Its presence on a host should be treated as a
high-confidence indicator of Operation SILKNOTE activity.
