# Northwind CTI Infrastructure Note NW-IN-2025-44

- Vendor: Northwind CTI
- Date: 2025-09-30
- TLP: AMBER
- Tracked actor: CicadaSpin
- Campaign: SILKNOTE

## Summary

Northwind CTI has identified the phase-two staging infrastructure used by
CicadaSpin in the SILKNOTE campaign during September 2025. Indicators are
published in plain form.

## Findings

Exfiltration archives observed by Northwind sensors were staged to a
phase-two staging server at 198.51.100.24 prior to onward transfer to
actor-controlled storage. The server was reachable over HTTPS on port 443
and presented a certificate reused across two unrelated Northwind
investigations, suggesting shared hosting infrastructure.

Northwind observed the staging host receive archives from two SILKNOTE
victims over a nine-day window before going dark. The onward-transfer
destination could not be recovered from available telemetry.

## Assessment

Northwind CTI assesses the staging host is part of CicadaSpin's phase-two
collection pipeline. Because the actor rotates staging infrastructure
frequently, Northwind recommends alerting on the staging behavior — bulk
HTTPS uploads to freshly registered object-storage gateways — rather than on
the address alone.
