# Northwind CTI Report NW-2025-1212-54

- Vendor: Northwind CTI
- Date: 2025-12-12
- TLP: AMBER
- Tracked actor: CRIMSON FERRET
- Campaign: GRAYFROST set

## Summary

This report analyzes the ransom notes and negotiation-chat transcripts recovered from
CRIMSON FERRET's GRAYFROST intrusions, offering a close read of how the actor communicates,
prices, and pressures victims. Northwind CTI reviewed ransom notes from sixteen confirmed
victims and full or partial negotiation transcripts from seven of them. The analysis
reveals a scripted, businesslike operation with standardized note templates, a predictable
pressure ladder, and negotiators who behave like a customer-facing extortion desk. All
indicators are published plain per Northwind CTI convention.

## Findings

The ransom note is remarkably consistent across victims. Every note dropped as
RESTORE-GRAYFROST-FILES.txt in affected directories, opened by naming the GRAYFROST leak
site, and instructed the victim to authenticate to a Tor-hosted negotiation portal within
seven days. Notes carried a per-victim identifier and a warning that stolen data would be
published on the leak site if the victim failed to engage. The template language changed
only cosmetically across the tracking window, indicating a stable, reused artifact.

Plain indicators associated with the note-and-negotiation analysis:

- Ransom-note filename: RESTORE-GRAYFROST-FILES.txt
- Negotiation portal: https://grayfrost-support.example/victim
- Leak-site directory: https://grayfrost-leaks.example/directory
- Active C2 at time of encryption: 203.0.113.180 over HTTPS
- Exfiltration relay: 198.51.100.120
- Payload SHA-256: b7d2f4190ec5a83641cc90bb2e5f4a71d8c360912ea7b45f0d19c6a8e3f2107d

The negotiation transcripts show a disciplined, scripted desk. CRIMSON FERRET negotiators
open with the full demand, cite the specific stolen data types to establish credibility,
and offer a proof-of-decryption on one or two sample files. When victims stall,
negotiators advance a fixed pressure ladder: a private deadline reminder, a threat to
publish an "unnamed victim" teaser, then a threat of full public naming with document
samples. In five of seven transcripts, the operators granted a discount for prompt
payment, typically 20 to 35 percent off the opening figure, consistent with a revenue
target rather than a fixed price. Negotiators maintained a calm, transactional tone,
avoided ideological or personal language, and referenced deletion of the stolen archive as
part of the settlement.

Notably, the transcripts reinforce Northwind CTI's tooling guidance: negotiators never
referenced the DUSKREACH loader or any specific intrusion tool, and the branding in the
notes and chats was exclusively GRAYFROST leak-site language. This is consistent with
DUSKREACH being commodity tooling separate from the actor's customer-facing identity;
attribution to CRIMSON FERRET continues to rest on the GRAYFROST branding and negotiation
tradecraft, not on any shared tool.

## Assessment

Northwind CTI assesses with high confidence that CRIMSON FERRET operates a professionalized
extortion desk with standardized notes, a scripted negotiation playbook, and a revenue-target
pricing model. The consistency of the RESTORE-GRAYFROST-FILES.txt template, the fixed
pressure ladder, and the discount-for-speed behavior across unrelated victims indicates
trained negotiators following internal procedures rather than improvisation.

We expect CRIMSON FERRET to maintain this negotiation model and possibly to add
third-party-pressure tactics, such as contacting a victim's customers or partners, to
accelerate payment. Victim organizations should assume that engaging the negotiation portal
starts a scripted, deadline-driven process and should decide their negotiation and payment
posture in advance, with counsel and incident-response support, rather than under live
pressure. Northwind CTI will continue collecting and analyzing GRAYFROST notes and
transcripts and will update this analysis as the actor's negotiation tradecraft evolves.
