# Trellium Infrastructure Note TRB-2025-0930-61I

- Vendor: Trellium
- Date: 2025-09-30
- TLP: AMBER
- Tracked actor: TAG-61
- Campaign: GRAYFROST intrusion set

## Summary

This infrastructure note documents Trellium's tracking of the network and leak-site
infrastructure supporting the GRAYFROST intrusion set, which Trellium attributes to
TAG-61. Since our July bulletin (TRB-2025-0725-61), Trellium has mapped rotating
command-and-control hosts, a small set of exfiltration relays, and the actor's public
leak-site presence. All indicators below are defanged per Trellium convention. Trellium
assesses that TAG-61 maintains a deliberately compartmented infrastructure with short-lived
C2 hosts and a more durable leak-site backbone.

## Findings

Trellium observed TAG-61 rotate command-and-control endpoints roughly every two to three
weeks, favoring hosting providers that tolerate abuse complaints slowly. The exfiltration
relays are longer-lived, likely because re-provisioning bulk-transfer infrastructure is
more operationally costly than spinning up a new beacon host. The leak site itself has
remained stable across the tracking window, with the actor rotating only its front-end
mirror domains while preserving the underlying victim directory.

Defanged infrastructure indicators:

- C2 (retired): 203.0.113[.]140, 203.0.113[.]141
- C2 (active): 203.0.113[.]155 over hxxps port 443
- Exfiltration relay: 198.51.100[.]88 and 198.51.100[.]89
- Leak-site primary: hxxps://grayfrost-leaks[.]example/directory
- Leak-site mirror: hxxps://grayfrost-mirror[.]test/dir
- Victim negotiation portal: hxxps://grayfrost-support[.]example/victim
- TLS certificate common name reused across C2: grayfrost-ops[.]example

Trellium correlated three active C2 hosts through a reused self-signed TLS certificate
whose common name matched the exfiltration staging domain observed in earlier TAG-61
intrusions. This certificate reuse is currently Trellium's strongest infrastructure-level
pivot for discovering new TAG-61 hosts before they appear in victim telemetry. Trellium
also observed that the leak site publishes a structured victim index with countdown
timers, sector tags, and partial document samples — a presentation consistent with a
mature extortion operation optimizing pressure on non-paying victims.

On the leak site, Trellium counted eleven named manufacturing victims across the tracking
window, with two additional entries listed as "pending disclosure." Sector tags on the
site were dominated by industrial equipment, automotive components, and specialty
chemicals. Trellium did not observe any non-manufacturing victims on the TAG-61 leak site,
reinforcing the sector-focus assessment from prior reporting. Loader infrastructure tied
to the commodity DUSKREACH family was visible in the intrusions but was hosted separately
from the TAG-61 leak-site backbone, consistent with DUSKREACH being shared tooling rather
than actor-owned infrastructure.

## Assessment

Trellium assesses with moderate confidence that TAG-61 operates a two-tier
infrastructure: disposable C2 hosts for intrusion operations and a durable, branded
leak-site backbone for extortion. The certificate-reuse pattern suggests a small operating
team recycling configuration artifacts across hosts, which gives defenders a reliable
hunting pivot. Trellium expects TAG-61 to continue rotating C2 on a two-to-three-week
cadence while preserving the leak-site directory.

Defenders should monitor for the defanged indicators above after re-fanging, prioritize
the reused-certificate common name as a discovery pivot, and treat DUSKREACH-related hosts
as a separate, commodity concern rather than as core TAG-61 infrastructure. Trellium will
publish an updated assessment as the leak-site victim count grows and as new C2 hosts are
correlated through the certificate pivot.
