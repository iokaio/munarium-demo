# Trellium Intelligence Bulletin TR-2025-28

- Vendor: Trellium
- Date: 2025-07-20
- TLP: AMBER
- Tracked actor: TAG-77
- Campaign: SILKNOTE intrusion set

## Summary

Trellium is issuing an expanded victimology bulletin for the SILKNOTE
intrusion set, which we track as TAG-77. Since our initial July reporting we
have confirmed additional intrusions and refined our understanding of the
sectors and geographies TAG-77 prioritizes. This bulletin consolidates
confirmed victim data and characterizes the intrusion pattern. Network
indicators are defanged per Trellium policy.

## Confirmed intrusions

Trellium now attributes four confirmed intrusions to TAG-77 with high
confidence, each independently corroborated through host forensics and
overlapping infrastructure. All four victims operate in the renewable-energy
sector:

1. A mid-sized onshore wind operator in Western Europe, where TAG-77 gained
   initial access via a spearphish carrying the GLASSKEY loader and
   maintained access for an estimated eleven weeks before eviction.
2. A solar-farm engineering-procurement-construction firm in Southern
   Europe, compromised through a contractor's remote-access account.
3. A regional grid-balancing services provider whose SCADA-adjacent business
   network — not the control network — was the target of collection.
4. A battery-storage integrator supporting utility-scale projects, where
   Trellium recovered a SILKWRAP implant beaconing to
   `update-cdn[.]example`.

In every confirmed case the actor's objective was collection: engineering
documents, grid-interconnection filings, project schedules, and internal
correspondence. Trellium observed no destructive activity and no evidence of
operational-technology manipulation. The consistent focus on business-side
intellectual property and project intelligence, rather than disruption,
frames TAG-77 as an espionage set.

## Victimology and targeting

The confirmed victims share a profile: organizations positioned at the
engineering, integration, and grid-services layer of the renewable-energy
supply chain rather than end-consumer utilities. Trellium assesses TAG-77 is
targeting the design and interconnection knowledge concentrated in these
firms — data with clear value to a state seeking to accelerate domestic
renewable-energy programs or to understand foreign grid modernization.

Geographically the confirmed set clusters in Western and Southern Europe,
though shared-indicator data suggests suspected activity extending to at
least two organizations in other regions that Trellium has not yet been able
to confirm. Initial access alternated between targeted spearphishing of
named engineers and compromise of trusted third parties — contractors and
subcontractors with legitimate remote access into the victim environment.
This supply-chain-adjacent access pattern recurred in three of four cases and
is, in Trellium's assessment, a defining characteristic of the set.

Tradecraft across the intrusions was consistent: GLASSKEY for initial
loading, SILKWRAP for persistence and collection, credential harvesting for
lateral movement, and staged exfiltration through rotating cloud
infrastructure. The uniformity of tooling across otherwise unrelated victims
is a primary basis for Trellium's clustering of these events under TAG-77.

## Assessment

Trellium assesses with high confidence that TAG-77 is a state-sponsored
espionage actor conducting a sustained campaign against the renewable-energy
sector, with an emphasis on engineering and grid-integration organizations in
Europe. The confirmed intrusions show disciplined, collection-focused
tradecraft and a repeatable reliance on trusted-third-party access. Trellium
expects the confirmed victim count to grow as suspected intrusions are
corroborated, and will publish infrastructure and tooling addenda as the
investigation matures. Defenders in this sector should scrutinize contractor
remote-access paths and hunt for the GLASSKEY and SILKWRAP tradecraft
described in prior Trellium reporting.
