# ES-CERT Advisory ESCERT-2026-0108-46

- Issuer: ES-CERT
- Date: 2026-01-08
- TLP: CLEAR
- Tracked actor: IRON WREN
- Campaign: Operation COPPERVEIL
- Report class: Sector advisory

## Summary

ES-CERT is issuing this TLP:CLEAR advisory to help telecommunications operators defend against Operation COPPERVEIL, an espionage campaign targeting the sector's carrier infrastructure. The campaign is attributed by commercial reporting to the actor referenced here as IRON WREN. ES-CERT has reviewed vendor reporting and constituent incident data and consolidates the practical, actionable mitigations below. Because this advisory is CLEAR and intended for wide distribution, indicators are published in plain form and the guidance is written for operational teams. ES-CERT does not make an independent sponsorship attribution and refers readers to commercial reporting for actor analysis.

## Findings

Operation COPPERVEIL follows a consistent pattern that defenders can plan against. IRON WREN gains initial access by exploiting internet-facing network appliances — VPN concentrators, secure-access gateways, and load-balancer management planes — typically using unpatched, known vulnerabilities. After foothold, the actor creates covert appliance-local accounts, establishes persistence that survives firmware updates, and moves laterally with native administrative tools to avoid detection. The campaign's objective is access to carrier provisioning databases and lawful-intercept mediation platforms.

The actor stages a memory-resident loader and second-stage backdoor that avoid writing to disk, which limits the value of traditional file-based scanning. Command-and-control uses TLS to a small, durable set of hosts. ES-CERT is republishing the highest-value network indicators from vendor reporting in plain form for operator convenience: the primary command-and-control domain `relay-hub.example`, resolving to `203.0.113.61`; a second-stage retrieval host `cdn-sync.example` at `203.0.113.44`; and staging addresses `198.51.100.23`, `198.51.100.77`, and `198.51.100.140`. Operators should note that the campaign's command channel uses ordinary-looking `https://` traffic, so block-listing and TLS-fingerprint hunting are more effective than protocol anomaly detection alone.

## Assessment

ES-CERT assesses that telecommunications operators face a credible and ongoing threat from Operation COPPERVEIL and that the intrusion pattern is well enough understood to defend against with disciplined execution of standard controls. The following mitigations are prioritized for constituent action.

First, patch and harden internet-facing appliances. Apply vendor security updates promptly, disable unused management interfaces, and restrict appliance administration to dedicated management networks rather than the public internet. Given IRON WREN's reliance on edge-appliance exploitation, this is the single highest-impact control.

Second, audit appliance-local accounts. Inventory every local account on VPN concentrators and gateways, remove any not tied to a named administrator, and enable centralized logging of account creation and configuration changes so covert accounts surface quickly. Verify that firmware updates do not silently preserve attacker-created accounts.

Third, protect crown-jewel systems. Treat subscriber-provisioning databases and lawful-intercept mediation platforms as the highest-sensitivity assets. Enforce multi-factor authentication and least-privilege access to them, and alert on anomalous or bulk queries.

Fourth, hunt behaviorally for the memory-resident implant. Because Operation COPPERVEIL tooling avoids disk, deploy endpoint detection that can identify reflective execution and private executable memory in signed system processes, and hunt for TLS beaconing to the indicators listed above at `https://relay-hub.example` and `203.0.113.61`.

Fifth, preserve evidence and report. Operators identifying any listed indicator or the described tradecraft should preserve appliance forensic images before remediation, as these are the most valuable artifacts for confirming IRON WREN activity, and should report incidents to ES-CERT so the community picture stays current.

ES-CERT will update this advisory as the threat evolves. Constituents seeking deeper technical detail on IRON WREN tooling and infrastructure should consult the commercial vendor reporting on Operation COPPERVEIL referenced by ES-CERT. Questions and incident reports may be directed to the ES-CERT duty desk through the usual constituent channels.
