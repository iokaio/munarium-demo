# Helioscope Labs Deep-Dive Report HL-2025-0811-05

- Vendor: Helioscope Labs
- Date: 2025-08-11
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

This deep-dive consolidates four months of Operation SILKNOTE incident
response engagements and malware analysis. It introduces the campaign's
primary implant, which Helioscope Labs designates SILKWRAP.

## Victimology

Helioscope Labs has identified 14 victim organizations in Operation SILKNOTE
to date, spanning utility-scale solar operators, wind-farm services firms,
and two grid-software vendors. All victims fit the energy-transition
collection profile described in our May campaign report.

## Malware

SILKWRAP is a modular second-stage implant deployed after credential
harvesting. The analyzed SILKWRAP sample has SHA-256
A47C9E02B5D1F6883E2A90C4D7B15F3A6C8E0D92417B5A3F9E6C10D84B27A5E1.
For initial code execution on patched hosts, SILKWRAP exploits
CVE-2025-31337 in a widely deployed document-preview service. The implant
loads its collection modules reflectively and encrypts staging archives with
a per-victim key.

## Assessment

Helioscope Labs attributes Operation SILKNOTE to VELVET CICADA with high
confidence. Our attribution confidence for the campaign is high, based on
implant code sharing with 2024 VELVET CICADA samples, infrastructure
registration overlap, and consistent victimology.
