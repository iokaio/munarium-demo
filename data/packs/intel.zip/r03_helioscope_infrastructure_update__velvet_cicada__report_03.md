# Helioscope Labs Infrastructure Update HL-2025-0618-03

- Vendor: Helioscope Labs
- Date: 2025-06-18
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

Operation SILKNOTE infrastructure rotated in early June 2025. This update
documents the current command-and-control layer. Indicators below are
defanged per Helioscope publication policy.

## Findings

Second-stage payloads retrieve tasking from update-cdn[.]example over HTTPS.
The full tasking endpoint observed in network telemetry is
hxxps://update-cdn[.]example/api/v2/sync, with beacon intervals of 45 to 90
minutes and jitter consistent with earlier VELVET CICADA infrastructure.

The domain was registered through a privacy-proxied registrar account eleven
days before first observed use, matching the registration-to-use window we
documented for the campaign's April infrastructure.

## Assessment

The rotation preserved the operators' preference for content-delivery-themed
domain names. Defenders should treat update-cdn[.]example as the campaign's
active command-and-control domain and hunt retrospectively for DNS
resolutions beginning 2025-06-05.
