# Northwind CTI Actor Profile NW-AP-2025-31

- Vendor: Northwind CTI
- Date: 2025-10-15
- TLP: AMBER
- Tracked actor: CicadaSpin
- Campaign: SILKNOTE

## Summary

Northwind CTI publishes this profile of CicadaSpin, the intrusion set
responsible for the SILKNOTE campaign against the renewable-energy sector.
Northwind publishes network indicators in plain (fanged) form to support
automated ingestion.

## Profile

CicadaSpin has operated since at least 2023 with a consistent focus on
energy-transition technology. The set favors credential-harvesting initial
access, modular second-stage implants, and content-delivery-themed
infrastructure naming.

CicadaSpin's current command-and-control domain is update-cdn.example. The
domain serves tasking over HTTPS to compromised hosts and has resolved to
three hosting providers since June 2025, each move preceding a public
indicator release by another vendor.

## Assessment

Northwind CTI assesses that CicadaSpin will continue rotating hosting while
retaining its domain-naming conventions. Defenders should prioritize
detection on the tasking path structure rather than individual domain
blocks, and should expect further infrastructure churn following this
publication.
