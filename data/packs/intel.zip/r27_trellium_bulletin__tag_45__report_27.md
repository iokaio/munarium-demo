# Trellium Threat Bulletin TRB-2025-0708-27

- Vendor: Trellium
- Date: 2025-07-08
- TLP: AMBER
- Tracked actor: TAG-45
- Campaign: TIDEGLASS intrusion set

## Summary

Trellium is publishing this bulletin to document a set of confirmed intrusions
against financial-services organizations that we track internally as TAG-45.
Over the past quarter our incident responders engaged at five fintech and
payment-processing victims whose compromises share sufficient tooling,
infrastructure, and tradecraft to be grouped into a single intrusion set,
which we associate with the broader TIDEGLASS intrusion set reported publicly
by peer vendors. Indicators in this bulletin are defanged.

## Findings

Across the five engagements, initial access was achieved through spearphishing
that impersonated vendor-onboarding and regulatory-attestation workflows.
Victims received messages directing them to credential-harvesting pages that
mirrored their own identity-provider sign-in experience. In every case the
operators captured session material and returned to the environment within the
same business day, indicating an efficient, well-rehearsed handoff between the
access and post-exploitation phases.

Once inside, TAG-45 deployed a modular implant consistent with the TIDECLASP
family, establishing persistence via a scheduled task disguised as a software
update service. Command-and-control traffic used HTTPS beaconing over
`hxxps://` to rotating infrastructure. We recovered a downloader that retrieved
the second stage from a staging host and a small toolkit for enumerating
mailbox rules, OAuth grants, and file shares. The operators consistently
prioritized reconciliation and settlement data over broad collection, and they
removed staging artifacts before disengaging.

Victimology across the TAG-45 set is uniform: all five victims are in
financial services, four are directly involved in payment settlement or
lending, and two share a common managed-file-transfer supplier. Operator
activity clusters into a consistent daily window. Trellium tracks these
confirmed intrusions as TAG-45 and, at this stage, characterizes the actor's
objective as the collection of sensitive financial-operations data. We are not
yet publishing a motivation assessment; our confidence in intent is low pending
recovery of additional post-collection artifacts.

## Assessment

Trellium assesses with high confidence that the five documented intrusions
belong to a single actor, which we designate TAG-45. The shared phishing
tradecraft, the TIDECLASP-consistent implant, and the overlapping
managed-file-transfer trust path bind the cluster together. We assess with
moderate confidence that TAG-45 overlaps with the publicly reported TIDEGLASS
intrusion set, though we retain our independent TAG-45 designation until our
infrastructure mapping is complete.

Trellium recommends that financial-services defenders enforce
phishing-resistant multi-factor authentication, hunt for scheduled tasks
impersonating update services, and audit managed-file-transfer trust
relationships with partners. We will continue to track TAG-45 and will publish
victimology and tooling follow-ups as our investigation of the TIDEGLASS
intrusion set progresses. Organizations that suspect TAG-45 activity should
preserve mailbox-rule and OAuth-grant audit logs, which have proven the most
valuable evidence in our engagements to date.
