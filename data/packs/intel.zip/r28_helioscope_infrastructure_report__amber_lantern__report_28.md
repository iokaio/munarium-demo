# Helioscope Labs Infrastructure Report HL-2025-0802-28

- Vendor: Helioscope Labs
- Date: 2025-08-02
- TLP: AMBER
- Tracked actor: AMBER LANTERN
- Campaign: Operation TIDEGLASS

## Summary

This infrastructure report documents the command-and-control and staging
network Helioscope Labs has mapped for Operation TIDEGLASS as of late July
2025. Sustained collaboration with three victims and passive-DNS correlation
have let us pivot from initial landing pages to the actor's second-stage
delivery tier. All indicators in this report are defanged; defenders should
re-fang before deploying to blocking controls.

## Findings

The TIDEGLASS network is organized in tiers. The outermost tier comprises the
short-lived credential-harvesting landing pages described in our earlier
reporting. Behind these sits a delivery and staging tier that we have now
characterized in detail. We identified a phase-two staging server at
`203.0.113[.]88` that hosts the second-stage TIDECLASP payload and serves it to
the first-stage downloader after a successful credential capture. The host
responded on 443 with a self-signed certificate whose subject reused a string
also seen on earlier AMBER LANTERN infrastructure, and it was reachable only
after the downloader presented a campaign-specific URI path, indicating access
gating designed to frustrate sandbox retrieval.

Beaconing from deployed implants resolves to the command-and-control domain
`cloud-sync[.]example`, which fronts the operators' tasking channel. During the
observation window `cloud-sync[.]example` rotated across several hosting
providers while preserving a stable request pattern: periodic HTTPS POSTs over
`hxxps://` with a fixed User-Agent and a small, consistent body size for
check-ins. We assess that `203.0.113[.]88` and `cloud-sync[.]example` are
operated by the same actor, based on temporally correlated provisioning,
shared TLS-certificate reuse, and the fact that implants retrieved from the
staging server beacon exclusively to the command-and-control domain.

The staging server at `203.0.113[.]88` was periodically taken offline between
campaigns and re-provisioned on the same address block, and the operators
appear to treat `cloud-sync[.]example` as their durable C2 identity across
those cycles. We have not observed the staging server hosting any content
unrelated to TIDEGLASS.

## Assessment

Helioscope Labs assesses with high confidence that the phase-two staging server
at `203.0.113[.]88` and the command-and-control domain `cloud-sync[.]example`
are core, actor-controlled elements of Operation TIDEGLASS, and we associate
both with AMBER LANTERN. The certificate-string reuse tying `203.0.113[.]88` to
prior AMBER LANTERN infrastructure is the strongest single pivot in our current
dataset. The disciplined tiering, access gating, and durable C2 identity are
consistent with the state-directed collection posture described in our campaign
report.

Defenders should block and alert on `203.0.113[.]88` and `cloud-sync[.]example`
after re-fanging, hunt historically for HTTPS beacons matching the fixed
User-Agent and body-size pattern, and review egress logs for the staging-server
URI path. Because the staging server is periodically re-provisioned on the same
address block while the C2 domain persists, we recommend that defenders treat
`cloud-sync[.]example` as the higher-value durable indicator and monitor its
resolution history for new hosting providers, while retaining `203.0.113[.]88`
as a point-in-time staging indicator whose absence does not imply the campaign
has ceased. Correlating a short single-session retrieval from the staging tier
with the onset of periodic beaconing to the C2 domain remains the most reliable
behavioral signature for hunting TIDEGLASS in historical telemetry. Helioscope
Labs will continue mapping the TIDEGLASS network and will fold any newly
discovered nodes into subsequent reporting.
