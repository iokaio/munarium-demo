# Helioscope Labs Campaign Report HL-2025-0506-02

- Vendor: Helioscope Labs
- Date: 2025-05-06
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

This report consolidates Helioscope Labs' visibility into Operation SILKNOTE
through the end of April 2025. Intrusion tempo has increased since our flash
report, with new victims identified in the renewable-energy sector each week
of April.

## Findings

Post-compromise activity centers on the collection of interconnection
agreements, turbine telemetry exports, and capacity-planning documents. The
operators show consistent working hours and re-enter victim environments
within hours of credential resets, indicating an established persistence
mechanism we are still characterizing.

Observed targeting is concentrated in renewable-energy generation and
grid-services operators. We have not observed collection against corporate
financial systems in any SILKNOTE intrusion to date.

## Assessment

Helioscope Labs attributes Operation SILKNOTE to VELVET CICADA. The
tasking profile, victimology, and tradecraft are consistent with a
state-directed collection requirement against energy-transition
infrastructure, and we assess the actor is operating on behalf of a state
sponsor.

A detailed TTP annex (HL-SILKNOTE-TTP) will be published as a follow-up to
this report, covering the full intrusion chain with mapped techniques.
