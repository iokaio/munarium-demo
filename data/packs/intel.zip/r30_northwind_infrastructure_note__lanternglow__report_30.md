# Northwind CTI Infrastructure Note NW-2025-1005-30

- Vendor: Northwind CTI
- Date: 2025-10-05
- TLP: AMBER
- Tracked actor: LanternGlow
- Campaign: TIDEGLASS

## Summary

This infrastructure note extends Northwind CTI's LanternGlow actor profile with
newly confirmed staging infrastructure supporting the TIDEGLASS campaign. Since
publishing our profile in September we have correlated additional passive-DNS
and netflow evidence from two financial-services victims and identified a
second-stage delivery host. Northwind CTI publishes indicators in plain,
non-defanged form.

## Findings

The LanternGlow delivery network separates credential harvesting from payload
staging. The credential-harvesting tier remains short-lived and disposable, as
documented previously. The staging tier, by contrast, is more stable, and we
have now characterized one of its hosts directly. We identified a phase-two
staging server at `198.51.100.55` that serves the second-stage TIDECLASP
payload to the first-stage downloader after a successful credential capture.

The staging server at `198.51.100.55` answered on port 443 with a self-signed
certificate and returned the payload only when the requesting client presented
a campaign-specific URI path, an access-gating behavior that frustrates
automated sandbox retrieval. Netflow from both victims showed the downloader
contacting `198.51.100.55` over `https://` in a brief, single-purpose session,
after which deployed implants beaconed to the durable command-and-control
domain `cloud-sync.example` rather than back to the staging host. We assess
`198.51.100.55` and `cloud-sync.example` to be operated by the same actor,
based on the tightly coupled retrieval-then-beacon sequence and temporally
correlated provisioning.

Consistent with LanternGlow's observed tradecraft, the staging server was
taken offline between activity bursts and re-provisioned, while the group
preserved `cloud-sync.example` as its long-lived C2 identity. We observed no
unrelated content hosted on `198.51.100.55`, reinforcing our assessment that it
is dedicated, actor-controlled infrastructure rather than an incidental
compromise.

## Assessment

Northwind CTI assesses with high confidence that the phase-two staging server
at `198.51.100.55` is an actor-controlled component of the LanternGlow delivery
network within the TIDEGLASS campaign. Together with the previously reported C2
domain `cloud-sync.example`, it completes our current picture of the group's
two-tier delivery-and-tasking architecture. The disciplined separation,
access gating, and durable C2 identity are consistent with the state-nexus
collection posture described in our actor profile.

Financial-services defenders should block and alert on `198.51.100.55` and
`cloud-sync.example`, hunt egress logs for the staging-server URI path and for
short single-session retrievals preceding sustained HTTPS beaconing, and
preserve netflow that captures the retrieval-then-beacon sequence, which is the
most reliable behavioral signature of this activity. As with the group's other
staging hosts, we expect `198.51.100.55` to be decommissioned and replaced
between activity bursts; defenders should therefore prioritize the durable C2
domain `cloud-sync.example` for long-lived blocking while retaining the staging
address as a historical hunting pivot. Organizations that recover a downloader
sample should extract and share the embedded staging URI path, which has proven
stable across the samples we have analyzed and materially improves detection
coverage for the delivery tier. Northwind CTI will fold newly discovered nodes
into subsequent LanternGlow reporting and will continue to correlate victim
netflow to expand its map of the TIDEGLASS delivery network.
