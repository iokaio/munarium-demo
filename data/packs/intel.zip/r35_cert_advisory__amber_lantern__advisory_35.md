# ES-CERT Advisory ESC-2025-1220-35

- Issuer: ES-CERT
- Date: 2025-12-20
- TLP: CLEAR
- Tracked actor: AMBER LANTERN
- Campaign: Operation TIDEGLASS

## Summary

ES-CERT is issuing this advisory to help financial-sector organizations defend
against Operation TIDEGLASS, an intrusion campaign targeting payment
processors, lenders, and fintech providers. This advisory consolidates
publicly reported findings from multiple commercial threat-intelligence
vendors and translates them into concrete mitigations. It references the actor
using the AMBER LANTERN designation established by one of the reporting
vendors; other vendors track the same or overlapping activity under different
names. Released at TLP:CLEAR for the widest possible distribution, this
advisory publishes indicators in plain form.

## Findings

Reporting across the community describes a consistent operational pattern.
Initial access is achieved through spearphishing that abuses vendor-onboarding
and regulatory-compliance workflows, directing recipients to
credential-harvesting pages that mirror their own identity provider and proxy
authentication in real time to defeat one-time passcodes. Following credential
capture, the operators deploy the TIDECLASP implant, which persists through a
scheduled task impersonating a software-update service and communicates over
HTTPS to actor-controlled infrastructure such as the command-and-control domain
`cloud-sync.example`. Reported staging infrastructure includes hosts that serve
the second-stage payload only after a campaign-specific request path is
presented.

Collection is selective and focused on settlement and reconciliation records,
correspondent-bank and counterparty data, and clearing-integration
documentation. A recurring theme in the reporting is the abuse of shared
managed-file-transfer and core-banking suppliers as trust bridges between
otherwise unrelated victims. ES-CERT notes that reporting vendors currently
diverge on the actor's motivation — some assess a state nexus, at least one
assesses financial motivation — and this advisory deliberately does not
adjudicate that question, because the recommended mitigations are the same
under either interpretation.

## Assessment

ES-CERT assesses that Operation TIDEGLASS poses a credible and ongoing risk to
financial-sector organizations, and recommends the following mitigations:

- Enforce phishing-resistant, hardware-backed multi-factor authentication on
  all single sign-on and remote-access surfaces; prioritize methods that resist
  real-time authentication proxying.
- Audit OAuth application grants, mailbox-forwarding rules, and session-token
  reuse for anomalies, and revoke unrecognized grants.
- Block and alert on known TIDEGLASS indicators, including `cloud-sync.example`
  and reported staging hosts, after validating them against your environment.
- Hunt for scheduled tasks impersonating browser or software update services
  and for side-loaded signed DLLs in unusual host processes.
- Review third-party trust relationships — especially managed-file-transfer and
  core-banking suppliers — and monitor those integration paths for lateral
  movement.
- Restrict and monitor access to settlement, reconciliation, and
  clearing-integration documentation.

ES-CERT further recommends that financial-sector organizations rehearse their
incident-response plans against both an espionage scenario, in which the
priority is scoping and evicting a persistent collector, and an extortion
scenario, in which the priority is containing a data-leak threat and managing a
ransom demand. Because reporting vendors have documented rapid re-entry into
remediated environments, eviction should be treated as a coordinated event that
rotates all potentially exposed credentials and tokens simultaneously rather
than piecemeal. Smaller institutions that rely on third-party core-banking or
managed-file-transfer providers should confirm with those suppliers that
equivalent controls and monitoring are in place upstream.

Organizations that identify suspected AMBER LANTERN or Operation TIDEGLASS
activity should preserve mailbox-rule and OAuth audit logs, netflow, and any
staging-host artifacts, and report incidents to ES-CERT. ES-CERT will update
this advisory as community reporting evolves.
