# Northwind CTI Flash Report NW-2025-0605-47

- Vendor: Northwind CTI
- Date: 2025-06-05
- TLP: AMBER
- Tracked actor: CRIMSON FERRET
- Campaign: GRAYFROST set

## Summary

Northwind CTI is issuing this flash report to alert manufacturing-sector partners to a
wave of ransomware intrusions observed since early spring 2025. Across five confirmed
victims and three suspected ones, operators established initial access, staged data for
exfiltration, and detonated file-encrypting ransomware within a 96-hour median dwell
window. The activity is consistent enough in tooling, staging cadence, and negotiation
posture that Northwind CTI is clustering it as the GRAYFROST set and attributing the
observed intrusions to the actor we track as CRIMSON FERRET. Every named victim to date
operates in discrete-parts or industrial-equipment manufacturing, and every case
involved a double-extortion demand: data was stolen before encryption, and the operators
threatened public leak-site disclosure to pressure payment.

## Findings

Initial access in four of the five confirmed cases traced to exposed remote-access
appliances protected only by single-factor credentials, most likely sourced from
commodity infostealer logs. Once inside, CRIMSON FERRET operators moved quickly to
enumerate Active Directory, disable endpoint protection through a signed vulnerable
driver, and pull data to attacker-controlled staging before deploying the ransomware
payload from a domain controller via scheduled task.

Northwind CTI observed the following indicators during incident response and is
publishing them in plain, non-defanged form for immediate detection engineering:

- Command-and-control beacon: 203.0.113.120 over HTTPS on port 443
- Secondary C2 / fallback: 198.51.100.44
- Exfiltration staging host: https://transfer-stage.grayfrost-ops.example/upload
- Leak-site contact portal: https://grayfrost-support.example/victim
- Ransomware payload SHA-256: 4f1c9ad2e77b3a6058c1de44b0f9a217c3e8d5619b02fa7c4d81e6a390bb57c2
- DUSKREACH loader SHA-256: a903be71c4d20f5e18d7c6ab449f2130e6c58bb71d0af3e29c4471b6d5a8e0f1
- Actor negotiation alias observed in ransom note: "grayfrost_desk"

The ransom notes dropped in each environment used a consistent template naming the
GRAYFROST leak site and instructing victims to authenticate to a Tor-hosted negotiation
portal within seven days. Demands scaled with apparent annual revenue, ranging from
roughly USD 400,000 to USD 2.1 million in the confirmed set. Two victims who declined to
engage saw sample documents posted to the public leak site within eleven days of
encryption, confirming the double-extortion model rather than an idle threat.

Northwind CTI notes that the intrusion chain relied on the DUSKREACH loader as a
first-stage delivery mechanism. We caution that DUSKREACH is a commodity tool and its
presence should be corroborated with additional CRIMSON FERRET tradecraft before
attribution; a dedicated tooling note will follow. For this flash, the loader is called
out only as an indicator, not as standalone proof of actor identity.

## Assessment

Northwind CTI assesses with moderate confidence that the GRAYFROST set represents a
single, financially motivated criminal operation targeting manufacturers of opportunity
rather than a strategically selected victim list. The consistency of the leak-site
branding, negotiation template, and staging cadence across geographically dispersed
victims points to a coherent operating team behind CRIMSON FERRET, rather than
uncoordinated affiliates reusing a shared kit. The manufacturing focus is likely driven
by the sector's low tolerance for downtime, which raises the operators' expected payout
per intrusion.

We expect CRIMSON FERRET to continue prioritizing internet-exposed remote-access
appliances and to expand its victim pool through the summer. Partners in discrete
manufacturing should prioritize multi-factor enforcement on all remote access, monitor
for the plain indicators above, and treat any DUSKREACH detection as a trigger for
deeper hunting rather than a closed finding. Northwind CTI will publish a fuller campaign
report as additional victims are confirmed and will update the indicator set as
infrastructure rotates.
