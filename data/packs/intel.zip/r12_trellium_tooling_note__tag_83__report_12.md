# Trellium Tooling Note TR-2025-45

- Vendor: Trellium
- Date: 2025-11-12
- TLP: AMBER
- Tracked actor: TAG-83
- Campaign: cross-cluster tooling

## Summary

Trellium tracks a second energy-sector intrusion cluster as TAG-83, distinct
from TAG-77. This note documents TAG-83's use of the GLASSKEY loader, which
other vendors have associated with the SILKNOTE campaign.

## Findings

Trellium observed the GLASSKEY loader in two TAG-83 intrusions at
distribution-utility targets in October 2025. In both cases GLASSKEY
performed the same environment checks and telemetry-suppression routine
documented in public reporting, then retrieved a different second-stage
implant than the one associated with SILKNOTE.

The GLASSKEY loader used by TAG-83 shares its core routine with the SILKNOTE
variant but was compiled with a different toolchain and does not contact
SILKNOTE infrastructure.

## Assessment

Trellium assesses that GLASSKEY is used by TAG-83 as well as by the SILKNOTE
cluster, and is therefore shared tooling rather than an exclusive indicator
of any single actor. Attribution based on GLASSKEY presence alone is
unsafe. TAG-83 and TAG-77 remain separately tracked clusters with
overlapping tradecraft but distinct infrastructure and implants.
