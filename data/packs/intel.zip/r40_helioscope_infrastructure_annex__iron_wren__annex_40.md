# Helioscope Labs Infrastructure Annex HL-2025-0730-40

- Vendor: Helioscope Labs
- Date: 2025-07-30
- TLP: AMBER
- Tracked actor: IRON WREN
- Campaign: Operation COPPERVEIL
- Report class: Infrastructure annex

## Summary

This annex fulfils the infrastructure annex promised in the Operation COPPERVEIL campaign report. It consolidates every staging and command-and-control indicator Helioscope Labs has attributed to IRON WREN across the confirmed victim set, together with certificate observations and hosting patterns that support clustering. The intent is to give telecommunications SOCs a single, authoritative hunting resource for Operation COPPERVEIL. Indicators are grouped by function — staging tier, primary command-and-control, and secondary rendezvous — and each is defanged per Helioscope Labs convention. Where an indicator was observed at more than one victim, we mark it as shared-tier, which raises its value for retrospective hunting.

## Findings

Primary command-and-control for IRON WREN centers on a small, stable set of hosts that recurred across the campaign. The domain `hxxps://relay-hub[.]example` served as the principal beacon endpoint and was observed at a majority of confirmed victims; it resolved during the campaign window to `203.0.113[.]61`, which we assess as the campaign's most durable command-and-control address. A companion host, `hxxps://cdn-sync[.]example`, provided second-stage retrieval and resolved intermittently to `203.0.113[.]44`. Both domains were fronted behind a commodity reverse proxy, and Helioscope Labs assesses the operators reused a single hosting reseller for their primary tier.

The staging tier — used for loader delivery and short-lived exfiltration rendezvous — comprised `198.51.100[.]23`, `198.51.100[.]77`, and `198.51.100[.]140`. These addresses rotated more frequently than the primary tier and were typically live for one to three weeks before abandonment. A secondary rendezvous domain, `hxxps://update-broker[.]example`, appeared late in the campaign and resolved to `203.0.113[.]129`; we assess it as a contingency channel activated when primary command-and-control was unavailable.

Certificate observations strengthen the clustering. The primary command-and-control hosts presented TLS certificates issued by a free automated certificate authority, reissued on a regular cadence, sharing a distinctive subject-alternative-name pattern that bundled the beacon domain with a throwaway wildcard. Across the campaign we recovered four certificates matching this pattern, with issuance timestamps clustering within a narrow window that aligns with the actor's observed staging setup activity. The reverse proxy consistently advertised an identical, slightly nonstandard cipher-suite ordering, providing a durable network-level fingerprint that defenders can hunt on independent of domain or address.

Hosting patterns further support single-actor attribution. The primary tier resided with one reseller and the staging tier with a second; both providers offer anonymous signup and cryptocurrency billing. IRON WREN never co-located primary command-and-control with staging, a compartmentalization choice consistent with the operational discipline documented elsewhere in Operation COPPERVEIL reporting. We observed no overlap between COPPERVEIL infrastructure and other campaigns Helioscope Labs tracks, which is one reason we treat IRON WREN as a distinct intrusion set.

## Assessment

Helioscope Labs assesses with high confidence that the infrastructure catalogued here belongs to IRON WREN and supports Operation COPPERVEIL. The stability of the primary command-and-control tier, the reuse of shared staging hosts across unrelated victims, the coherent certificate fingerprint, and the deliberate separation of hosting tiers together constitute strong clustering evidence. Defenders should ingest these indicators into blocklists and retrospective hunts, prioritizing the shared-tier hosts `203.0.113[.]61` and `relay-hub[.]example` as the highest-value anchors.

We caution that command-and-control infrastructure is perishable. Several staging hosts are already dormant, and we expect IRON WREN to migrate primary infrastructure now that it is documented. The most durable of these findings are the certificate and cipher-suite fingerprints, which survive domain and address rotation. Helioscope Labs will publish a separate tooling note covering the campaign's loader and second-stage implant, and will update this annex as new IRON WREN infrastructure surfaces. Organizations identifying any catalogued indicator in historical logs should treat it as a confirmed Operation COPPERVEIL touchpoint and initiate incident response.
