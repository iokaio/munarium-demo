# Helioscope Labs Actor Report HS-AR-2025-58

- Vendor: Helioscope Labs
- Date: 2025-11-25
- TLP: AMBER
- Tracked actor: SLATE VULTURE
- Campaign: PouchRunner (unrelated — government)

## Summary

Helioscope Labs provides a follow-up on SLATE VULTURE, the state-espionage
intrusion set we track under the PouchRunner campaign for its targeting of
government and diplomatic entities. Since our September report (HS-AR-2025-57),
SLATE VULTURE has refreshed its infrastructure and introduced a second-stage
implant with improved in-memory operation, but its mission — quiet collection of
diplomatic and foreign-policy material — is unchanged. The group remains distinct
from energy, financial, telecom, and manufacturing espionage. All indicators are
defanged.

## Findings

Through October and November 2025, Helioscope observed SLATE VULTURE retire the
infrastructure documented in September and stand up a fresh set. New first-stage
command-and-control appeared at 203.0.113[.]230 and 203.0.113[.]236, with lure
staging over hxxps://demarche-desk.test and hxxps://summit-agenda.test. A revised
collection implant contacted 203.0.113[.]241 and exfiltrated over the domain
diplo-archive.test. These indicators supersede the September set; the earlier
hosts at 203.0.113[.]210 and 203.0.113[.]212 are no longer active. The rotation
is consistent with SLATE VULTURE's disciplined operational hygiene rather than a
response to any specific disclosure.

The notable technical change is the second-stage implant. Where SLATE VULTURE
previously wrote a collection module to disk, the new variant executes primarily
in memory, decrypting its configuration at runtime and reducing on-disk
footprint. It continues to target the same diplomatic email and
document-management clients, and it retains the jittered, victim-time-zone
exfiltration behavior Helioscope described previously. The spearphishing themes
have shifted to end-of-year multilateral scheduling — demarche coordination and
summit agendas — matching the diplomatic calendar.

Helioscope has still observed no destructive, ransomware, or financially
motivated behavior from SLATE VULTURE. The group continues to clean up staging
artifacts after each collection cycle and to limit beaconing volume, both
consistent with an intelligence-collection mission. We reiterate that this
activity and its infrastructure are specific to government and diplomatic
targeting and share no confirmed overlap with the critical-infrastructure or
financial-market intrusion sets tracked elsewhere.

## Assessment

Helioscope Labs assesses that SLATE VULTURE's infrastructure rotation and
in-memory implant reflect incremental tradecraft maturation rather than a change
in mission or targeting. The group remains a state-directed espionage actor
collecting against diplomatic decision-making, and its improvements are aimed at
reducing detectability, not at broadening its victim aperture. We judge the
ongoing risk to be confidentiality loss of sensitive diplomatic reporting and
negotiating material.

Defenders in government and diplomatic environments should update hunting to
account for in-memory execution — memory-scanning and behavioral detection rather
than file-based indicators alone — while continuing to watch for jittered,
business-hours-aligned egress. The specific domains and addresses in this report
will rotate; the behavioral pattern is the more durable signal. Helioscope will
continue to track SLATE VULTURE under PouchRunner. As before, SLATE VULTURE
should be correlated only within the government-and-diplomatic espionage space
and never merged with energy, financial, telecom, or manufacturing campaigns.
