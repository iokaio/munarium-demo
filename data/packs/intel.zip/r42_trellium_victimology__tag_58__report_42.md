# Trellium Victimology Report TR-2025-10-12-42

- Vendor: Trellium
- Date: 2025-10-12
- TLP: AMBER
- Tracked actor: TAG-58
- Campaign: COPPERVEIL intrusion set
- Report class: Victimology report

## Summary

This report updates Trellium's victimology for the COPPERVEIL intrusion set, tracked under our designation TAG-58, following three additional months of investigation and customer notification. Since our July bulletin, Trellium's confirmed victim count has grown substantially as retrospective hunts surfaced earlier intrusions that matched the cluster's tradecraft. To date, Trellium has associated 17 victim organizations with TAG-58, all in the telecommunications sector. This report characterizes that victim population by operator type, geography, and observed collection focus, and refines our understanding of TAG-58's targeting logic.

## Findings

The 17 victim organizations span a broader slice of the telecommunications ecosystem than our initial bulletin suggested. The population includes regional and tier-two carriers, two mobile virtual network operators, three wholesale transit and peering providers, a satellite backhaul operator, and a managed-services firm that administers OSS/BSS platforms for several smaller carriers. That last victim is significant: through it, TAG-58 gained indirect visibility into multiple downstream operators, and Trellium assesses the actor recognized and deliberately exploited this supply-chain position.

Geographically, the victim set clusters across three regions with a small number of outliers. Trellium confirmed each of the 17 victim organizations using the same two-anchor bar applied in prior reporting: an edge-appliance compromise matching the COPPERVEIL access pattern plus either shared staging infrastructure or the covert appliance-local accounts characteristic of the cluster. We reviewed a further set of candidate organizations that did not meet this bar and excluded them from the confirmed count, though several remain under active investigation and may be added in future reporting.

Collection focus is consistent across the victim population and reinforces the espionage assessment. In the majority of the 17 victims, TAG-58 reached subscriber-provisioning systems; in a smaller subset it accessed lawful-intercept mediation platforms; and in several transit providers it enumerated routing and peering configuration. The satellite backhaul operator and the OSS/BSS managed-services firm both provided the actor with reach beyond their own perimeters, and Trellium assesses TAG-58 selects victims at least partly for the downstream visibility they confer.

Infrastructure ties across the victim set remain consistent with earlier Trellium reporting. Beacons to `hxxps://relay-hub[.]example` and `203.0.113[.]61` recurred at multiple victims in the expanded population, and the staging host `198.51.100[.]140` reappeared at two organizations added since July. This reuse across otherwise unrelated victims is a primary reason Trellium treats the 17 as a single intrusion set rather than coincidental, separate compromises.

Timeline analysis indicates the campaign began earlier than first believed. Retrospective hunts placed the earliest confirmed TAG-58 intrusion in March 2025, predating our initial detection by roughly three months. The actor's tempo has been steady rather than bursty, with new intrusions appearing roughly monthly, suggesting a sustained collection program rather than a time-boxed operation.

## Assessment

Trellium assesses with high confidence that the 17 victim organizations constitute a single espionage campaign, tracked as TAG-58, against the telecommunications sector. The consistency of the edge-appliance access vector, the reuse of staging infrastructure across unrelated victims, and the uniform interest in provisioning, lawful-intercept, and routing systems support single-cluster attribution. The deliberate targeting of aggregation points — a managed-services provider and a satellite backhaul operator — indicates an actor optimizing for breadth of collection.

Defenders should assume the confirmed count understates true scope, given the retrospective discovery pattern, and should hunt aggressively across appliance and provisioning telemetry. Trellium will continue to expand and refine COPPERVEIL victimology and will report separately on TAG-58 infrastructure and intent.
