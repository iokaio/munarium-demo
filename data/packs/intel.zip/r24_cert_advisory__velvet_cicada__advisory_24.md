# ES-CERT Advisory ESC-2026-004

- Issuer: Energy Sector CERT (ES-CERT)
- Date: 2026-01-05
- TLP: CLEAR
- Referenced actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

ES-CERT is issuing this updated advisory in response to continuing intrusions
against energy-sector organizations attributed by industry reporting to the
actor publicly known as VELVET CICADA, conducting the campaign publicly
tracked as Operation SILKNOTE. This advisory supersedes ES-CERT's prior
SILKNOTE advisory, consolidates the current mitigation guidance, and reflects
indicators confirmed in victim telemetry shared with ES-CERT through year end.
ES-CERT publishes indicators in plain form.

## Ongoing activity

Activity attributed by industry reporting to VELVET CICADA remains ongoing.
Multiple commercial vendors continue to observe intrusions consistent with
Operation SILKNOTE against renewable-energy and grid-services organizations,
using the GLASSKEY loader, the SILKWRAP implant, and a durable command-and-
control domain, update-cdn.example, that persists across rotating hosting.
ES-CERT does not itself attribute the activity but references the VELVET
CICADA designation used in the reporting on which this advisory draws.
Confirmed campaign indicators in ES-CERT's holdings include the C2 domain
update-cdn.example and the phase-two staging server at 203.0.113.77;
defenders should note the actor rotates network infrastructure rapidly and
should not rely on address blocking alone.

## Recommended mitigations

Organizations in the electricity subsector should:

1. Block and alert on outbound connections to the command-and-control domain
   update-cdn.example and to the staging server at 203.0.113.77, while
   recognizing these will rotate; pair address blocking with behavioral
   detection.
2. Hunt for DLL sideloading of unsigned libraries by signed, benign
   application binaries executing from user-writable directories — the
   SILKWRAP execution pattern.
3. Alert on periodic HTTPS beaconing with jitter to newly-registered domains
   that impersonate software-update or content-delivery services.
4. Scrutinize contractor and third-party remote-access paths; enforce
   phishing-resistant multi-factor authentication for all remote access and
   review contractor accounts that authenticate into multiple environments.
5. Reset credentials for any account that authenticated to a suspected
   credential-harvesting page associated with the grid-status lure pattern.
6. Hunt for scheduled tasks and run-key persistence created outside approved
   change windows.
7. Restrict and monitor outbound HTTPS from document repositories to detect
   staged bulk exfiltration.

## Reporting

Affected organizations are asked to report intrusions consistent with this
advisory to ES-CERT within 72 hours of discovery, including any newly
observed lookalike update domains, so ES-CERT can share validated indicators
across the sector. ES-CERT will revise this advisory as additional confirmed
indicators and mitigations become available.

## Assessment

ES-CERT assesses that Operation SILKNOTE remains an active threat to the
renewable-energy and grid-services sectors and that the activity attributed
by industry reporting to VELVET CICADA is unlikely to abate in the near term.
The actor's disciplined infrastructure rotation means durable defense depends
on behavioral detection and hardened remote-access controls rather than
static indicators. ES-CERT urges sector organizations to implement the
mitigations above and to maintain heightened monitoring of contractor access
and outbound traffic from sensitive repositories.
