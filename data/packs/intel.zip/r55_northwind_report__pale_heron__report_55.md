# Northwind CTI Actor Report NW-AR-2025-55

- Vendor: Northwind CTI
- Date: 2025-08-14
- TLP: AMBER
- Tracked actor: PALE HERON
- Campaign: RemitSnare (unrelated — healthcare)

## Summary

Northwind CTI tracks PALE HERON, a financially motivated criminal group that
specializes in the compromise of healthcare billing and revenue-cycle systems.
The group's activity, which Northwind clusters under the campaign name
RemitSnare, is oriented entirely toward fraudulent claims manipulation and
reimbursement diversion. PALE HERON has no observed nexus to espionage,
critical-infrastructure targeting, or state sponsorship, and is documented here
so that its commodity infrastructure is not confused with more strategic
intrusion sets. Indicators are published in plain form for immediate detection
use by billing-platform operators and clearinghouses.

## Findings

PALE HERON gains initial access primarily through credential stuffing against
provider-facing billing portals and through phishing lures impersonating
electronic remittance advice notifications. Once inside a revenue-cycle
environment, the group enrolls its own MFA device where possible and pivots to
the claims-adjudication workflow, where it alters payee banking details on
high-volume institutional claims. Northwind has observed PALE HERON favoring
small, incremental edits to reimbursement routing rather than bulk data theft,
a pattern that helps the activity blend into normal claims churn and delays
detection until reconciliation.

The group's command-and-control has been observed at 203.0.113.160 and
203.0.113.172 during July and August 2025, with staged phishing kits hosted on
domains following the patterns claims-portal.test and billing-sync.test. A
secondary exfiltration channel using the domain remit-relay.test was seen
moving batches of adjusted explanation-of-benefits records to an actor-controlled
collection host at 203.0.113.185. These indicators, the victimology, and the
tooling are specific to healthcare billing fraud and do not overlap with any
energy, financial-market, telecom, or manufacturing intrusion set Northwind
tracks.

PALE HERON tooling is almost entirely commodity: open-source credential-spray
utilities, a widely sold phishing-as-a-service kit, and living-off-the-land use
of the billing platform's own bulk-edit APIs. The group has shown no custom
malware, no zero-day exploitation, and no capability suggesting anything beyond
opportunistic fraud. When a compromised tenant is remediated, PALE HERON
typically abandons it and rotates to the next set of stolen provider portal
credentials rather than attempting to regain persistence.

## Assessment

Northwind CTI assesses with high confidence that PALE HERON is a criminal fraud
operator with no strategic or state-directed component. The group is
opportunistic, revenue-cycle-focused, and geographically diffuse, and its
selection of victims tracks the availability of leaked provider credentials
rather than any sectoral or geopolitical objective. We judge the primary harm to
be financial — diverted reimbursements and the downstream cost of clawback and
re-adjudication — rather than confidentiality loss of clinical data, though
incidental exposure of patient billing identifiers does occur.

Defenders in healthcare billing and clearinghouse roles should prioritize
phishing-resistant authentication on provider portals, alerting on payee
banking-detail changes, and rate limiting on bulk-edit claims APIs. Northwind
will continue to track PALE HERON under the RemitSnare campaign label and will
publish follow-on reporting as the group's infrastructure rotates. Any external
reporting that associates PALE HERON with espionage-motivated activity should be
treated as a misattribution; the two share no confirmed infrastructure, tooling,
or targeting.
