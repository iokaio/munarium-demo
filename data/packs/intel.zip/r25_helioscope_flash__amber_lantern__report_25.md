# Helioscope Labs Flash Report HL-2025-0520-25

- Vendor: Helioscope Labs
- Date: 2025-05-20
- TLP: AMBER
- Tracked actor: AMBER LANTERN
- Campaign: Operation TIDEGLASS

## Summary

Helioscope Labs is issuing this flash report to alert the financial-services
community to a new intrusion campaign we are tracking as Operation TIDEGLASS.
Beginning in the second week of April 2025, our incident-response and telemetry
teams observed a coordinated wave of spearphishing against payment processors,
digital-lending platforms, and mid-market fintech firms across North America
and Western Europe. We are releasing early observations now, ahead of a fuller
campaign report, because the tempo and precision of the targeting warrant
immediate defender attention. Indicators in this report are defanged.

## Findings

The initial access vector in every confirmed case is spearphishing. The
operators craft lures around vendor-onboarding and compliance-attestation
themes — subjects such as "Updated KYC attestation package" and "Q2 settlement
reconciliation" — that are convincing to finance and treasury staff. Messages
carry a link to an actor-controlled landing page hosted at
`hxxps://onboarding-portal[.]example/kyc`, which presents a cloned single
sign-on prompt and harvests credentials before redirecting the target to a
legitimate document. In a subset of cases the lure instead delivers a
password-protected archive containing a signed LNK file that side-loads a
lightweight downloader.

The downloader, which we are still characterizing, retrieves a second-stage
payload we have designated the TIDECLASP implant. TIDECLASP establishes
persistence through a scheduled task masquerading as a browser update service
and beacons over HTTPS to infrastructure we are actively mapping. Post-access
behavior is disciplined: the operators validate stolen credentials quickly,
enumerate mailbox rules and OAuth application grants, and pivot toward finance
and reconciliation shares rather than spraying broadly across the estate.

Victimology is tightly clustered in the financial-services and fintech sector.
We have not observed TIDEGLASS collection against healthcare, energy, or
manufacturing targets during this window. Working hours across the operator set
are consistent and narrow, and re-entry into remediated environments occurs
within hours of credential resets, indicating either an unrecovered persistence
mechanism or a second undiscovered foothold. Several victims share a common
managed-file-transfer vendor, and we are investigating whether that supplier
relationship is being abused as a trust bridge between targets.

## Assessment

Helioscope Labs attributes this activity, with moderate confidence, to the
actor we track as AMBER LANTERN. The confidence level reflects that Operation
TIDEGLASS is a newly observed cluster; the attribution rests on tooling
overlaps in the TIDECLASP loader and on tasking patterns consistent with
AMBER LANTERN's historical tradecraft, rather than on a full infrastructure
lineage. The concentration on financial-services intelligence — settlement
flows, counterparty data, and cross-border payment metadata — together with
the operational discipline observed, is more consistent with a directed
collection requirement than with opportunistic fraud at this stage.

Defenders in the financial-services sector should treat vendor-onboarding and
compliance-themed lures as elevated risk, enforce phishing-resistant
multi-factor authentication on all SSO surfaces, and audit OAuth application
grants and mailbox-forwarding rules for anomalies. Helioscope Labs will follow
this flash with a consolidated campaign report as our visibility into Operation
TIDEGLASS matures. Hunt for the defanged landing-page indicator
`onboarding-portal[.]example` and for scheduled tasks impersonating browser
update services as immediate starting points.
