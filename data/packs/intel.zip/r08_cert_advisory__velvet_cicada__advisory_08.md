# ES-CERT Advisory ESC-2025-114

- Issuer: Energy Sector CERT (ES-CERT)
- Date: 2025-11-04
- TLP: CLEAR
- Referenced actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

ES-CERT is aware of ongoing intrusions against energy-sector organizations
attributed by industry reporting to the actor publicly known as VELVET
CICADA (Operation SILKNOTE). This advisory provides actionable mitigations
for network defenders. ES-CERT publishes indicators in plain form.

## Recommended actions

Organizations in the electricity subsector should:

1. Block outbound connections to 203.0.113.41, the campaign
   command-and-control address confirmed in victim telemetry shared with
   ES-CERT.
2. Audit mail-flow rules for the grid-status notification lure pattern
   described in vendor reporting.
3. Reset credentials for any account that authenticated to a
   credential-harvesting page, and enforce phishing-resistant MFA for
   remote access.
4. Hunt for scheduled tasks created outside change windows since March
   2025.

## Reporting

Affected organizations are asked to report intrusions consistent with this
advisory to ES-CERT within 72 hours of discovery. ES-CERT will update this
advisory as additional confirmed indicators become available.
