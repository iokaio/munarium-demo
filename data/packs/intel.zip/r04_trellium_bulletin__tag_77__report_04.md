# Trellium Threat Bulletin TR-2025-19

- Vendor: Trellium
- Date: 2025-07-02
- TLP: AMBER
- Tracked actor: TAG-77
- Campaign: SILKNOTE intrusion set

## Summary

Trellium has confirmed intrusions at four energy-sector customers consistent
with the publicly discussed SILKNOTE activity. Trellium tracks the
responsible cluster as TAG-77 under our internal designation scheme.

## Findings

In each confirmed intrusion, the implant established command-and-control by
beaconing to 203.0.113[.]41 over TLS on port 443 with a self-signed
certificate reusing the same serial number across victims. Trellium defangs
network indicators in all published reporting.

Lateral movement relied on harvested domain credentials and scheduled tasks;
no custom privilege-escalation tooling was observed. Collection staging
occurred in web-accessible directories of an internal SharePoint mirror in
two of the four cases.

## Assessment

Trellium attributes the SILKNOTE intrusions to TAG-77. Victimology and
infrastructure registration patterns align with the cluster's 2024
collection activity against grid-modernization suppliers. We assess with
moderate confidence that TAG-77's tasking originates from a state
intelligence requirement.
