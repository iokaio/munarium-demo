# Helioscope Labs Campaign Report HL-2025-0625-38

- Vendor: Helioscope Labs
- Date: 2025-06-25
- TLP: AMBER
- Tracked actor: IRON WREN
- Campaign: Operation COPPERVEIL
- Report class: Campaign report

## Summary

This campaign report consolidates four weeks of investigation into the telecommunications-sector intrusion cluster first described in our 28 May flash. Since that publication, Helioscope Labs has completed victim scoping across multiple incident engagements and third-party notifications. On the strength of consistent tradecraft, shared staging infrastructure, and overlapping tooling, Helioscope Labs attributes Operation COPPERVEIL to IRON WREN with high confidence. This report presents the current victimology, refines the intrusion lifecycle, and sets out our forward reporting plan for the campaign.

## Findings

As of this publication, Helioscope Labs has confirmed IRON WREN activity at 9 victim organizations, all operating in the telecommunications sector. The victims span regional carriers, a mobile virtual network operator, and two wholesale transit providers. Confirmation in each case rested on at least two of three anchors: exploitation of an internet-facing appliance matching the COPPERVEIL access pattern, callbacks to staging infrastructure previously catalogued, or the covert appliance-local accounts characteristic of this actor. We excluded four additional candidate organizations where evidence was suggestive but did not meet our two-anchor confirmation bar.

The intrusion lifecycle has sharpened since the flash. IRON WREN continues to rely on edge-appliance exploitation for initial access, but we can now describe the follow-on stages with greater fidelity. After foothold, the actor deploys a small living-off-the-land toolkit, harvests appliance and directory credentials, and pivots toward provisioning and mediation systems. In three of the nine confirmed victims, the actor reached lawful-intercept mediation platforms; in two, subscriber databases were queried directly. Callback infrastructure remained consistent with earlier reporting, with `hxxps://relay-hub[.]example` and `203.0.113[.]61` recurring across multiple victims, and a newly observed staging host at `198.51.100[.]77`.

We also refined our understanding of IRON WREN's operational security. The actor rotates credentials it harvests, prunes appliance logs selectively rather than wholesale, and times lateral movement to business hours in the victim's timezone to blend with legitimate administration. This tempo discipline is a reason the campaign evaded early detection at several victims and underscores the need for behavior-based hunting rather than reliance on volumetric anomalies.

Tooling analysis is ongoing. We have recovered loader and second-stage samples from three victims and are reverse-engineering them under a separate workstream; findings will appear in a dedicated tooling note. At this stage we are not publishing hashes to avoid tipping the actor before broader victim notification concludes.

## Assessment

Helioscope Labs assesses with high confidence that Operation COPPERVEIL is a coherent espionage campaign conducted by a single actor, IRON WREN, against the telecommunications sector. The uniformity of the edge-appliance access pattern, the reuse of staging infrastructure across the nine confirmed victims, and the consistent targeting of carrier provisioning and intercept systems collectively support single-actor attribution and an intelligence-collection motive. We continue to withhold nation-state sponsor attribution pending further corroboration.

To support defender action, Helioscope Labs will publish an infrastructure annex detailing the full set of staging and command-and-control indicators, certificate observations, and hosting patterns associated with IRON WREN. That annex will extend the conservative indicator set released to date and is intended as a hunting resource for telecom SOCs. A separate tooling note covering the campaign's loader and second-stage implant will follow.

Defenders should prioritize the following: patch and audit all internet-facing appliances; inventory appliance-local accounts and remove any not tied to a known administrator; hunt for the callback indicators listed above and in prior reporting; and monitor provisioning and lawful-intercept mediation platforms for anomalous query patterns. Organizations that identify possible IRON WREN activity should preserve appliance forensic images, which remain the single most valuable artifact for confirming Operation COPPERVEIL involvement.
