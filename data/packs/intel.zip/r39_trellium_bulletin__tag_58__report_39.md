# Trellium Threat Bulletin TR-2025-07-15-39

- Vendor: Trellium
- Date: 2025-07-15
- TLP: AMBER
- Tracked actor: TAG-58
- Campaign: COPPERVEIL intrusion set
- Report class: Threat bulletin

## Summary

Trellium is publishing this bulletin to document confirmed intrusions we track under the designation TAG-58, associated with what we refer to as the COPPERVEIL intrusion set targeting telecommunications providers. Trellium began tracking TAG-58 as a distinct cluster in June 2025 after our managed-detection customers reported a recurring pattern of edge-appliance compromise followed by quiet lateral movement into carrier back-office systems. This bulletin summarizes the intrusions we have confirmed, describes the tradecraft that defines the cluster, and shares indicators for defender hunting. Trellium tracks this activity independently; where our findings overlap with other vendors' reporting on the same telecom-sector campaign, we note the convergence but maintain our own designation and evidentiary bar.

## Findings

Trellium has confirmed a set of intrusions tracked as TAG-58 across telecommunications operators in multiple regions. The intrusions share a consistent entry vector: exploitation of internet-facing network appliances, chiefly remote-access gateways and VPN concentrators, followed by the creation of covert local accounts and out-of-band persistence surviving firmware updates. In each confirmed case, the actor prioritized stealth over speed, using native administrative utilities to move laterally and touching subscriber-provisioning and mediation systems only after establishing durable access.

Our telemetry surfaced recurring command-and-control infrastructure across the COPPERVEIL intrusion set. TAG-58 beacons resolved to `hxxps://relay-hub[.]example` and to the address `203.0.113[.]61`, both observed at more than one victim. A distinct staging host at `198.51.100[.]140` appeared in one Trellium-confirmed intrusion during late June and is published here for the first time. We assess these hosts as part of a shared staging tier rather than victim-specific infrastructure, given their reuse across unrelated victim networks.

TAG-58 tradecraft is notable for its operational discipline. The actor selectively prunes appliance logs, rotates harvested credentials, and schedules lateral movement to align with the victim's business hours. In two Trellium-confirmed intrusions, the actor enumerated lawful-intercept mediation platforms; in one, subscriber records were queried directly. We did not observe bulk exfiltration in the confirmed set, consistent with an actor still consolidating access rather than conducting active collection at scale.

Trellium recovered a loader artifact from one intrusion that stages a follow-on implant in memory. Analysis is ongoing and will be reported separately; we are withholding hashes in this bulletin to preserve investigative advantage while notification continues. We note that the loader's behavior — in-memory staging, minimal disk footprint, and reliance on signed host binaries for execution — is consistent across the COPPERVEIL intrusion set and contributes to the low detection rate observed at affected operators.

## Assessment

Trellium assesses with high confidence that the intrusions documented here constitute a single, coherent intrusion set, which we track as TAG-58, targeting the telecommunications sector for intelligence purposes. The uniformity of the edge-appliance access vector, the reuse of staging infrastructure across unrelated victims, and the consistent interest in carrier provisioning and lawful-intercept systems together support single-cluster attribution and an espionage motive. Trellium does not at this time attribute TAG-58 to a specific state sponsor.

Defenders in the telecommunications sector should patch and audit internet-facing appliances, inventory and validate all appliance-local accounts, hunt for the indicators published here and in prior Trellium reporting, and closely monitor provisioning and lawful-intercept mediation platforms for anomalous access. Trellium will continue to track the COPPERVEIL intrusion set and expects to publish expanded victimology and infrastructure notes as our investigation matures. Customers who suspect TAG-58 activity should preserve appliance forensic images and engage Trellium incident response for corroboration.
