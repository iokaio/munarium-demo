# Northwind CTI Actor Report NW-AR-2025-52

- Vendor: Northwind CTI
- Date: 2025-11-20
- TLP: AMBER
- Tracked actor: SABLE OTTER
- Campaign: (unrelated to SILKNOTE)

## Summary

Northwind CTI reports on SABLE OTTER, a financially motivated intrusion set
active against retail and hospitality targets. SABLE OTTER is unrelated to
the SILKNOTE campaign and is included here only to disambiguate it from
energy-sector activity, as its infrastructure was briefly misattributed by a
third party. Indicators are published in plain form.

## Findings

SABLE OTTER gains initial access through compromised remote-desktop services
exposed to the internet, deploys commodity remote-access tooling, and
monetizes access through point-of-sale malware and extortion. Its
command-and-control uses fast-flux domains under the pattern
pos-sync[.]test, distinct from any energy-sector campaign infrastructure.

Northwind observed SABLE OTTER command-and-control at 203.0.113.200 during
November 2025. This address, victimology, and tooling do not overlap with
the SILKNOTE campaign.

## Assessment

Northwind CTI assesses SABLE OTTER as a criminal actor with no nexus to
energy-sector espionage. Any reporting linking SABLE OTTER infrastructure to
SILKNOTE should be treated as a misattribution; the two sets share no
confirmed infrastructure, tooling, or victimology.
