# Helioscope Labs Flash Report HL-2025-0528-37

- Vendor: Helioscope Labs
- Date: 2025-05-28
- TLP: AMBER
- Tracked actor: IRON WREN
- Campaign: Operation COPPERVEIL
- Report class: Flash advisory

## Summary

Helioscope Labs is issuing this flash report to alert telecommunications-sector defenders to an active intrusion cluster we track as Operation COPPERVEIL. Beginning in the second week of April 2025, our incident-response teams observed a coordinated wave of intrusions against regional and tier-two telecom operators across three geographies. The activity is opportunistic in tempo but disciplined in tradecraft, and we assess with moderate confidence that a single espionage-motivated actor — provisionally tracked by Helioscope Labs as IRON WREN — is responsible. This flash is deliberately narrow: it establishes the campaign, describes the initial-access pattern, and provides early indicators so operators can begin hunting. A fuller campaign report will follow once victim scoping stabilizes.

## Findings

The defining characteristic of Operation COPPERVEIL is initial access via edge-appliance exploitation. In every confirmed case, IRON WREN gained a foothold by exploiting internet-facing network appliances — SSL VPN concentrators, secure-access gateways, and a load-balancer management plane — rather than through phishing or credential stuffing. The actor favors n-day exploitation of appliances that operators had not yet patched, and in two incidents chained a configuration-disclosure weakness with an authenticated command-injection path reachable after the first stage. This preference for the network edge is consistent with an actor seeking durable, low-noise access to carrier infrastructure.

Post-exploitation, IRON WREN moved quickly to establish out-of-band persistence. Operators observed the creation of covert local accounts on the appliance itself, modification of the appliance boot configuration to survive firmware updates, and beaconing to a small set of staging hosts. Early callbacks resolved to `hxxps://relay-hub[.]example` and to the address `203.0.113[.]61`, both of which we are publishing here as first-tier indicators. A second staging address, `198.51.100[.]23`, appeared in one incident during the same window. Defenders should treat any of these as high-severity when observed egressing from appliance management interfaces.

Once inside, the actor demonstrated familiarity with telecom operational systems. In two intrusions, IRON WREN enumerated subscriber-provisioning databases and lawful-intercept mediation platforms — collection targets that reinforce our espionage assessment. Data staging was minimal at this stage, and we did not observe large-volume exfiltration, suggesting the campaign remains in an access-establishment phase rather than active collection at scale.

Notably, Operation COPPERVEIL tradecraft emphasizes living-off-the-land techniques after the initial appliance compromise. The actor relied on native administrative tooling and signed system binaries to move laterally, minimizing the deployment of custom malware in the early kill-chain stages. This restraint is a hallmark of a mature operator and complicates signature-based detection.

## Assessment

Helioscope Labs assesses with moderate confidence that Operation COPPERVEIL is a dedicated espionage campaign against the telecommunications sector, and that IRON WREN is a distinct, well-resourced intrusion set rather than a commodity crimeware crew. The consistent targeting of carrier provisioning and intercept systems, the emphasis on edge-appliance exploitation for stealthy access, and the disciplined use of living-off-the-land techniques together point to a state-aligned collection mission. We do not yet attribute IRON WREN to a specific sponsor and are withholding higher-order attribution pending further corroboration.

We caution that this is an early, developing picture. Victim scoping is ongoing, and the indicator set published here is intentionally conservative. Defenders in the telecom sector should prioritize patching of internet-facing appliances, audit appliance-local account inventories, and hunt for the callback indicators listed above. Helioscope Labs will continue to track Operation COPPERVEIL and expects to release a consolidated campaign report with expanded victimology and infrastructure detail in the coming weeks. Organizations with suspected exposure are encouraged to engage their incident-response provider and share appliance forensic images, which have proven decisive in confirming IRON WREN activity.
