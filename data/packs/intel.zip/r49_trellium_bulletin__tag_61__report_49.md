# Trellium Threat Bulletin TRB-2025-0725-61

- Vendor: Trellium
- Date: 2025-07-25
- TLP: AMBER
- Tracked actor: TAG-61
- Campaign: GRAYFROST intrusion set

## Summary

Trellium is publishing this bulletin to document confirmed ransomware intrusions we
track under the designation TAG-61, associated with the GRAYFROST intrusion set. Trellium
independently investigated three victim environments in the manufacturing sector between
May and July 2025 and has correlated the activity into a single cluster on the basis of
shared leak-site infrastructure, a consistent negotiation template, and overlapping
staging tradecraft. Per Trellium publication convention, all indicators in this bulletin
are defanged. Trellium assesses TAG-61 to be a financially motivated criminal operation
running a double-extortion program against industrial manufacturers.

## Findings

In all three Trellium-investigated cases, TAG-61 obtained initial access through
internet-exposed remote-access appliances using valid credentials, consistent with reuse
of infostealer-sourced logins. Following access, operators enumerated the directory
environment, disabled endpoint protection via a signed vulnerable driver, and exfiltrated
document repositories to external staging prior to encryption. Encryption was deployed as
the terminal action, and victims were presented with a combined demand for a decryptor
and deletion of the stolen data.

Trellium observed the following defanged indicators across the three intrusions:

- Primary C2: 203.0.113[.]140 over hxxps port 443
- Fallback C2: 198.51.100[.]72
- Exfiltration staging: hxxps://transfer-stage[.]grayfrost-ops[.]example/upload
- Leak-site portal: hxxps://grayfrost-support[.]example/victim
- Ransomware payload SHA-256: c1f0a4d7e29b6538f1cc740bb9e2a561d7c48f0193ab72e5c0d84f6a17b3e920
- Loader SHA-256 (DUSKREACH): a903be71c4d20f5e18d7c6ab449f2130e6c58bb71d0af3e29c4471b6d5a8e0f1

Trellium notes that the loader hash observed in TAG-61 intrusions matches a commodity
loader family Trellium tracks as DUSKREACH, which has appeared in unrelated activity
outside this cluster. For that reason, Trellium did not treat loader presence alone as
attributive; the TAG-61 clustering rests on the leak-site branding and negotiation
tradecraft. The ransom notes across all three cases directed victims to a Tor negotiation
portal and threatened public disclosure within a fixed countdown, and in one case Trellium
confirmed sample documents were published after the victim declined to engage.

Demands in the Trellium-investigated set were revenue-scaled and ranged from roughly USD
500,000 to USD 1.8 million. Negotiation transcripts recovered from one environment showed
the operators offering a discount for rapid payment and providing a proof-of-decryption
sample, both behaviors consistent with an established extortion service rather than an
opportunistic one-off actor.

## Assessment

Trellium assesses with moderate-to-high confidence that TAG-61 is a coherent,
financially motivated ransomware operation targeting the manufacturing sector, and that
the GRAYFROST intrusion set is its branded extortion program. The uniformity of the
leak-site infrastructure and negotiation posture across three unrelated victims argues
for a single operating team. Trellium's clustering was performed independently of other
vendors' tracking and is based solely on Trellium telemetry and incident data.

Trellium expects TAG-61 to continue targeting exposed remote-access surfaces at
manufacturers and to maintain its double-extortion model. Defenders should enforce
multi-factor authentication on all external access, alert on the defanged indicators
above once re-fanged for their tooling, and treat any DUSKREACH loader detection as a
hunting trigger rather than confirmation of TAG-61. Trellium will publish infrastructure
and assessment follow-ups as additional TAG-61 victims are confirmed.
