# Helioscope Labs Flash Report HL-2025-0414-01

- Vendor: Helioscope Labs
- Date: 2025-04-14
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

Helioscope Labs is tracking a new intrusion campaign, designated Operation
SILKNOTE, first observed in March 2025. The campaign targets renewable-energy
generation and grid-services operators in North America and Western Europe.
Initial access is achieved through spearphishing messages that impersonate a
regional grid-status notification service.

## Findings

The spearphishing wave delivers a link to a credential-harvesting page hosted
at grid-alerts[.]example. The lure messages reference real transmission
outage events within 48 hours of their public disclosure, indicating the
operators monitor sector news feeds to time their delivery.

Initial access in every observed intrusion was gained through spearphishing
with a grid-status lure. No exploitation of public-facing infrastructure has
been observed in this wave.

## Assessment

Helioscope Labs attributes Operation SILKNOTE to VELVET CICADA with moderate
confidence at this time, based on lure construction, staging behavior, and
victim overlap with earlier VELVET CICADA activity. We expect to revisit this
assessment as the intrusion set develops. Indicators will be updated in
subsequent reports as infrastructure rotates.
