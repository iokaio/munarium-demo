# Northwind CTI Victimology Report NW-2025-1025-52

- Vendor: Northwind CTI
- Date: 2025-10-25
- TLP: AMBER
- Tracked actor: CRIMSON FERRET
- Campaign: GRAYFROST set

## Summary

This victimology report characterizes the manufacturers targeted by CRIMSON FERRET
across the GRAYFROST set and analyzes the actor's ransom-demand behavior. Drawing on
fourteen confirmed Northwind CTI cases and additional leak-site observations, this report
profiles who CRIMSON FERRET attacks, how large the demands run, and what distinguishes
victims who paid from those who did not. All indicators are published plain per Northwind
CTI convention. The central finding is that CRIMSON FERRET selects manufacturers of
opportunity but scales its extortion demands with apparent revenue and downtime
sensitivity.

## Findings

Northwind CTI's confirmed victim set is concentrated in three manufacturing subsectors:
industrial and heavy equipment (six victims), automotive and transportation components
(five), and specialty chemicals and materials (three). Victim organizations ranged from
roughly USD 40 million to USD 900 million in estimated annual revenue, with a median
near USD 180 million. The common thread was not size or geography but exposure: every
confirmed victim ran an internet-facing remote-access appliance reachable with
single-factor credentials at the time of compromise.

CRIMSON FERRET's ransom demands scaled with the victim's estimated revenue and, more
tellingly, with the operators' read of the victim's downtime tolerance. Demands in the
confirmed set ranged from USD 350,000 at the smallest victim to USD 4.2 million at the
largest, with the actor frequently opening near 2 to 3 percent of estimated annual
revenue. Manufacturers with time-critical production lines — just-in-time automotive
suppliers in particular — drew proportionally higher opening demands, consistent with
CRIMSON FERRET pricing the cost of a production halt into the extortion.

Northwind CTI observed the following plain indicators tied to the recent victim wave:

- Leak-site directory: https://grayfrost-leaks.example/directory
- Negotiation portal: https://grayfrost-support.example/victim
- Active C2: 203.0.113.160 over HTTPS
- Exfiltration relay: 198.51.100.101
- Ransom-note filename: RESTORE-GRAYFROST-FILES.txt
- Payload SHA-256: 9c3f7a10e58bd2461cc09fb4a7e21503d6c84f0192bb73e5c0d84f6a17b3e921

Of the fourteen confirmed victims, Northwind CTI assesses that at least five paid, based
on their removal from the leak-site countdown before the disclosure deadline. Non-paying
victims were named publicly and had sample documents posted within seven to fourteen days
of encryption, consistent with the double-extortion model documented in earlier reports.
Northwind CTI observed no cases in which CRIMSON FERRET re-extorted a victim after
payment during this window, though we caution that absence of observed re-extortion is not
evidence of deletion. The DUSKREACH loader appeared in twelve of the fourteen intrusions
but, consistent with prior Northwind CTI guidance, was treated as corroboration rather
than as the basis for victim clustering.

## Assessment

Northwind CTI assesses with high confidence that CRIMSON FERRET is an opportunistic but
disciplined operation: victims are selected by exposure, then demands are tailored to
revenue and downtime sensitivity to maximize payout. The concentration in industrial
equipment, automotive components, and specialty chemicals almost certainly reflects both
the prevalence of exposed remote-access appliances in those subsectors and their acute
sensitivity to production interruption.

We expect CRIMSON FERRET to sustain its manufacturing focus and to continue pricing
demands against downtime cost. Manufacturers — especially just-in-time suppliers — should
assume they are attractive targets, enforce multi-factor authentication on all external
access, segment operational technology from IT, and rehearse an extortion-response plan
that weighs the data-disclosure threat independently of encryption recovery. Northwind
CTI will continue tracking the GRAYFROST leak site and update victimology as the set
expands.
