# Northwind CTI Actor Report NW-AR-2025-56

- Vendor: Northwind CTI
- Date: 2025-10-08
- TLP: AMBER
- Tracked actor: PALE HERON
- Campaign: RemitSnare (unrelated — healthcare)

## Summary

This report is a follow-up on PALE HERON, the financially motivated group
Northwind CTI tracks under the RemitSnare campaign for its exclusive focus on
healthcare billing and reimbursement fraud. Since our August profile
(NW-AR-2025-55), PALE HERON has expanded from provider-portal credential abuse
into third-party revenue-cycle-management vendors, giving the group a
one-to-many path into downstream provider organizations. The activity remains
criminal and fraud-oriented, with no observed connection to espionage or
critical-infrastructure targeting. Indicators are published in plain form.

## Findings

Between late August and early October 2025, Northwind observed PALE HERON
shifting upstream. Rather than compromising individual provider portals, the
group phished administrators at two outsourced revenue-cycle-management vendors
and abused legitimate vendor tenancy to reach multiple client practices at once.
This is a meaningful efficiency gain for the actor: a single vendor foothold
exposed dozens of downstream billing environments without requiring fresh
credential theft for each.

The group's tradecraft otherwise remains consistent with RemitSnare. PALE HERON
continues to alter payee banking details on institutional claims in small
increments, and it continues to time edits to coincide with high-volume
submission windows. New command-and-control was observed at 203.0.113.190 and
203.0.113.205 during September 2025. Phishing infrastructure rotated to the
patterns eob-portal.test and vendor-desk.test, and a new exfiltration host was
identified at 203.0.113.221 receiving batched remittance records over the domain
remit-collect.test. These indicators supersede, but do not contradict, the
August set; older infrastructure at 203.0.113.160 has gone dark.

Northwind also observed a modest capability improvement: PALE HERON now scripts
the payee-detail edits through the RCM platform's automation API, reducing the
manual interaction that previously left distinctive session artifacts. The group
still relies on commodity phishing kits and open-source tooling and has not
demonstrated custom malware or exploitation of unpatched vulnerabilities. When
one vendor tenant was locked down, PALE HERON did not attempt to re-enter; it
moved laterally in its target list to the second vendor.

## Assessment

Northwind CTI assesses that PALE HERON's move to revenue-cycle-management
vendors reflects normal criminal optimization rather than any escalation in
sophistication or intent. The group remains a fraud operator whose objective is
reimbursement diversion, and its expansion increases the blast radius of a
single compromise without changing its fundamental character. We continue to
judge the primary impact as financial, with incidental exposure of patient
billing identifiers.

The vendor-tenancy vector warrants specific attention. Northwind recommends that
revenue-cycle-management providers enforce phishing-resistant authentication for
administrative accounts, segment client tenancies so that one compromised
operator cannot silently edit payee details across all clients, and alert on
API-driven banking-detail changes. Downstream provider organizations should
request evidence of these controls from their billing vendors. Northwind will
continue to track PALE HERON under RemitSnare and will issue further updates as
infrastructure rotates. As with our prior reporting, PALE HERON should not be
associated with energy, financial-market, telecom, or manufacturing espionage;
the campaign is healthcare-fraud-specific and shares no confirmed overlap with
those intrusion sets.
