# Northwind CTI Hunting Guide NW-HG-2025-09

- Vendor: Northwind CTI
- Date: 2025-11-28
- TLP: AMBER
- Tracked actor: CicadaSpin
- Campaign: SILKNOTE

## Summary

Northwind CTI is publishing behavioral hunting guidance for CicadaSpin
activity within the SILKNOTE campaign. Because CicadaSpin rotates network
infrastructure aggressively, indicator-of-compromise matching alone provides
short-lived coverage. This guide emphasizes behavior-based hunts across
delivery, execution, C2, and exfiltration that survive the actor's
infrastructure churn. Indicators are published in plain form.

## Hunting guidance

### Delivery and initial access

Hunt for GLASSKEY loader delivery patterns rather than specific attachments.
CicadaSpin favors spearphishing with a grid-status or interconnection-filing
lure and, frequently, compromise of contractor remote-access accounts. Review
authentication logs for remote-access sessions from newly-seen geolocations or
autonomous systems tied to contractor accounts, especially where a single
contractor identity authenticates into multiple client environments in a short
window. Correlate first-seen external logins with subsequent process creation
on the accessed host.

### Execution and persistence

CicadaSpin executes SILKWRAP via DLL sideloading against signed, benign host
binaries. Hunt for signed executables loading unsigned or unusually-located
DLLs from user-writable paths, and for legitimate application binaries running
from non-standard directories. The current SILKWRAP variant reconstructs its
configuration in memory and gates on victim environment before beaconing, so
prioritize hunts that surface the sideloading relationship and in-memory
implant artifacts over static file signatures. Review scheduled tasks and
run-key persistence created outside change windows.

### Command and control

The durable network signals are behavioral. CicadaSpin beacons over HTTPS to
software-update-themed domains such as update-cdn.example using a
manifest-style tasking path and a jittered check-in interval averaging near
47 minutes with random offset, and it suppresses beaconing during victim-local
weekends. Hunt for periodic-with-jitter outbound HTTPS to newly-registered or
low-reputation domains matching the update/cdn/patch/mirror naming
convention, for a stable custom User-Agent presenting across multiple internal
hosts, and for a consistent JA3 TLS fingerprint on those flows. A single
internal host beaconing on a near-hourly jittered cadence to a lookalike
update domain is a high-value lead even absent a known-bad address.

### Exfiltration

Collection is staged before exfiltration. Hunt for bulk internal document
access followed by outbound HTTPS POSTs to a telemetry-style path, and for
archive creation in staging directories preceding transfer. CicadaSpin routes
onward transfer through phase-two staging infrastructure — Northwind has
observed staging at 203.0.113.77 — and rotates it frequently, so alert on the
behavior (large compressed uploads to freshly-seen object-storage or gateway
hosts) rather than on the staging address alone.

## Prioritized hunts

Northwind recommends defenders run, in priority order: (1) signed-binary
sideloading of user-path DLLs; (2) jittered periodic HTTPS to update-themed
lookalike domains with a shared custom User-Agent and stable JA3; (3)
contractor remote-access anomalies preceding new host activity; and (4) bulk
document access followed by staged HTTPS exfiltration. Each hunt targets a
stage of the intrusion that CicadaSpin cannot cheaply change, unlike its IPs
and certificates.

## Assessment

Northwind CTI assesses that behavior-based hunting is the durable path to
detecting CicadaSpin given the actor's disciplined infrastructure rotation.
The sideloading execution pattern, the jittered beacon rhythm to
update-themed domains, and the staged exfiltration profile persist across
infrastructure generations and are difficult for the actor to alter without
reengineering its tradecraft. Northwind will refine these hunts as new
CicadaSpin tradecraft is observed and share validated behavioral analytics
with trusted partners.
