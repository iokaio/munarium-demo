# Northwind CTI Landscape Note NW-2025-1115-34

- Vendor: Northwind CTI
- Date: 2025-11-15
- TLP: GREEN
- Tracked actor: LanternGlow
- Campaign: TIDEGLASS

## Summary

This strategic landscape note situates the LanternGlow / TIDEGLASS campaign
within the broader threat picture facing the financial-services sector in late
2025. It is written for security leadership and risk owners rather than for
detection engineers, and is released at TLP:GREEN to support sector-wide
awareness. Northwind CTI publishes indicators in plain form; this note is
primarily strategic and contains few technical indicators.

## Findings

Over 2025 the financial-services sector has faced intensifying targeting from
capable intrusion actors, and the TIDEGLASS campaign — attributed by Northwind
CTI to the actor we track as LanternGlow — is among the most disciplined we
have observed this year. LanternGlow's focus on the operational core of the
payment system, rather than on consumer accounts or opportunistic fraud,
distinguishes it from the commodity threats most institutions are tuned to
detect. The campaign's selective interest in settlement flows, correspondent
relationships, and clearing-integration details reflects an adversary seeking
to understand how money moves, not merely to steal a fixed sum.

Our findings corroborate the broad strokes of peer reporting. Independent
vendors have documented the same spearphishing tradecraft, the same
TIDECLASP-family implant, and overlapping infrastructure, and there is strong
community consensus that a single actor is responsible for the TIDEGLASS
intrusion set even where designations differ. Northwind CTI assesses a state
nexus for LanternGlow, an assessment we hold with moderate-to-high confidence;
we note that at least one peer weighs the available evidence toward a
financial motivation, and we regard the intent question as genuinely
contested within the community. We flag this divergence rather than paper over
it, because motivation shapes the risk calculus for defenders.

From a sector-risk standpoint, three structural exposures amplify TIDEGLASS.
First, shared managed-file-transfer and core-banking suppliers create trust
bridges that let a single compromise propagate across institutions. Second,
the concentration of settlement and clearing functions in a small number of
providers means that targeting a few well-chosen victims yields
disproportionate visibility into the system. Third, compliance-themed lures
exploit exactly the workflows that finance and treasury staff are trained to
act on promptly.

## Assessment

Northwind CTI assesses that LanternGlow represents a durable, strategic threat
to the financial-services sector under the TIDEGLASS campaign, and that sector
risk is elevated regardless of how the motivation debate resolves — a
state-nexus collector and a financially motivated extortionist both justify the
same near-term defensive posture. Boards and security leaders should treat
supplier trust relationships, settlement-system access, and compliance-workflow
phishing as top-tier risks.

We recommend sector-level information sharing on TIDEGLASS indicators,
third-party risk reviews of managed-file-transfer and core-banking suppliers,
and tabletop exercises spanning both espionage and extortion scenarios.
Northwind CTI will continue to publish LanternGlow reporting and will revise
this landscape view as community consensus on intent evolves.
