# Helioscope Labs Malware Deep-Dive HL-2025-1108-32

- Vendor: Helioscope Labs
- Date: 2025-11-08
- TLP: AMBER
- Tracked actor: AMBER LANTERN
- Campaign: Operation TIDEGLASS

## Summary

This report presents Helioscope Labs' technical deep-dive into the TIDECLASP
implant, the primary second-stage tool of Operation TIDEGLASS. Our analysis is
based on three recovered samples and dynamic detonation in an instrumented
environment. TIDECLASP is a modular, HTTPS-beaconing implant purpose-built for
selective collection in financial-services environments. Indicators and hashes
in this report are defanged where applicable.

## Findings

The analyzed TIDECLASP sample corresponds to the synthetic SHA-256 hash
`c1e5a7930b6d2f84e0a1c3b57d9028f461ac7e30d52b18f9640ae2c7b83d10f5`. The implant
is delivered by the first-stage downloader as a signed DLL and is side-loaded
by a legitimate host process. On execution it establishes persistence through a
scheduled task that impersonates a browser update service, then decrypts its
configuration — including the command-and-control endpoint — from an embedded,
XOR-obfuscated blob keyed on a per-sample constant.

TIDECLASP is modular. A small core loader handles persistence, configuration,
and command dispatch, and retrieves additional capability modules on demand
from its C2. During detonation we recovered a collection module that enumerates
mailbox rules and OAuth application grants, a file-triage module that searches
shares for reconciliation and settlement keywords, and a lightweight
credential-access module. The implant beacons over HTTPS with a fixed
User-Agent and a consistent small check-in body, matching the
`hxxps://cloud-sync[.]example` tasking pattern documented in our infrastructure
report. Tasking responses are encrypted and length-padded to blend check-in and
command traffic.

TIDECLASP exhibits deliberate operational-security features: it validates its
execution environment against sandbox artifacts before decrypting its
configuration, gates module retrieval behind a campaign-specific URI path, and
wipes staging files after each module runs. It does not contain any
ransomware, wiper, or extortion functionality; every recovered module serves
collection or access, reinforcing the espionage-oriented tasking profile
Helioscope has reported.

The XOR-key derivation, the scheduled-task naming convention, and the
configuration-blob format are consistent across all three samples and overlap
with loader code previously attributed to AMBER LANTERN, providing a strong
code-lineage pivot for the implant family.

## Assessment

Helioscope Labs assesses with high confidence that the TIDECLASP implant
described here, represented by SHA-256
`c1e5a7930b6d2f84e0a1c3b57d9028f461ac7e30d52b18f9640ae2c7b83d10f5`, is the core
second-stage capability of Operation TIDEGLASS and is developed and operated by
AMBER LANTERN. The purely collection-oriented module set, disciplined
operational security, and code lineage all reinforce our state-directed
espionage assessment.

Defenders should deploy detections for the scheduled-task naming convention,
side-loaded signed DLLs in unusual host processes, and the fixed-User-Agent
HTTPS check-in pattern. Because TIDECLASP retrieves its capability modules on
demand rather than shipping them in the initial payload, static analysis of a
recovered core loader will under-represent the implant's full functionality;
we therefore recommend that responders capture memory and outbound tasking
traffic during live incidents to observe the modules actually deployed against
a given victim. The per-sample XOR key means that file-hash blocking alone will
age quickly as the operators recompile, so behavioral detections anchored on the
persistence and beaconing patterns should be treated as the durable control and
the hash as a point-in-time indicator. Helioscope Labs will publish detection
signatures alongside this deep-dive and will update the TIDECLASP family
analysis as new samples are recovered and additional modules are observed.
