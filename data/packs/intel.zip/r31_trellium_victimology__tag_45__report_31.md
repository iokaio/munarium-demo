# Trellium Victimology Report TRB-2025-1030-31

- Vendor: Trellium
- Date: 2025-10-30
- TLP: AMBER
- Tracked actor: TAG-45
- Campaign: TIDEGLASS intrusion set

## Summary

Trellium is publishing an expanded victimology analysis of the TAG-45
intrusion set, part of the broader TIDEGLASS intrusion set, following six
additional incident-response engagements over the third quarter of 2025. This
report characterizes who TAG-45 targets, what data the operators pursue, and
how victims are connected, drawing on eleven confirmed victims in total.
Indicators in this report are defanged.

## Findings

TAG-45 victimology is narrowly concentrated in financial services and fintech.
Of the eleven confirmed victims, four are payment processors, three are
digital-lending platforms, two are cross-border remittance providers, and two
are core-banking software vendors that serve smaller institutions. We have
observed no confirmed TAG-45 intrusions outside financial services, and no
targeting of consumer accounts directly; the operators consistently pursue the
institutions that sit at the plumbing of the payment system rather than their
end customers.

Within each victim, the operators' collection is remarkably consistent. TAG-45
prioritizes settlement and reconciliation data, correspondent-bank and
counterparty records, cross-border payment metadata, and the configuration of
fraud- and sanctions-screening systems. In several engagements the operators
accessed integration documentation describing how the victim connects to
clearing networks and partner institutions. This tasking suggests an interest
in understanding the structure and flow of the payment system, not merely in
any single institution's records.

Victim interconnection is a defining feature of the set. Five of the eleven
victims share a common managed-file-transfer supplier, and in at least two
cases we assess with moderate confidence that TAG-45 used that trust
relationship to move from one victim into another. Two core-banking vendors in
the set serve overlapping downstream institutions, raising the possibility of
supply-chain positioning. Across all engagements, operator working hours fall
into a consistent daily window, and the TIDECLASP-consistent implant and
`hxxps://` beaconing tradecraft match the earlier TAG-45 bulletin.

## Assessment

Trellium assesses with high confidence that the eleven victims constitute a
single, coherently tasked intrusion set, which we continue to designate TAG-45
and associate with the public TIDEGLASS intrusion set. The victimology — a
tight focus on payment-system infrastructure, selective collection of
settlement and interconnection intelligence, and repeated abuse of shared
supplier relationships — points to a deliberate campaign to map the financial
system's operational structure. At this stage Trellium is not issuing a
motivation assessment; we are actively evaluating whether the objective is
intelligence collection, financial gain, or a combination, and we expect to
publish a determination once ongoing artifact analysis concludes.

Financial-services defenders, especially payment processors and core-banking
vendors, should audit managed-file-transfer trust paths with partners, monitor
access to clearing-integration and screening-configuration documentation, and
enforce phishing-resistant multi-factor authentication. Trellium will continue
to track TAG-45.
