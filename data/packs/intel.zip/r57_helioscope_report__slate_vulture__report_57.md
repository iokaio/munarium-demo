# Helioscope Labs Actor Report HS-AR-2025-57

- Vendor: Helioscope Labs
- Date: 2025-09-05
- TLP: AMBER
- Tracked actor: SLATE VULTURE
- Campaign: PouchRunner (unrelated — government)

## Summary

Helioscope Labs tracks SLATE VULTURE, a state-espionage intrusion set focused on
government and diplomatic entities. Helioscope clusters the group's current
activity under the campaign name PouchRunner, reflecting its interest in
diplomatic correspondence, consular records, and foreign-ministry protocol
material. SLATE VULTURE is documented here to keep it clearly separated from
energy, financial, telecom, and manufacturing espionage; it shares no confirmed
infrastructure, tooling, or victimology with those intrusion sets. All indicators
in this report are defanged.

## Findings

SLATE VULTURE's initial access is characteristically patient. Helioscope has
observed the group conducting extended reconnaissance of foreign-ministry and
diplomatic-mission staff via professional-networking pretexts before delivering
spearphishing lures themed around visa processing, protocol scheduling, and
multilateral summit logistics. The lures carry password-protected archives that
drop a lightweight first-stage loader; the loader beacons only intermittently and
on a jittered schedule, a hallmark that has helped SLATE VULTURE evade
volume-based network detection.

Command-and-control for the first-stage loader was observed at 203.0.113[.]210
and 203.0.113[.]212 during August 2025, with staging content retrieved over
hxxps://consular-brief.test and hxxps://visa-status.test. A later-stage collection
component contacted 203.0.113[.]218 and used the domain protocol-notes.test to
exfiltrate document sets in encrypted, chunked transfers timed to business hours
in the victim time zone. Helioscope emphasizes that these indicators, and SLATE
VULTURE's diplomatic targeting, are distinct from any energy-sector or
financial-market campaign; analysts should not fold this infrastructure into
critical-infrastructure clusters.

The group's tooling suggests a well-resourced but disciplined operator. The
first-stage loader is modular and reflectively loaded, custom collection modules
target specific email and document-management clients used in diplomatic
settings, and SLATE VULTURE consistently cleans up staging artifacts after
exfiltration. Helioscope has not observed destructive activity, ransomware, or
financially motivated behavior — the objective is quiet, sustained access to
diplomatic reporting.

## Assessment

Helioscope Labs assesses with moderate-to-high confidence that SLATE VULTURE is a
state-directed espionage actor whose collection priorities center on diplomatic
and foreign-policy decision-making. The group's tradecraft — patient targeting,
jittered beaconing, victim-time-zone exfiltration, and thorough cleanup — is
consistent with an intelligence-collection mission rather than opportunistic
crime. We judge the primary risk to be confidentiality loss of sensitive
diplomatic correspondence and negotiating positions.

Government and diplomatic defenders should prioritize phishing-resistant
authentication for mission staff, scrutiny of password-protected archive
attachments, and egress monitoring tuned for low-and-slow beaconing rather than
high-volume anomalies. Helioscope recommends threat-hunting for the loader's
jittered callback pattern even where the specific domains in this report have
rotated. We will continue tracking SLATE VULTURE under PouchRunner and will
publish follow-on reporting. To be explicit for correlation purposes: SLATE
VULTURE is a government-and-diplomatic intrusion set and must not be conflated
with energy, financial, telecom, or manufacturing espionage campaigns.
