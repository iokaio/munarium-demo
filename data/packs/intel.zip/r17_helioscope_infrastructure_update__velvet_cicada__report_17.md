# Helioscope Labs Infrastructure Update HL-2025-0630-17

- Vendor: Helioscope Labs
- Date: 2025-06-30
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

Helioscope Labs is publishing an interim infrastructure update covering
command-and-control rotation by VELVET CICADA in support of Operation
SILKNOTE. Over the reporting window we observed the actor stand up two new
front-end nodes while retaining a long-lived logical C2 endpoint, indicating
a deliberate strategy of surface churn layered over a stable back-end. All
network indicators in this report are defanged per Helioscope publication
policy.

## Findings

The primary observation this period is that the C2 domain
`update-cdn[.]example` remains active and continues to broker VELVET CICADA
implant traffic. Rather than retire the domain when two of its historical IP
mappings were burned in prior reporting, the actor re-pointed it to fresh
front-end infrastructure while preserving the same hostname and URI scheme.
Helioscope assesses this domain has now served as a stable rendezvous point
across at least three distinct hosting generations, and we recommend
defenders continue to alert on the hostname independent of its current
address.

New front-end nodes resolved during the window sat behind a commodity CDN
reverse proxy, with the actual origin obscured. Passive DNS shows
`update-cdn[.]example` flipping A records on an irregular cadence — most
recently to `203.0.113[.]41` — consistent with fast-rotation hosting churn
rather than a scheduled roll. Helioscope also confirmed the phase-two
staging server previously reported at `203.0.113[.]77` is reachable again
after a quiet interval, suggesting the staging tier was warm-parked rather
than abandoned.

Beacon behavior for the current SILKWRAP builds is unchanged in shape but
tuned for lower volume. After the GLASSKEY loader completes injection, the
implant issues an initial check-in as an HTTPS GET to a
`/v2/manifest?ch=<hex>` path on `update-cdn[.]example`, where the `ch`
parameter is a rotating campaign token derived from the victim host GUID.
Subsequent beacons follow a jittered interval averaging roughly 47 minutes
with a plus-or-minus 20 percent random offset, and the implant suppresses
beaconing entirely during locally-observed weekend windows in the victim's
timezone — a low-and-slow profile intended to blend with legitimate CDN
polling. Tasking responses arrive as gzip-compressed JSON inside a
`200 OK` body padded to a fixed length, defeating naive size-based anomaly
detection. Command output is exfiltrated over the same channel using
`hxxps://` POSTs to a `/v2/telemetry` path, again on `update-cdn[.]example`.

Notably, the beacon User-Agent this period mimics a legitimate content-
delivery client string and is stable across victims, which — combined with
the fixed URI template — gives defenders a durable network signature even as
the underlying IPs rotate. Helioscope observed no change to the TLS JA3
fingerprint from prior SILKNOTE reporting.

## Assessment

Helioscope Labs assesses with high confidence that VELVET CICADA is
deliberately decoupling its durable logical C2 (`update-cdn[.]example`) from
its disposable network layer, rotating IPs aggressively while keeping the
hostname and application-layer protocol constant. This pattern rewards
hostname- and behavior-based detection over IP blocklists, which the actor's
churn renders stale within days. The reactivation of the
`203.0.113[.]77` staging tier suggests the operators are preparing for a
renewed collection push rather than winding the campaign down.

Defenders should prioritize alerting on the `update-cdn[.]example` hostname,
the `/v2/manifest` and `/v2/telemetry` URI patterns, and the jittered
47-minute beacon cadence. Helioscope will issue a follow-on malware report
as new SILKWRAP builds are recovered.
