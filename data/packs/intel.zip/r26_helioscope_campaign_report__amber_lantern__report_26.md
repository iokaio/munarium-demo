# Helioscope Labs Campaign Report HL-2025-0612-26

- Vendor: Helioscope Labs
- Date: 2025-06-12
- TLP: AMBER
- Tracked actor: AMBER LANTERN
- Campaign: Operation TIDEGLASS

## Summary

This report consolidates Helioscope Labs' visibility into Operation TIDEGLASS
through the end of May 2025, expanding on our 2025-05-20 flash report. Intrusion
tempo has continued to climb, with newly confirmed victims among payment
processors and digital-lending platforms identified in each week of the
reporting period. The campaign remains tightly focused on the
financial-services and fintech sector. Indicators throughout this report are
defanged.

## Findings

Initial access continues to rely on spearphishing with vendor-onboarding and
compliance-attestation lures. The phishing kit behind the campaign has matured
over the period: the cloned single sign-on pages now fingerprint the victim
browser, proxy authentication in real time to defeat one-time passcodes, and
capture session cookies for immediate reuse. We attribute this kit to a single
development lineage across all observed TIDEGLASS intrusions, based on shared
JavaScript obfuscation, identical error-handling strings, and a common
credential-exfiltration endpoint reached over `hxxps://` beaconing.

Following credential capture, the operators deploy the TIDECLASP implant and
move deliberately toward finance-relevant data: settlement reconciliation
files, counterparty and correspondent-bank records, and cross-border payment
metadata. Collection is selective rather than bulk, and the operators
consistently clean up scheduled tasks and staging artifacts on exit. We
observed no destructive activity, no ransomware, and no extortion messaging in
any TIDEGLASS intrusion during this window; the tasking profile reads as
intelligence collection against the movement of money rather than theft of it.

Working-hour analysis across the operator set remains narrow and consistent,
and re-entry into remediated environments within hours of credential resets
recurred at three victims, reinforcing our assessment of an established,
partially undiscovered persistence mechanism. Several affected firms share a
common managed-file-transfer supplier, and we now assess with moderate
confidence that this trust relationship is being used to move laterally between
otherwise unrelated victims.

## Assessment

Helioscope Labs attributes Operation TIDEGLASS to AMBER LANTERN. Our confidence
has risen from moderate to high over the reporting period on the strength of
consistent tooling lineage in the phishing kit and TIDECLASP loader, stable
operator working hours, and a victimology and tasking profile that align with
AMBER LANTERN's known collection requirements. We assess Operation TIDEGLASS as
state-directed espionage: the selective collection of settlement and
counterparty intelligence, the operational discipline, and the absence of any
monetization behavior are, together, inconsistent with financially motivated
crime and consistent with a state collection mandate targeting financial-system
visibility.

Defenders should prioritize phishing-resistant multi-factor authentication that
resists real-time proxying, continuous review of OAuth grants and session-token
reuse, and monitoring of managed-file-transfer trust paths between partner
organizations, and treat any successful real-time authentication proxy as a
full session compromise requiring token revocation rather than a simple
password reset. To support kit-level detection across the community,
Helioscope Labs will publish a phishing-kit teardown addendum
documenting the credential-proxy internals, obfuscation signatures, TLS
fingerprints, and exfiltration endpoints in full. We will continue to track
Operation TIDEGLASS and will update this attribution as our visibility into
the actor's tooling and infrastructure matures over the coming reporting
periods.
