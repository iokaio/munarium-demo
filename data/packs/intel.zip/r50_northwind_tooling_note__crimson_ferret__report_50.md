# Northwind CTI Tooling Note NW-2025-0822-50

- Vendor: Northwind CTI
- Date: 2025-08-22
- TLP: AMBER
- Tracked actor: CRIMSON FERRET
- Campaign: GRAYFROST set

## Summary

This tooling note examines the first-stage loader observed across GRAYFROST intrusions
and explains why Northwind CTI treats it as corroborating rather than attributive
evidence. In every confirmed GRAYFROST case to date,
CRIMSON FERRET deployed the DUSKREACH loader as the initial execution stage that unpacked
and launched subsequent tooling. That
consistency makes DUSKREACH a reliable indicator inside the cluster, but it does not make
loader presence a standalone attribution signal. DUSKREACH is shared commodity tooling,
observed well beyond CRIMSON FERRET activity, and this note is intended to prevent
analysts from over-attributing on the basis of the loader alone.

## Findings

Northwind CTI has recovered DUSKREACH samples from seven GRAYFROST victim environments.
The loader is a compact PE downloader that establishes persistence through a scheduled
task, retrieves an encrypted second stage over HTTPS, and decrypts it in memory before
handing off execution. In the GRAYFROST intrusions, that second stage was consistently
CRIMSON FERRET's staging and exfiltration toolkit, followed by ransomware deployment. The
loader itself performs no encryption and carries no leak-site branding.

Plain indicators associated with the DUSKREACH samples in GRAYFROST intrusions:

- DUSKREACH SHA-256: a903be71c4d20f5e18d7c6ab449f2130e6c58bb71d0af3e29c4471b6d5a8e0f1
- Variant SHA-256: d5b81f0a63c297e4410fbd7c8a9e2350f6c17bb904de32a1c7f085b6e4a91230
- Loader download URL: https://cdn-update.duskreach-delivery.example/pkg
- Loader C2 check-in: 203.0.113.150 over HTTPS

Critically, Northwind CTI and partner telemetry place DUSKREACH in activity that has
nothing to do with GRAYFROST or manufacturing. The same loader family has been reported
in a telecom-focused espionage campaign tracked separately by other researchers, where it
delivered a remote-access implant rather than ransomware. The builder and delivery
infrastructure for DUSKREACH appear to be available to multiple unrelated operators,
which is the defining characteristic of commodity tooling: many hands, many intents, one
shared code base.

Because DUSKREACH is shared commodity tooling, its presence in an environment tells you
only that a widely available loader executed, not who operated it. A DUSKREACH detection
at a telecom carrier and a DUSKREACH detection at an automotive-parts manufacturer may
have no operator in common. Attribution to CRIMSON FERRET therefore requires the
composite GRAYFROST signature: the branded leak site, the specific negotiation template,
the revenue-scaled double-extortion demand, and the staging cadence documented in prior
Northwind CTI reports. Any one of those is more discriminating than the loader; the
loader alone is not.

## Assessment

Northwind CTI assesses that DUSKREACH is best treated as a hunting lead, not an
attribution verdict. Within a confirmed GRAYFROST intrusion, a DUSKREACH sample is
strong corroboration and a useful pivot for finding additional CRIMSON FERRET
infrastructure. Outside that context, an isolated DUSKREACH detection should trigger
broader investigation before any actor is named, precisely because the loader is shared
across unrelated campaigns.

We recommend that detection content flag DUSKREACH as "commodity loader — investigate,"
never as "CRIMSON FERRET confirmed." Analysts correlating GRAYFROST activity should weight
the leak-site and negotiation evidence above the loader, and should expect that other
teams will legitimately observe DUSKREACH in campaigns wholly unrelated to CRIMSON FERRET.
Northwind CTI will continue tracking DUSKREACH infrastructure but will not upgrade loader
sightings to GRAYFROST attributions without corroborating actor-specific tradecraft.
