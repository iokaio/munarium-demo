# Trellium Victimology Update TR-2025-41

- Vendor: Trellium
- Date: 2025-10-28
- TLP: AMBER
- Tracked actor: TAG-77
- Campaign: SILKNOTE intrusion set

## Summary

Trellium provides an updated victimology assessment for the SILKNOTE
intrusion set (TAG-77) reflecting confirmed and high-confidence suspected
intrusions through October 2025.

## Victimology

Trellium now counts 23 victim organizations associated with the SILKNOTE
intrusion set, including the four confirmed in our July bulletin plus
nineteen additional organizations identified through shared indicators and
victim-notification data. The expanded set includes several grid-services
subcontractors not previously in scope.

Notably, six of the newly identified victims were compromised through a
watering-hole wave rather than direct spearphishing: a trade-association
portal for renewable-energy operators was compromised to serve the
credential-harvesting payload to authenticated members.

## Follow-up

Trellium will publish an IOC addendum for the watering-hole wave, covering
the compromised portal infrastructure and the modified payload, as a
supplement to this report.

## Assessment

The victim expansion and the shift to watering-hole delivery indicate
TAG-77 is broadening access methods while holding its sector focus. Trellium
maintains its state-sponsored attribution assessment for the set.
