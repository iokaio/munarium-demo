# Trellium Infrastructure Note TR-2025-33

- Vendor: Trellium
- Date: 2025-09-10
- TLP: AMBER
- Tracked actor: TAG-77
- Campaign: SILKNOTE intrusion set

## Summary

Trellium is documenting infrastructure tradecraft observed across TAG-77
operations within the SILKNOTE intrusion set, with an emphasis on TLS
certificate reuse and front-end hosting churn. These observations refine the
pivots Trellium uses to cluster TAG-77 infrastructure and to anticipate
rotation. Network indicators are defanged per Trellium policy.

## Findings

TAG-77 operates a two-tier network architecture: a stable logical C2 layer
and a disposable front-end layer that the actor rotates aggressively.
Trellium's collection this period confirms the logical endpoint
`update-cdn[.]example` persists across generations of front-end nodes, while
individual IP mappings survive only days before rotation. During the window
the domain resolved through several front ends, including a mapping to
`203.0.113[.]41`, before churning again. The phase-two staging server at
`203.0.113[.]77` remained associated with the set through the period.

The most analytically useful finding is TLS certificate reuse across
ostensibly unrelated front-end hosts. Trellium recovered a set of leaf
certificates that shared a common issuance pattern: all were short-lived
domain-validated certificates from a single free certificate authority,
issued in tight temporal batches, and several reused the same certificate
serial and public-key fingerprint across hosts that otherwise shared no
network relationship. This reuse links infrastructure that IP-based analysis
alone would treat as independent, and it gives Trellium a durable pivot for
attributing newly observed hosts to TAG-77. In two cases a certificate
observed on a burned front end reappeared on a freshly stood-up node within
seventy-two hours, indicating the operators pre-provision certificates in
bulk and redeploy them as they rotate hosting.

Hosting churn itself followed a discernible rhythm. TAG-77 favored a small
number of bulletproof-adjacent and commodity cloud providers, cycling
front-end virtual machines on a roughly weekly basis and fronting them with
a reverse-proxy layer that concealed the true origin. Trellium observed the
actor abandon a front end within hours of that address appearing in public
reporting, then re-point `update-cdn[.]example` to a pre-staged replacement —
behavior consistent with an operator monitoring open-source indicator feeds
and reacting to exposure. Despite this churn, the URI structure
(`/v2/manifest` for tasking, `/v2/telemetry` for exfiltration) and the JA3
TLS fingerprint remained constant, preserving Trellium's behavioral pivots
even as the network layer moved.

Trellium also noted a modest expansion in registrar diversity: where earlier
TAG-77 domains clustered at one privacy-protected registrar, the current
generation is spread across two, likely to complicate bulk takedown. The
naming convention — software-update and content-delivery themed hostnames on
inexpensive TLDs — did not change.

## Assessment

Trellium assesses with high confidence that TAG-77 maintains a mature,
resilient infrastructure operation characterized by a stable logical C2
overlaid on rapidly rotating front ends. The actor's certificate reuse and
batch pre-provisioning are, paradoxically, its most exploitable weakness:
they link infrastructure that would otherwise appear unrelated and let
defenders anticipate rotation. Trellium recommends pivoting on certificate
serial and public-key reuse and on the constant URI and JA3 signatures rather
than on IP addresses, which the actor's churn renders stale within days.
Trellium will continue to track TAG-77 infrastructure and share validated
certificate and domain pivots with trusted partners.
