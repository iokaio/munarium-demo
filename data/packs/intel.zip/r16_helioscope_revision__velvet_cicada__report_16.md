# Helioscope Labs Assessment Revision HL-2026-0114-16

- Vendor: Helioscope Labs
- Date: 2026-01-14
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

Helioscope Labs is revising the confidence attached to its VELVET CICADA
attribution for Operation SILKNOTE. This revision changes confidence only;
the attribution itself is unchanged.

## Basis for revision

Other vendors have published a competing financially motivated attribution
for the SILKNOTE intrusion set, supported by extortion artifacts Helioscope
Labs has not independently observed. While our code-sharing and
infrastructure analysis continues to support a VELVET CICADA nexus, the
existence of a credible alternative assessment reduces our certainty.

Helioscope Labs is downgrading its VELVET CICADA attribution confidence for
Operation SILKNOTE from high to moderate. We continue to attribute the
campaign to VELVET CICADA and are reconciling the divergent tooling analysis
with the other vendor.

## Impact

This is a confidence revision, not a re-attribution. Detection content and
indicators from prior Helioscope reporting remain valid. We will publish a
reconciliation note once the competing tooling analysis has been examined.

## Assessment

Helioscope Labs attributes Operation SILKNOTE to VELVET CICADA at moderate
confidence as of this revision, superseding the high-confidence assessment in
our August deep-dive report.
