# Helioscope Labs TTP Annex HL-SILKNOTE-TTP

- Vendor: Helioscope Labs
- Date: 2025-08-19
- TLP: AMBER
- Tracked actor: VELVET CICADA
- Campaign: Operation SILKNOTE

## Summary

This annex accompanies the Helioscope Labs Operation SILKNOTE campaign
report and provides the full intrusion chain for VELVET CICADA, mapped to
technique identifiers. It fulfils the TTP annex promised in that report.

## Intrusion chain

1. Spearphishing with a grid-status lure delivers a credential-harvesting
   link.
2. Harvested credentials are used for remote access to the victim's VPN or
   webmail.
3. The GLASSKEY loader is deployed and disables endpoint telemetry sampling.
4. GLASSKEY retrieves and reflectively loads the SILKWRAP implant.
5. SILKWRAP exploits cve 2025 31337 in the document-preview service for
   execution on patched hosts, then stages collection archives for
   exfiltration.

## Malware detail

The SILKWRAP sample analyzed for this annex has SHA-256
a47c9e02b5d1f6883e2a90c4d7b15f3a6c8e0d92417b5a3f9e6c10d84b27a5e1, matching
the sample in the campaign report. Reflective loading leaves no implant
artifact on disk between reboots; persistence is re-established through the
harvested credentials and scheduled tasks.

## Assessment

The chain is consistent across all analyzed intrusions and supports the
campaign report's high-confidence attribution to VELVET CICADA. No new
infrastructure is introduced in this annex.
