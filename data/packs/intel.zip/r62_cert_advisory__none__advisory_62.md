# ES-CERT Defensive Hardening Advisory ES-CERT-ADV-2025-62

- Issuer: ES-CERT
- Date: 2025-12-01
- TLP: CLEAR
- Tracked actor: (none — general guidance)
- Campaign: (none)

## Summary

ES-CERT issues this general defensive-hardening advisory to consolidate baseline
recommendations applicable across sectors as organizations enter 2026. It is not
tied to any single actor, campaign, or active incident, and it publishes no
indicators. The guidance reflects controls that ES-CERT has repeatedly observed to
blunt intrusions regardless of the attacker's motivation, and it is written for a
broad audience of system owners and security teams. Indicators, where ES-CERT
publishes them in incident advisories, are given in plain form; this advisory
contains none.

## Recommended Controls

Identity first. ES-CERT continues to observe that the majority of impactful
intrusions begin with the abuse of legitimate credentials. Organizations should
deploy phishing-resistant multi-factor authentication for all remote and
administrative access, bind sessions to devices where supported, and monitor for
token theft and anomalous authentication. Legacy authentication protocols that
cannot enforce modern controls should be retired.

Reduce and defend the external surface. Internet-facing remote-access gateways,
management interfaces, and file-transfer utilities are recurring entry points.
ES-CERT recommends maintaining an authoritative inventory of external assets,
applying vendor security updates on an expedited schedule for edge devices, and
removing management interfaces from direct internet exposure. Where an appliance
cannot be promptly patched, compensating controls and heightened monitoring should
be applied.

Constrain execution and movement. Baseline endpoint controls — application
allow-listing where feasible, restriction of script interpreters and
administrative tooling to authorized users, and least-privilege administration —
raise the cost of the post-access phase. Network segmentation between user,
server, and administrative zones limits lateral movement and contains the impact
of a single compromised host.

Prepare for data-theft extortion. Because exposure-based extortion does not depend
on encryption, resilient backups are necessary but not sufficient. ES-CERT
recommends least-privilege access to sensitive data stores, egress monitoring for
unusual bulk transfers, and incident-response plans that explicitly address the
theft-and-exposure scenario rather than assuming availability loss alone.

Maintain visibility and rehearsal. Centralized, tamper-resistant logging across
identity, endpoint, and network layers underpins every other control, and its
value is realized only if the logs are retained long enough to support
investigation. ES-CERT recommends periodic tabletop and technical exercises so
that detection and response are validated before, not during, an incident.

## Closing

This advisory provides durable baseline guidance and is intentionally
actor-agnostic; it should be read alongside, not in place of, ES-CERT's
incident-specific advisories. ES-CERT will refresh this baseline periodically as
the threat environment evolves. Questions may be directed to ES-CERT through
standard constituent channels.
