# Trellium Attribution Revision TR-2025-49

- Vendor: Trellium
- Date: 2025-12-03
- TLP: AMBER
- Tracked actor: TAG-83
- Campaign: SILKNOTE intrusion set (revised attribution)

## Summary

Trellium is revising its attribution of the SILKNOTE intrusion set.
Following analysis of newly recovered tooling and financial artifacts,
Trellium now attributes the SILKNOTE campaign to TAG-83 rather than TAG-77.

## Basis for revision

Recovered second-stage implants from three SILKNOTE victims share build
infrastructure and code with TAG-83 tooling documented in our November
tooling note, not with the TAG-77 cluster. In two of these intrusions,
Trellium recovered cryptocurrency-wallet staging artifacts and extortion-note
templates inconsistent with a pure espionage tasking.

Trellium now attributes the SILKNOTE campaign to TAG-83 and assesses the
actor is financially motivated, pursuing extortion and data-theft revenue
rather than state-directed intelligence collection.

## Impact

This revision reassigns the SILKNOTE intrusion set from TAG-77 to TAG-83
within Trellium's tracking. Defenders relying on Trellium attribution should
note that indicators previously published under TAG-77 for this campaign are
now tracked under TAG-83. Prior victimology counts are unaffected by the
reassignment.

## Assessment

Trellium assesses with moderate confidence that SILKNOTE is a
financially motivated TAG-83 operation. We acknowledge this diverges from
other vendors' state-sponsored assessments and will publish supporting
analysis separately.
