# Trellium Assessment Revision TRB-2025-1210-33

- Vendor: Trellium
- Date: 2025-12-10
- TLP: AMBER
- Tracked actor: TAG-45
- Campaign: TIDEGLASS intrusion set (revised)

## Summary

This report revises Trellium's motivation assessment for the TAG-45 intrusion
set. In our earlier bulletins we declined to publish an intent determination
pending artifact analysis. Following two additional engagements and forensic
recovery of monetization infrastructure, Trellium is now issuing a revised
assessment of the actor's motivation. Importantly, this is a revision of
motivation only: we continue to track the same actor as TAG-45, and our
technical clustering of the TIDEGLASS intrusion set is unchanged. Indicators
in this report are defanged.

## Findings

Two Q4 2025 engagements produced evidence we had not previously recovered. On a
staging host abandoned by the operators, our responders recovered draft
extortion correspondence templated for financial-services victims, referencing
stolen settlement records and threatening publication unless payment was made.
The same host held a wallet-management note listing several cryptocurrency
addresses and a running tally consistent with victim-payment tracking, plus a
chat-log fragment negotiating a cryptocurrency ransom denominated in a
stablecoin. These extortion and cryptocurrency artifacts are the first direct
monetization evidence in the TAG-45 dataset.

Re-examining prior engagements in light of these findings, we identified
earlier signals we had under-weighted: selective exfiltration of the exact
records most useful for extortion leverage, and brief connections to
cryptocurrency-exchange infrastructure that we had previously logged as
unattributed noise. The core tradecraft is otherwise unchanged from our earlier
TAG-45 reporting — spearphishing initial access, the TIDECLASP-consistent
implant, `hxxps://` beaconing, and the same operator working-hour window — which
is why our actor clustering is unaffected by the new motivation evidence.

We note that our motivation assessment now diverges from that of some peer
vendors, who assess a state nexus for this activity. Trellium's revision is
driven specifically by the recovered monetization artifacts, which we weight
heavily; we acknowledge the divergence and will continue to share evidence with
the community.

## Assessment

Trellium assesses Operation TIDEGLASS is financially motivated. On the strength
of the recovered extortion correspondence, the cryptocurrency wallet-tracking
note, and the ransom-negotiation chat fragment, we assess with moderate-to-high
confidence that TAG-45's objective is financial gain through data theft and
extortion rather than state-directed collection. This revises our motivation
judgment only; TAG-45 remains our designation for the same actor and the same
intrusion set, and none of our technical attribution is retracted.

Financial-services defenders should treat TAG-45 intrusions as carrying a
material extortion and data-leak risk, ensure incident-response plans cover
ransom-negotiation and cryptocurrency-payment scenarios, and preserve staging
hosts for forensic recovery, which yielded the decisive evidence here. We
further recommend that responders engaging suspected TAG-45 activity involve
legal and communications functions early, given the demonstrated willingness of
this actor to threaten publication of stolen settlement records, and that they
monitor cryptocurrency addresses recovered during response for on-chain activity
that may reveal additional victims. Trellium recognizes that its financial
motivation assessment now diverges from the state-nexus view held by some peers;
we regard this as a healthy product of independent analysis and will continue to
share the underlying artifacts so that the community can weigh the evidence
directly. Trellium will continue to track TAG-45 and will update this assessment
if further evidence warrants.
