# Trellium Actor Assessment TRB-2025-1118-61A

- Vendor: Trellium
- Date: 2025-11-18
- TLP: AMBER
- Tracked actor: TAG-61
- Campaign: GRAYFROST intrusion set

## Summary

This assessment consolidates Trellium's view of TAG-61 after six months of tracking the
GRAYFROST intrusion set. Trellium assesses with high confidence that TAG-61 is a
financially motivated criminal enterprise running a professionalized double-extortion
operation against the manufacturing sector. This report synthesizes intrusion tradecraft,
infrastructure behavior, and extortion economics into a consolidated actor picture. All
indicators are defanged per Trellium convention. Trellium's assessment is derived
independently from Trellium telemetry, incident engagements, and leak-site monitoring.

## Findings

Trellium's evidence base now spans direct incident response at multiple manufacturers,
sustained leak-site monitoring, and infrastructure tracking through reused TLS
certificates. Three characteristics define TAG-61 as a financially motivated criminal
enterprise rather than a state-directed or hacktivist actor.

First, motivation. Every observed TAG-61 action terminates in a monetary demand. There is
no evidence of espionage collection, destructive intent beyond leverage, or ideological
messaging. Stolen data is used strictly as extortion leverage, and negotiation transcripts
show discounting, proof-of-decryption, and deletion promises — the behaviors of a
payment-seeking business.

Second, professionalization. TAG-61 operates a stable, branded leak site with structured
victim listings, countdown timers, and staged disclosure. The operators reuse negotiation
templates and pricing logic across unrelated victims, indicating standardized internal
procedures. Trellium's certificate-reuse pivot suggests a small, consistent operating team
recycling configuration artifacts rather than a sprawling affiliate program.

Third, target economics. TAG-61 concentrates exclusively on manufacturers, scaling demands
to revenue and downtime sensitivity. This is a payout-optimization strategy: production
interruption is expensive and time-critical, which strengthens the operators' leverage.

Representative defanged indicators from the assessment window:

- Active C2: 203.0.113[.]170 over hxxps port 443
- Exfiltration relay: 198.51.100[.]112
- Leak-site primary: hxxps://grayfrost-leaks[.]example/directory
- Negotiation portal: hxxps://grayfrost-support[.]example/victim
- Payload SHA-256: e2a9c4170db5f83641cc90bb2e5f4a71d8c360912ea7b45f0d19c6a8e3f2107c
- Reused TLS certificate CN: grayfrost-ops[.]example

Trellium reiterates that the commodity DUSKREACH loader appears in TAG-61 intrusions but
is not exclusive to this actor and has been reported in unrelated activity. Trellium's
TAG-61 attribution rests on leak-site branding, negotiation tradecraft, and the
certificate-reuse infrastructure pivot, not on the presence of shared tooling.

## Assessment

Trellium assesses with high confidence that TAG-61 is a coherent, financially motivated
criminal enterprise and that the GRAYFROST intrusion set is its branded extortion program
against manufacturers. The convergence of monetary-only outcomes, standardized operating
procedures, and revenue-scaled demands is characteristic of a mature ransomware business
rather than an opportunistic or ideologically driven actor.

Trellium expects TAG-61 to persist and likely grow through the coming quarters, sustaining
its manufacturing focus and two-tier infrastructure model. Trellium judges it likely that
the operators will experiment with additional pressure mechanisms, such as direct outreach
to victims' customers, to accelerate payment. Defenders in manufacturing should treat
TAG-61 as a durable threat: enforce multi-factor authentication on external access, monitor
for the defanged indicators after re-fanging, use the reused-certificate pivot for
proactive hunting, and prepare extortion-response procedures that address data disclosure
independently of recovery. Trellium will update this assessment as the actor's tradecraft
and infrastructure evolve.
