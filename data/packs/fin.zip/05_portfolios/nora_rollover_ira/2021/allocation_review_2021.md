# Nora Vale Rollover IRA Annual Allocation Review — 2021

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `ALLOC-NVR-7782-2021`
- Document type: `portfolio_allocation_review`
- As-of date: 2021-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, NVR-7782, ADVISER-MAYA-CHEN

## Annual review scope

This report evaluates Nora Vale Rollover IRA against the household's current IPS and the most restrictive quarterly constraint sheet in force at the review date.

## Year-end or latest available position

- Ending value: $3,026,859
- Prior comparison value: $2,704,087
- Public equity: 64%
- Fixed income: 28%
- Cash and short-term Treasury: 4%
- Diversifiers: 4%

## Findings

The account remained diversified and held no prohibited products. Its public-equity weight is evaluated together with the other liquid accounts; the household cap is 60%. The household liquidity floor is $1,500,000, and designated tax or construction reserves may not be redeployed merely because this account is within its percentage range.

## Recommended implementation

Use cash flows for rebalancing, retain high-basis lots for spending needs, place tax-inefficient bonds preferentially in the IRA, and preserve the trust's distribution policy. No change to risk tolerance is inferred from market performance.
