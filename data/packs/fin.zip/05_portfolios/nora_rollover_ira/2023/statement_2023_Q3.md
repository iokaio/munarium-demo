# Nora Vale Rollover IRA Quarterly Statement — 2023 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `PORT-NVR-7782-2023-Q3`
- Document type: `portfolio_statement`
- As-of date: 2023-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, NVR-7782

## Account summary

- Account title: Nora Vale Rollover IRA
- Masked account ID: NVR-7782
- Custody type: traditional rollover IRA
- Quarter: 2023 Q3

| Activity | Amount |
|---|---:|
| Opening market value | $3,180,151 |
| Contributions | $0 |
| Withdrawals | ($0) |
| Investment return | $152,486 |
| Advisory and custody fees | ($3,975) |
| **Ending market value** | **$3,328,662** |

## Ending allocation

| Asset class | Weight | Representative holdings |
|---|---:|---|
| Global public equity | 74% | U.S. total-market, developed ex-U.S., emerging-markets index funds |
| Investment-grade fixed income | 18% | Treasury ladder, municipal bonds, core bond index |
| Cash and short-term Treasury | 4% | government money-market fund and 3–12 month Treasury bills |
| Diversifiers | 4% | managed futures and listed infrastructure |
| **Total** | **100%** | |

## Suitability annotations

- Current household risk band: moderate-growth (6/10).
- Current combined growth-asset cap: 72%.
- Current household liquidity floor: $2,750,000.
- Retirement/trust restrictions mean this account is not the primary source for the near-term liquidity floor.
- No prohibited product, unauthorized margin debit, or issuer position above 5% was present at quarter end.

## Adviser review

Cash flows were reviewed against business distributions, construction costs, taxes, and known capital calls. Allocation weights in this statement are account-level; the quarterly advisory review determines compliance on a combined-household basis.
