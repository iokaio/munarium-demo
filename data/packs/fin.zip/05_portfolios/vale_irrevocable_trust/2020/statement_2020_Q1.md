# Vale Family Irrevocable Trust Quarterly Statement — 2020 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `PORT-VIT-5520-2020-Q1`
- Document type: `portfolio_statement`
- As-of date: 2020-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VIT-5520

## Account summary

- Account title: Vale Family Irrevocable Trust
- Masked account ID: VIT-5520
- Custody type: irrevocable family trust
- Quarter: 2020 Q1

| Activity | Amount |
|---|---:|
| Opening market value | $3,610,000 |
| Contributions | $0 |
| Withdrawals | ($0) |
| Investment return | $-71,717 |
| Advisory and custody fees | ($4,512) |
| **Ending market value** | **$3,533,771** |

## Ending allocation

| Asset class | Weight | Representative holdings |
|---|---:|---|
| Global public equity | 67% | U.S. total-market, developed ex-U.S., emerging-markets index funds |
| Investment-grade fixed income | 25% | Treasury ladder, municipal bonds, core bond index |
| Cash and short-term Treasury | 4% | government money-market fund and 3–12 month Treasury bills |
| Diversifiers | 4% | managed futures and listed infrastructure |
| **Total** | **100%** | |

## Suitability annotations

- Current household risk band: moderate (5/10).
- Current combined growth-asset cap: 68%.
- Current household liquidity floor: $750,000.
- Retirement/trust restrictions mean this account is not the primary source for the near-term liquidity floor.
- No prohibited product, unauthorized margin debit, or issuer position above 5% was present at quarter end.

## Adviser review

Cash flows were reviewed against business distributions, construction costs, taxes, and known capital calls. Allocation weights in this statement are account-level; the quarterly advisory review determines compliance on a combined-household basis.
