# Vale Family Irrevocable Trust Quarterly Statement — 2022 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `PORT-VIT-5520-2022-Q2`
- Document type: `portfolio_statement`
- As-of date: 2022-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VIT-5520

## Account summary

- Account title: Vale Family Irrevocable Trust
- Masked account ID: VIT-5520
- Custody type: irrevocable family trust
- Quarter: 2022 Q2

| Activity | Amount |
|---|---:|
| Opening market value | $4,050,011 |
| Contributions | $35,000 |
| Withdrawals | ($0) |
| Investment return | $10,753 |
| Advisory and custody fees | ($5,063) |
| **Ending market value** | **$4,090,701** |

## Ending allocation

| Asset class | Weight | Representative holdings |
|---|---:|---|
| Global public equity | 59% | U.S. total-market, developed ex-U.S., emerging-markets index funds |
| Investment-grade fixed income | 33% | Treasury ladder, municipal bonds, core bond index |
| Cash and short-term Treasury | 4% | government money-market fund and 3–12 month Treasury bills |
| Diversifiers | 4% | managed futures and listed infrastructure |
| **Total** | **100%** | |

## Suitability annotations

- Current household risk band: moderate-conservative (4/10).
- Current combined growth-asset cap: 60%.
- Current household liquidity floor: $1,500,000.
- Retirement/trust restrictions mean this account is not the primary source for the near-term liquidity floor.
- No prohibited product, unauthorized margin debit, or issuer position above 5% was present at quarter end.

## Adviser review

Cash flows were reviewed against business distributions, construction costs, taxes, and known capital calls. Allocation weights in this statement are account-level; the quarterly advisory review determines compliance on a combined-household basis.
