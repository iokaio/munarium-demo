# Vale Family Irrevocable Trust Annual Allocation Review — 2025

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `ALLOC-VIT-5520-2025`
- Document type: `portfolio_allocation_review`
- As-of date: 2025-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VIT-5520, ADVISER-MAYA-CHEN

## Annual review scope

This report evaluates Vale Family Irrevocable Trust against the household's current IPS and the most restrictive quarterly constraint sheet in force at the review date.

## Year-end or latest available position

- Ending value: $4,512,461
- Prior comparison value: $4,325,768
- Public equity: 59%
- Fixed income: 33%
- Cash and short-term Treasury: 4%
- Diversifiers: 4%

## Findings

The account remained diversified and held no prohibited products. Its public-equity weight is evaluated together with the other liquid accounts; the household cap is 60%. The household liquidity floor is $3,500,000, and designated tax or construction reserves may not be redeployed merely because this account is within its percentage range.

## Recommended implementation

Use cash flows for rebalancing, retain high-basis lots for spending needs, place tax-inefficient bonds preferentially in the IRA, and preserve the trust's distribution policy. No change to risk tolerance is inferred from market performance.
