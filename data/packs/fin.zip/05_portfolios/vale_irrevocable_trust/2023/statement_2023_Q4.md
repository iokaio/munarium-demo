# Vale Family Irrevocable Trust Quarterly Statement — 2023 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `PORT-VIT-5520-2023-Q4`
- Document type: `portfolio_statement`
- As-of date: 2023-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VIT-5520

## Account summary

- Account title: Vale Family Irrevocable Trust
- Masked account ID: VIT-5520
- Custody type: irrevocable family trust
- Quarter: 2023 Q4

| Activity | Amount |
|---|---:|
| Opening market value | $4,247,406 |
| Contributions | $35,000 |
| Withdrawals | ($45,000) |
| Investment return | $35,807 |
| Advisory and custody fees | ($5,309) |
| **Ending market value** | **$4,267,904** |

## Ending allocation

| Asset class | Weight | Representative holdings |
|---|---:|---|
| Global public equity | 71% | U.S. total-market, developed ex-U.S., emerging-markets index funds |
| Investment-grade fixed income | 21% | Treasury ladder, municipal bonds, core bond index |
| Cash and short-term Treasury | 4% | government money-market fund and 3–12 month Treasury bills |
| Diversifiers | 4% | managed futures and listed infrastructure |
| **Total** | **100%** | |

## Suitability annotations

- Current household risk band: moderate-growth (6/10).
- Current combined growth-asset cap: 72%.
- Current household liquidity floor: $2,750,000.
- Retirement/trust restrictions mean this account is not the primary source for the near-term liquidity floor.
- No prohibited product, unauthorized margin debit, or issuer position above 5% was present at quarter end.

## Adviser review

Cash flows were reviewed against business distributions, construction costs, taxes, and known capital calls. Allocation weights in this statement are account-level; the quarterly advisory review determines compliance on a combined-household basis.
