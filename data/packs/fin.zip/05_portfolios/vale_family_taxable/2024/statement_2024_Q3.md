# Vale Family Taxable Account Quarterly Statement — 2024 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `PORT-VFT-2041-2024-Q3`
- Document type: `portfolio_statement`
- As-of date: 2024-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VFT-2041

## Account summary

- Account title: Vale Family Taxable Account
- Masked account ID: VFT-2041
- Custody type: joint taxable brokerage
- Quarter: 2024 Q3

| Activity | Amount |
|---|---:|
| Opening market value | $6,649,861 |
| Contributions | $106,984 |
| Withdrawals | ($400,000) |
| Investment return | $-154,179 |
| Advisory and custody fees | ($8,312) |
| **Ending market value** | **$6,194,354** |

## Ending allocation

| Asset class | Weight | Representative holdings |
|---|---:|---|
| Global public equity | 65% | U.S. total-market, developed ex-U.S., emerging-markets index funds |
| Investment-grade fixed income | 12% | Treasury ladder, municipal bonds, core bond index |
| Cash and short-term Treasury | 19% | government money-market fund and 3–12 month Treasury bills |
| Diversifiers | 4% | managed futures and listed infrastructure |
| **Total** | **100%** | |

## Suitability annotations

- Current household risk band: moderate (5/10).
- Current combined growth-asset cap: 68%.
- Current household liquidity floor: $3,000,000.
- Counts toward the household liquidity floor.
- No prohibited product, unauthorized margin debit, or issuer position above 5% was present at quarter end.

## Adviser review

Cash flows were reviewed against business distributions, construction costs, taxes, and known capital calls. Allocation weights in this statement are account-level; the quarterly advisory review determines compliance on a combined-household basis.
