# Vale Family Annual Profile Update — 2025

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `PROFILE-2025`
- Document type: `client_profile`
- As-of date: 2025-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, PERSON-NORA-VALE, PERSON-DANIEL-VALE

## Household and family

- Eleanor “Nora” Vale, born 1972-04-18; age 53 during the year
- Daniel Vale, born 1970-09-03; age 55 during the year
- Married; Colorado residents; primary residence in fictional Cresthaven, Colorado
- Dependents: twins enrolled in college; remaining tuition is reserved in 529 plans
- Expected retirement year: 2032; neither client expects to retire before 2030

## Employment and closely held interests

- Nora owns 80% of Vale Dental Group and Dr. Priya Shah owns 20%.
- Daniel owns 70% of Juniper Ridge Outdoor Supply LLC; Nora owns 30%.
- Nora and Daniel each own 50% of Mesa Lantern Properties LLC.
- Nora owns 55% of ClearPeak Analytics LLC; two employee-members own the balance.

## Goals in priority order

1. Maintain household and business resilience without forced sales.
2. Fund retirement beginning in 2032 with $480,000 of first-year after-tax spending, inflation-adjusted thereafter.
3. Complete college funding without using retirement assets.
4. Complete the Cresthaven home project and family-care obligations from designated liquid assets.
5. Build a $2,000,000 charitable legacy by 2035 without jeopardizing core goals.

## Suitability profile

- Risk questionnaire score: 4/10
- Accepted band: moderate-conservative
- Required liquidity: $3,500,000
- Liquidity rationale: pending Vale Dental transaction, transaction expenses, and estimated taxes
- Capacity is lower than net worth alone suggests because the household already has concentrated business, real-estate, and venture exposure.

## Client acknowledgements

The clients understand that private investments may not be redeemed on demand, capital calls can occur during public-market stress, and no unsigned recommendation changes this profile. They prefer diversified, low-cost public holdings and tax-aware implementation. Product prohibitions are maintained in the contemporaneous quarterly constraints sheet.

## Expanded Daniel Vale majority-owned venture disclosure

- Copperline Industrial Partners LLC — Daniel owns 62% after the 2022 capital raise (68% before it).
- Harbor Pine Residential Holdings LLC — Daniel owns 67%.
- Ember & Pine Hospitality Group LLC — Daniel owns 68%.
- High Mesa Lodging Company LLC — Daniel owns 66% after the 2023 capital raise (72% before it).
- Bluebird Events & Catering Corporation — Daniel owns 65%.

These interests are concentrated, leveraged, and illiquid. Their company cash, property equity, restricted deposits, and borrowing capacity do not satisfy the household liquidity floor. See the contemporaneous consolidated business-interest schedule for valuation and provenance.
