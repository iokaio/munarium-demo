# Vale Dental Group PLLC Quarterly Financial Packet — 2023 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2023-Q4`
- Document type: `business_financial_packet`
- As-of date: 2023-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,084,122 |
| Cost of goods or clinical supplies | ($140,936) |
| Payroll and benefits | ($466,172) |
| Occupancy, marketing, and other operating expense | ($243,927) |
| **EBITDA / operating cash proxy** | **$233,086** |

## Balance-sheet and owner-cash items

- Cash: $914,800
- Accounts receivable: $214,798
- Interest-bearing debt: $630,000
- Owner distribution declared: $74,588
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. An analyst draft proposing a 12% private-credit allocation was rejected because it would have breached the liquidity floor and illiquidity cap. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
