# Vale Dental Group PLLC Quarterly Financial Packet — 2023 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2023-Q3`
- Document type: `business_financial_packet`
- As-of date: 2023-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,125,176 |
| Cost of goods or clinical supplies | ($146,273) |
| Payroll and benefits | ($483,826) |
| Occupancy, marketing, and other operating expense | ($253,165) |
| **EBITDA / operating cash proxy** | **$241,913** |

## Balance-sheet and owner-cash items

- Cash: $855,355
- Accounts receivable: $169,396
- Interest-bearing debt: $658,000
- Owner distribution declared: $77,412
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. An analyst draft proposing a 12% private-credit allocation was rejected because it would have breached the liquidity floor and illiquidity cap. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
