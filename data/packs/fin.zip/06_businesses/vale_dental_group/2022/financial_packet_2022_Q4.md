# Vale Dental Group PLLC Quarterly Financial Packet — 2022 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2022-Q4`
- Document type: `business_financial_packet`
- As-of date: 2022-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,086,623 |
| Cost of goods or clinical supplies | ($141,261) |
| Payroll and benefits | ($467,248) |
| Occupancy, marketing, and other operating expense | ($244,490) |
| **EBITDA / operating cash proxy** | **$233,624** |

## Balance-sheet and owner-cash items

- Cash: $786,267
- Accounts receivable: $213,604
- Interest-bearing debt: $742,000
- Owner distribution declared: $74,760
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. Construction began on the Cresthaven residence. The documented two-year project budget is $2,400,000, so the liquid-asset floor increased to $2,500,000. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
