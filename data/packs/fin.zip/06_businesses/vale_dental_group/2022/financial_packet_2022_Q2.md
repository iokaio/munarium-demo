# Vale Dental Group PLLC Quarterly Financial Packet — 2022 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2022-Q2`
- Document type: `business_financial_packet`
- As-of date: 2022-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,044,232 |
| Cost of goods or clinical supplies | ($135,750) |
| Payroll and benefits | ($449,020) |
| Occupancy, marketing, and other operating expense | ($234,952) |
| **EBITDA / operating cash proxy** | **$224,510** |

## Balance-sheet and owner-cash items

- Cash: $739,739
- Accounts receivable: $159,385
- Interest-bearing debt: $798,000
- Owner distribution declared: $71,843
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. Mesa Lantern acquired the Bellwether Commerce Center and the household committed $1,000,000 to Northline Climate Partners II. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
