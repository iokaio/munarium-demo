# Vale Dental Group PLLC Quarterly Financial Packet — 2024 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2024-Q2`
- Document type: `business_financial_packet`
- As-of date: 2024-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,120,538 |
| Cost of goods or clinical supplies | ($145,670) |
| Payroll and benefits | ($481,831) |
| Occupancy, marketing, and other operating expense | ($252,121) |
| **EBITDA / operating cash proxy** | **$240,916** |

## Balance-sheet and owner-cash items

- Cash: $1,001,467
- Accounts receivable: $180,446
- Interest-bearing debt: $574,000
- Owner distribution declared: $77,093
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. Nora assumed recurring care costs for her mother. Risk tolerance returned to moderate and the liquidity floor rose to $3,000,000; Kestrel Growth Fund I was approved only after this reserve was funded. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
