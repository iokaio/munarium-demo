# Vale Dental Group PLLC Quarterly Financial Packet — 2026 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2026-Q1`
- Document type: `business_financial_packet`
- As-of date: 2026-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Northstar Dental Partners 60%; Nora Vale 32%; Dr. Priya Shah 8%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,206,131 |
| Cost of goods or clinical supplies | ($156,797) |
| Payroll and benefits | ($518,636) |
| Occupancy, marketing, and other operating expense | ($271,379) |
| **EBITDA / operating cash proxy** | **$259,318** |

## Balance-sheet and owner-cash items

- Cash: $1,103,655
- Accounts receivable: $258,444
- Interest-bearing debt: $378,000
- Owner distribution declared: $82,982
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. Vale Dental completed a majority recapitalization: Northstar Dental Partners bought 60% of the company. Nora received $8,400,000 of gross proceeds for the 48 percentage points sold from her former 80% interest and retained 32%; Dr. Priya Shah retained 8%. The tax adviser reserved $3,100,000 for federal and Colorado payments due by April 2027. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
