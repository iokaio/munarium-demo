# Vale Dental Group PLLC Quarterly Financial Packet — 2026 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2026-Q2`
- Document type: `business_financial_packet`
- As-of date: 2026-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Northstar Dental Partners 60%; Nora Vale 32%; Dr. Priya Shah 8%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,399,109 |
| Cost of goods or clinical supplies | ($181,884) |
| Payroll and benefits | ($601,617) |
| Occupancy, marketing, and other operating expense | ($314,800) |
| **EBITDA / operating cash proxy** | **$300,809** |

## Balance-sheet and owner-cash items

- Cash: $1,249,969
- Accounts receivable: $293,879
- Interest-bearing debt: $350,000
- Owner distribution declared: $96,259
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. The first post-transaction review restored a moderate risk band while preserving the $4,250,000 liquid reserve and all product prohibitions. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
