# Vale Dental Group PLLC Quarterly Financial Packet — 2020 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2020-Q1`
- Document type: `business_financial_packet`
- As-of date: 2020-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 100%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $824,483 |
| Cost of goods or clinical supplies | ($107,183) |
| Payroll and benefits | ($354,528) |
| Occupancy, marketing, and other operating expense | ($185,509) |
| **EBITDA / operating cash proxy** | **$177,264** |

## Balance-sheet and owner-cash items

- Cash: $620,770
- Accounts receivable: $118,065
- Interest-bearing debt: $1,050,000
- Owner distribution declared: $56,724
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. The household completed initial onboarding. Nora and Daniel prioritized resilience over return maximization. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
