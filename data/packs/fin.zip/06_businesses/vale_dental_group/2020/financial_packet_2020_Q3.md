# Vale Dental Group PLLC Quarterly Financial Packet — 2020 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2020-Q3`
- Document type: `business_financial_packet`
- As-of date: 2020-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 100%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $815,815 |
| Cost of goods or clinical supplies | ($106,056) |
| Payroll and benefits | ($350,801) |
| Occupancy, marketing, and other operating expense | ($183,558) |
| **EBITDA / operating cash proxy** | **$175,400** |

## Balance-sheet and owner-cash items

- Cash: $674,248
- Accounts receivable: $167,553
- Interest-bearing debt: $994,000
- Owner distribution declared: $56,128
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. COVID-19 closures reduced dental production and retail traffic. The household formally lowered risk tolerance and doubled the liquidity floor. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
