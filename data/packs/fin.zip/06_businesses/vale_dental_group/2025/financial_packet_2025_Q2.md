# Vale Dental Group PLLC Quarterly Financial Packet — 2025 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2025-Q2`
- Document type: `business_financial_packet`
- As-of date: 2025-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,179,383 |
| Cost of goods or clinical supplies | ($153,320) |
| Payroll and benefits | ($507,134) |
| Occupancy, marketing, and other operating expense | ($265,361) |
| **EBITDA / operating cash proxy** | **$253,567** |

## Balance-sheet and owner-cash items

- Cash: $1,004,495
- Accounts receivable: $172,274
- Interest-bearing debt: $462,000
- Owner distribution declared: $81,142
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. Vale Dental signed a nonbinding letter of intent for a majority recapitalization. The clients lowered risk and raised the liquidity floor pending closing and tax estimates. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
