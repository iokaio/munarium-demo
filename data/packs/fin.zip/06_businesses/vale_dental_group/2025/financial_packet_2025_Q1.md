# Vale Dental Group PLLC Quarterly Financial Packet — 2025 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2025-Q1`
- Document type: `business_financial_packet`
- As-of date: 2025-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,111,240 |
| Cost of goods or clinical supplies | ($144,461) |
| Payroll and benefits | ($477,833) |
| Occupancy, marketing, and other operating expense | ($250,029) |
| **EBITDA / operating cash proxy** | **$238,917** |

## Balance-sheet and owner-cash items

- Cash: $1,041,788
- Accounts receivable: $166,528
- Interest-bearing debt: $490,000
- Owner distribution declared: $76,453
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. Juniper Ridge acquired Trailhead Outfitters' online catalog for $900,000, financed with $400,000 cash and a $500,000 seller note. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
