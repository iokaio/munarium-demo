# Vale Dental Group PLLC Quarterly Financial Packet — 2025 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2025-Q3`
- Document type: `business_financial_packet`
- As-of date: 2025-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 80%; Dr. Priya Shah 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,247,642 |
| Cost of goods or clinical supplies | ($162,193) |
| Payroll and benefits | ($536,486) |
| Occupancy, marketing, and other operating expense | ($280,719) |
| **EBITDA / operating cash proxy** | **$268,243** |

## Balance-sheet and owner-cash items

- Cash: $1,064,131
- Accounts receivable: $245,364
- Interest-bearing debt: $434,000
- Owner distribution declared: $85,838
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. A draft recommendation to raise public equities to 75% was rejected as outside the current moderate-conservative band. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
