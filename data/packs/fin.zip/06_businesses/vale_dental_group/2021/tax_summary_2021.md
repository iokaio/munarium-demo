# Vale Dental Group PLLC Preliminary Tax Summary — 2021

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `TAX-BIZ-VDG-2021`
- Document type: `business_tax_summary`
- As-of date: 2022-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Preliminary owner tax summary

- Entity: Vale Dental Group PLLC
- Tax year: 2021
- Federal tax classification: S corporation
- Ownership reported for the Vale household: Nora Vale 100%

| Tax workpaper item | Amount |
|---|---:|
| Gross receipts | $3,878,233 |
| EBITDA / operating cash proxy | $833,820 |
| Tax depreciation and amortization | ($135,738) |
| Interest expense | ($46,592) |
| Estimated ordinary business income | **$651,490** |
| Cash distributions to all owners | $266,823 |

## Reconciliation notes

Taxable income differs from cash distributions. The household tax organizer must use the final Schedule K-1, not this management estimate. Basis, passive-activity, at-risk, and state apportionment calculations remain with the tax preparer.

## Planning relevance

The advisory team may use this summary for preliminary estimated-tax and cash-flow planning, but may not count a projected distribution until it is declared. This document does not amend investment constraints.
