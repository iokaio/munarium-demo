# Vale Dental Group PLLC Quarterly Financial Packet — 2021 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2021-Q1`
- Document type: `business_financial_packet`
- As-of date: 2021-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 100%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $903,081 |
| Cost of goods or clinical supplies | ($117,401) |
| Payroll and benefits | ($388,325) |
| Occupancy, marketing, and other operating expense | ($203,193) |
| **EBITDA / operating cash proxy** | **$194,163** |

## Balance-sheet and owner-cash items

- Cash: $695,287
- Accounts receivable: $162,918
- Interest-bearing debt: $938,000
- Owner distribution declared: $62,132
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. The investment committee approved a $750,000 commitment to FrontRange Seed Fund III after cash-flow review. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
