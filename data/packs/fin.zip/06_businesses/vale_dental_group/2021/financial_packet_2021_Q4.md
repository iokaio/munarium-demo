# Vale Dental Group PLLC Quarterly Financial Packet — 2021 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2021-Q4`
- Document type: `business_financial_packet`
- As-of date: 2021-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 100%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $976,424 |
| Cost of goods or clinical supplies | ($126,935) |
| Payroll and benefits | ($419,862) |
| Occupancy, marketing, and other operating expense | ($219,695) |
| **EBITDA / operating cash proxy** | **$209,931** |

## Balance-sheet and owner-cash items

- Cash: $723,662
- Accounts receivable: $183,230
- Interest-bearing debt: $854,000
- Owner distribution declared: $67,178
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. The household approved a $600,000 commitment to Aster Health Ventures I; the liquidity floor remained unchanged. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
