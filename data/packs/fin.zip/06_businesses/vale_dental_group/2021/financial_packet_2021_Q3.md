# Vale Dental Group PLLC Quarterly Financial Packet — 2021 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-VDG-2021-Q3`
- Document type: `business_financial_packet`
- As-of date: 2021-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-VDG

## Entity and ownership

- Legal entity: Vale Dental Group PLLC
- Entity ID: BIZ-VDG
- Ownership at quarter end: Nora Vale 100%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,035,304 |
| Cost of goods or clinical supplies | ($134,589) |
| Payroll and benefits | ($445,181) |
| Occupancy, marketing, and other operating expense | ($232,943) |
| **EBITDA / operating cash proxy** | **$222,590** |

## Balance-sheet and owner-cash items

- Cash: $752,486
- Accounts receivable: $154,133
- Interest-bearing debt: $882,000
- Owner distribution declared: $71,229
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Patient volume, hygiene utilization, staffing, payer mix, and the majority recapitalization process were reviewed. The household approved a $600,000 commitment to Aster Health Ventures I; the liquidity floor remained unchanged. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
