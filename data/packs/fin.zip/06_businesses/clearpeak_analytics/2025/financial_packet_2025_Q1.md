# ClearPeak Analytics LLC Quarterly Financial Packet — 2025 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-CPA-2025-Q1`
- Document type: `business_financial_packet`
- As-of date: 2025-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Entity and ownership

- Legal entity: ClearPeak Analytics LLC
- Entity ID: BIZ-CPA
- Ownership at quarter end: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $485,292 |
| Cost of goods or clinical supplies | ($38,823) |
| Payroll and benefits | ($232,940) |
| Occupancy, marketing, and other operating expense | ($94,632) |
| **EBITDA / operating cash proxy** | **$118,896** |

## Balance-sheet and owner-cash items

- Cash: $499,239
- Accounts receivable: $82,455
- Interest-bearing debt: $0
- Owner distribution declared: $38,047
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Contract backlog, customer concentration, utilization, recurring revenue, and hiring capacity were reviewed. Juniper Ridge acquired Trailhead Outfitters' online catalog for $900,000, financed with $400,000 cash and a $500,000 seller note. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
