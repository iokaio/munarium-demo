# ClearPeak Analytics LLC Quarterly Financial Packet — 2025 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-CPA-2025-Q2`
- Document type: `business_financial_packet`
- As-of date: 2025-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Entity and ownership

- Legal entity: ClearPeak Analytics LLC
- Entity ID: BIZ-CPA
- Ownership at quarter end: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $564,252 |
| Cost of goods or clinical supplies | ($45,140) |
| Payroll and benefits | ($270,841) |
| Occupancy, marketing, and other operating expense | ($110,029) |
| **EBITDA / operating cash proxy** | **$138,242** |

## Balance-sheet and owner-cash items

- Cash: $485,365
- Accounts receivable: $95,683
- Interest-bearing debt: $0
- Owner distribution declared: $44,237
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Contract backlog, customer concentration, utilization, recurring revenue, and hiring capacity were reviewed. Vale Dental signed a nonbinding letter of intent for a majority recapitalization. The clients lowered risk and raised the liquidity floor pending closing and tax estimates. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
