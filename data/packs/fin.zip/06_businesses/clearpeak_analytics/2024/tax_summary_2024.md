# ClearPeak Analytics LLC Preliminary Tax Summary — 2024

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `TAX-BIZ-CPA-2024`
- Document type: `business_tax_summary`
- As-of date: 2025-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Preliminary owner tax summary

- Entity: ClearPeak Analytics LLC
- Tax year: 2024
- Federal tax classification: partnership
- Ownership reported for the Vale household: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

| Tax workpaper item | Amount |
|---|---:|
| Gross receipts | $1,971,004 |
| EBITDA / operating cash proxy | $482,896 |
| Tax depreciation and amortization | ($68,985) |
| Interest expense | ($0) |
| Estimated ordinary business income | **$413,911** |
| Cash distributions to all owners | $154,527 |

## Reconciliation notes

Taxable income differs from cash distributions. The household tax organizer must use the final Schedule K-1, not this management estimate. Basis, passive-activity, at-risk, and state apportionment calculations remain with the tax preparer.

## Planning relevance

The advisory team may use this summary for preliminary estimated-tax and cash-flow planning, but may not count a projected distribution until it is declared. This document does not amend investment constraints.
