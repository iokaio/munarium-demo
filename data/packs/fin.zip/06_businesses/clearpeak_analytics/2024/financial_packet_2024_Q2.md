# ClearPeak Analytics LLC Quarterly Financial Packet — 2024 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-CPA-2024-Q2`
- Document type: `business_financial_packet`
- As-of date: 2024-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Entity and ownership

- Legal entity: ClearPeak Analytics LLC
- Entity ID: BIZ-CPA
- Ownership at quarter end: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $506,364 |
| Cost of goods or clinical supplies | ($40,509) |
| Payroll and benefits | ($243,055) |
| Occupancy, marketing, and other operating expense | ($98,741) |
| **EBITDA / operating cash proxy** | **$124,059** |

## Balance-sheet and owner-cash items

- Cash: $428,919
- Accounts receivable: $88,800
- Interest-bearing debt: $0
- Owner distribution declared: $39,699
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Contract backlog, customer concentration, utilization, recurring revenue, and hiring capacity were reviewed. Nora assumed recurring care costs for her mother. Risk tolerance returned to moderate and the liquidity floor rose to $3,000,000; Kestrel Growth Fund I was approved only after this reserve was funded. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
