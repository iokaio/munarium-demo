# ClearPeak Analytics LLC Quarterly Financial Packet — 2022 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-CPA-2022-Q2`
- Document type: `business_financial_packet`
- As-of date: 2022-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Entity and ownership

- Legal entity: ClearPeak Analytics LLC
- Entity ID: BIZ-CPA
- Ownership at quarter end: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $420,927 |
| Cost of goods or clinical supplies | ($33,674) |
| Payroll and benefits | ($202,045) |
| Occupancy, marketing, and other operating expense | ($82,081) |
| **EBITDA / operating cash proxy** | **$103,127** |

## Balance-sheet and owner-cash items

- Cash: $352,387
- Accounts receivable: $67,615
- Interest-bearing debt: $0
- Owner distribution declared: $33,001
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Contract backlog, customer concentration, utilization, recurring revenue, and hiring capacity were reviewed. Mesa Lantern acquired the Bellwether Commerce Center and the household committed $1,000,000 to Northline Climate Partners II. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
