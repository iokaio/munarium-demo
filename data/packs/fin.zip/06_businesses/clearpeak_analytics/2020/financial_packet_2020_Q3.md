# ClearPeak Analytics LLC Quarterly Financial Packet — 2020 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-CPA-2020-Q3`
- Document type: `business_financial_packet`
- As-of date: 2020-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Entity and ownership

- Legal entity: ClearPeak Analytics LLC
- Entity ID: BIZ-CPA
- Ownership at quarter end: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $341,377 |
| Cost of goods or clinical supplies | ($27,310) |
| Payroll and benefits | ($163,861) |
| Occupancy, marketing, and other operating expense | ($66,568) |
| **EBITDA / operating cash proxy** | **$83,637** |

## Balance-sheet and owner-cash items

- Cash: $283,082
- Accounts receivable: $61,694
- Interest-bearing debt: $124,000
- Owner distribution declared: $26,764
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Contract backlog, customer concentration, utilization, recurring revenue, and hiring capacity were reviewed. COVID-19 closures reduced dental production and retail traffic. The household formally lowered risk tolerance and doubled the liquidity floor. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
