# ClearPeak Analytics LLC Quarterly Financial Packet — 2020 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-CPA-2020-Q4`
- Document type: `business_financial_packet`
- As-of date: 2020-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-CPA

## Entity and ownership

- Legal entity: ClearPeak Analytics LLC
- Entity ID: BIZ-CPA
- Ownership at quarter end: Nora Vale 55%; Morgan Lee 25%; Samir Patel 20%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $336,100 |
| Cost of goods or clinical supplies | ($26,888) |
| Payroll and benefits | ($161,328) |
| Occupancy, marketing, and other operating expense | ($65,540) |
| **EBITDA / operating cash proxy** | **$82,345** |

## Balance-sheet and owner-cash items

- Cash: $265,745
- Accounts receivable: $74,564
- Interest-bearing debt: $96,000
- Owner distribution declared: $26,350
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Contract backlog, customer concentration, utilization, recurring revenue, and hiring capacity were reviewed. The investment committee approved a $750,000 commitment to FrontRange Seed Fund III after cash-flow review. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
