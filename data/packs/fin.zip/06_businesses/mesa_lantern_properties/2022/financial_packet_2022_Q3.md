# Mesa Lantern Properties LLC Quarterly Financial Packet — 2022 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2022-Q3`
- Document type: `business_financial_packet`
- As-of date: 2022-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $594,816 |
| Cost of goods or clinical supplies | ($65,430) |
| Payroll and benefits | ($47,585) |
| Occupancy, marketing, and other operating expense | ($211,160) |
| **EBITDA / operating cash proxy** | **$270,641** |

## Balance-sheet and owner-cash items

- Cash: $684,654
- Accounts receivable: $90,214
- Interest-bearing debt: $5,920,000
- Owner distribution declared: $59,541
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. Construction began on the Cresthaven residence. The documented two-year project budget is $2,400,000, so the liquid-asset floor increased to $2,500,000. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
