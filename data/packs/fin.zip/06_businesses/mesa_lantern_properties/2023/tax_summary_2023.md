# Mesa Lantern Properties LLC Preliminary Tax Summary — 2023

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `TAX-BIZ-MLP-2023`
- Document type: `business_tax_summary`
- As-of date: 2024-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Preliminary owner tax summary

- Entity: Mesa Lantern Properties LLC
- Tax year: 2023
- Federal tax classification: partnership
- Ownership reported for the Vale household: Nora Vale 50%; Daniel Vale 50%

| Tax workpaper item | Amount |
|---|---:|
| Gross receipts | $2,424,720 |
| EBITDA / operating cash proxy | $1,103,248 |
| Tax depreciation and amortization | ($436,450) |
| Interest expense | ($302,744) |
| Estimated ordinary business income | **$364,054** |
| Cash distributions to all owners | $242,715 |

## Reconciliation notes

Taxable income differs from cash distributions. The household tax organizer must use the final Schedule K-1, not this management estimate. Basis, passive-activity, at-risk, and state apportionment calculations remain with the tax preparer.

## Planning relevance

The advisory team may use this summary for preliminary estimated-tax and cash-flow planning, but may not count a projected distribution until it is declared. This document does not amend investment constraints.
