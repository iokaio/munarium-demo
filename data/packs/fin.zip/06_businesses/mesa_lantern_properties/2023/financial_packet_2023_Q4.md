# Mesa Lantern Properties LLC Quarterly Financial Packet — 2023 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2023-Q4`
- Document type: `business_financial_packet`
- As-of date: 2023-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $630,927 |
| Cost of goods or clinical supplies | ($69,402) |
| Payroll and benefits | ($50,474) |
| Occupancy, marketing, and other operating expense | ($223,979) |
| **EBITDA / operating cash proxy** | **$287,072** |

## Balance-sheet and owner-cash items

- Cash: $788,191
- Accounts receivable: $110,610
- Interest-bearing debt: $5,780,000
- Owner distribution declared: $63,156
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. An analyst draft proposing a 12% private-credit allocation was rejected because it would have breached the liquidity floor and illiquidity cap. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
