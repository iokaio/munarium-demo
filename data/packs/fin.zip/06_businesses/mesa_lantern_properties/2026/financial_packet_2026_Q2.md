# Mesa Lantern Properties LLC Quarterly Financial Packet — 2026 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2026-Q2`
- Document type: `business_financial_packet`
- As-of date: 2026-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $727,233 |
| Cost of goods or clinical supplies | ($79,996) |
| Payroll and benefits | ($58,179) |
| Occupancy, marketing, and other operating expense | ($258,168) |
| **EBITDA / operating cash proxy** | **$330,891** |

## Balance-sheet and owner-cash items

- Cash: $1,188,117
- Accounts receivable: $152,603
- Interest-bearing debt: $5,500,000
- Owner distribution declared: $72,796
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. The first post-transaction review restored a moderate risk band while preserving the $4,250,000 liquid reserve and all product prohibitions. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
