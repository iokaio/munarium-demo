# Mesa Lantern Properties LLC Quarterly Financial Packet — 2021 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2021-Q4`
- Document type: `business_financial_packet`
- As-of date: 2021-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $415,145 |
| Cost of goods or clinical supplies | ($45,666) |
| Payroll and benefits | ($33,212) |
| Occupancy, marketing, and other operating expense | ($147,376) |
| **EBITDA / operating cash proxy** | **$188,891** |

## Balance-sheet and owner-cash items

- Cash: $557,857
- Accounts receivable: $66,665
- Interest-bearing debt: $3,754,000
- Owner distribution declared: $41,556
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. The household approved a $600,000 commitment to Aster Health Ventures I; the liquidity floor remained unchanged. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
