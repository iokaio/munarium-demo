# Mesa Lantern Properties LLC Quarterly Financial Packet — 2021 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2021-Q1`
- Document type: `business_financial_packet`
- As-of date: 2021-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $364,660 |
| Cost of goods or clinical supplies | ($40,113) |
| Payroll and benefits | ($29,173) |
| Occupancy, marketing, and other operating expense | ($129,454) |
| **EBITDA / operating cash proxy** | **$165,920** |

## Balance-sheet and owner-cash items

- Cash: $571,316
- Accounts receivable: $69,601
- Interest-bearing debt: $3,838,000
- Owner distribution declared: $36,503
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. The investment committee approved a $750,000 commitment to FrontRange Seed Fund III after cash-flow review. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
