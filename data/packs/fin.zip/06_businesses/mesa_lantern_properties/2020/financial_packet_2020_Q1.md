# Mesa Lantern Properties LLC Quarterly Financial Packet — 2020 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2020-Q1`
- Document type: `business_financial_packet`
- As-of date: 2020-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $359,666 |
| Cost of goods or clinical supplies | ($39,563) |
| Payroll and benefits | ($28,773) |
| Occupancy, marketing, and other operating expense | ($127,682) |
| **EBITDA / operating cash proxy** | **$163,648** |

## Balance-sheet and owner-cash items

- Cash: $487,201
- Accounts receivable: $57,699
- Interest-bearing debt: $3,950,000
- Owner distribution declared: $36,003
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. The household completed initial onboarding. Nora and Daniel prioritized resilience over return maximization. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
