# Mesa Lantern Properties LLC Quarterly Financial Packet — 2024 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2024-Q4`
- Document type: `business_financial_packet`
- As-of date: 2024-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $630,518 |
| Cost of goods or clinical supplies | ($69,357) |
| Payroll and benefits | ($50,441) |
| Occupancy, marketing, and other operating expense | ($223,834) |
| **EBITDA / operating cash proxy** | **$286,886** |

## Balance-sheet and owner-cash items

- Cash: $945,857
- Accounts receivable: $122,206
- Interest-bearing debt: $5,668,000
- Owner distribution declared: $63,115
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. Juniper Ridge acquired Trailhead Outfitters' online catalog for $900,000, financed with $400,000 cash and a $500,000 seller note. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
