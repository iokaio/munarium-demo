# Mesa Lantern Properties LLC Quarterly Financial Packet — 2024 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2024-Q1`
- Document type: `business_financial_packet`
- As-of date: 2024-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $586,955 |
| Cost of goods or clinical supplies | ($64,565) |
| Payroll and benefits | ($46,956) |
| Occupancy, marketing, and other operating expense | ($208,369) |
| **EBITDA / operating cash proxy** | **$267,064** |

## Balance-sheet and owner-cash items

- Cash: $776,850
- Accounts receivable: $77,168
- Interest-bearing debt: $5,752,000
- Owner distribution declared: $58,754
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. An analyst draft proposing a 12% private-credit allocation was rejected because it would have breached the liquidity floor and illiquidity cap. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
