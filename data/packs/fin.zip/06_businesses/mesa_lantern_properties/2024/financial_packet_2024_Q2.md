# Mesa Lantern Properties LLC Quarterly Financial Packet — 2024 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2024-Q2`
- Document type: `business_financial_packet`
- As-of date: 2024-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $654,498 |
| Cost of goods or clinical supplies | ($71,995) |
| Payroll and benefits | ($52,360) |
| Occupancy, marketing, and other operating expense | ($232,347) |
| **EBITDA / operating cash proxy** | **$297,797** |

## Balance-sheet and owner-cash items

- Cash: $891,677
- Accounts receivable: $132,633
- Interest-bearing debt: $5,724,000
- Owner distribution declared: $65,515
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. Nora assumed recurring care costs for her mother. Risk tolerance returned to moderate and the liquidity floor rose to $3,000,000; Kestrel Growth Fund I was approved only after this reserve was funded. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
