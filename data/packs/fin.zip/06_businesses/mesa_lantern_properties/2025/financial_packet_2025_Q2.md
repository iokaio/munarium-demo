# Mesa Lantern Properties LLC Quarterly Financial Packet — 2025 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2025-Q2`
- Document type: `business_financial_packet`
- As-of date: 2025-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $667,937 |
| Cost of goods or clinical supplies | ($73,473) |
| Payroll and benefits | ($53,435) |
| Occupancy, marketing, and other operating expense | ($237,118) |
| **EBITDA / operating cash proxy** | **$303,912** |

## Balance-sheet and owner-cash items

- Cash: $989,606
- Accounts receivable: $96,631
- Interest-bearing debt: $5,612,000
- Owner distribution declared: $66,861
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. Vale Dental signed a nonbinding letter of intent for a majority recapitalization. The clients lowered risk and raised the liquidity floor pending closing and tax estimates. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
