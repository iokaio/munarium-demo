# Mesa Lantern Properties LLC Preliminary Tax Summary — 2025

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `TAX-BIZ-MLP-2025`
- Document type: `business_tax_summary`
- As-of date: 2026-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Preliminary owner tax summary

- Entity: Mesa Lantern Properties LLC
- Tax year: 2025
- Federal tax classification: partnership
- Ownership reported for the Vale household: Nora Vale 50%; Daniel Vale 50%

| Tax workpaper item | Amount |
|---|---:|
| Gross receipts | $2,680,996 |
| EBITDA / operating cash proxy | $1,219,854 |
| Tax depreciation and amortization | ($482,579) |
| Interest expense | ($291,096) |
| Estimated ordinary business income | **$446,179** |
| Cash distributions to all owners | $268,367 |

## Reconciliation notes

Taxable income differs from cash distributions. The household tax organizer must use the final Schedule K-1, not this management estimate. Basis, passive-activity, at-risk, and state apportionment calculations remain with the tax preparer.

## Planning relevance

The advisory team may use this summary for preliminary estimated-tax and cash-flow planning, but may not count a projected distribution until it is declared. This document does not amend investment constraints.
