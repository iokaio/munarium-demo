# Mesa Lantern Properties LLC Quarterly Financial Packet — 2025 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-MLP-2025-Q3`
- Document type: `business_financial_packet`
- As-of date: 2025-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-MLP

## Entity and ownership

- Legal entity: Mesa Lantern Properties LLC
- Entity ID: BIZ-MLP
- Ownership at quarter end: Nora Vale 50%; Daniel Vale 50%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $698,036 |
| Cost of goods or clinical supplies | ($76,784) |
| Payroll and benefits | ($55,843) |
| Occupancy, marketing, and other operating expense | ($247,803) |
| **EBITDA / operating cash proxy** | **$317,606** |

## Balance-sheet and owner-cash items

- Cash: $1,080,345
- Accounts receivable: $156,773
- Interest-bearing debt: $5,584,000
- Owner distribution declared: $69,873
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Occupancy, rent collections, tenant rollover, debt service, and capital reserves were reviewed. A draft recommendation to raise public equities to 75% was rejected as outside the current moderate-conservative band. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
