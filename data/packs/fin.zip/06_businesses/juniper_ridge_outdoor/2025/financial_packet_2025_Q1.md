# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2025 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2025-Q1`
- Document type: `business_financial_packet`
- As-of date: 2025-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $909,464 |
| Cost of goods or clinical supplies | ($509,300) |
| Payroll and benefits | ($172,798) |
| Occupancy, marketing, and other operating expense | ($131,872) |
| **EBITDA / operating cash proxy** | **$95,494** |

## Balance-sheet and owner-cash items

- Cash: $441,605
- Accounts receivable: $125,221
- Interest-bearing debt: $430,000
- Owner distribution declared: $30,558
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. Juniper Ridge acquired Trailhead Outfitters' online catalog for $900,000, financed with $400,000 cash and a $500,000 seller note. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
