# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2025 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2025-Q4`
- Document type: `business_financial_packet`
- As-of date: 2025-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $1,023,496 |
| Cost of goods or clinical supplies | ($573,158) |
| Payroll and benefits | ($194,464) |
| Occupancy, marketing, and other operating expense | ($148,407) |
| **EBITDA / operating cash proxy** | **$107,467** |

## Balance-sheet and owner-cash items

- Cash: $498,746
- Accounts receivable: $211,527
- Interest-bearing debt: $325,000
- Owner distribution declared: $34,389
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. A draft recommendation to raise public equities to 75% was rejected as outside the current moderate-conservative band. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
