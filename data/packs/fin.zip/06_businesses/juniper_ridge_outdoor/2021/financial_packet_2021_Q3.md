# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2021 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2021-Q3`
- Document type: `business_financial_packet`
- As-of date: 2021-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $668,094 |
| Cost of goods or clinical supplies | ($374,132) |
| Payroll and benefits | ($126,938) |
| Occupancy, marketing, and other operating expense | ($96,874) |
| **EBITDA / operating cash proxy** | **$70,150** |

## Balance-sheet and owner-cash items

- Cash: $391,058
- Accounts receivable: $127,907
- Interest-bearing debt: $372,000
- Owner distribution declared: $22,448
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. The household approved a $600,000 commitment to Aster Health Ventures I; the liquidity floor remained unchanged. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
