# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2021 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2021-Q2`
- Document type: `business_financial_packet`
- As-of date: 2021-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $646,995 |
| Cost of goods or clinical supplies | ($362,317) |
| Payroll and benefits | ($122,929) |
| Occupancy, marketing, and other operating expense | ($93,814) |
| **EBITDA / operating cash proxy** | **$67,934** |

## Balance-sheet and owner-cash items

- Cash: $306,607
- Accounts receivable: $121,833
- Interest-bearing debt: $400,000
- Owner distribution declared: $21,739
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. The investment committee approved a $750,000 commitment to FrontRange Seed Fund III after cash-flow review. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
