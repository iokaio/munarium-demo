# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2020 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2020-Q2`
- Document type: `business_financial_packet`
- As-of date: 2020-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $482,667 |
| Cost of goods or clinical supplies | ($270,293) |
| Payroll and benefits | ($91,707) |
| Occupancy, marketing, and other operating expense | ($69,987) |
| **EBITDA / operating cash proxy** | **$50,680** |

## Balance-sheet and owner-cash items

- Cash: $326,259
- Accounts receivable: $79,221
- Interest-bearing debt: $512,000
- Owner distribution declared: $16,218
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. COVID-19 closures reduced dental production and retail traffic. The household formally lowered risk tolerance and doubled the liquidity floor. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
