# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2020 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2020-Q1`
- Document type: `business_financial_packet`
- As-of date: 2020-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $469,225 |
| Cost of goods or clinical supplies | ($262,766) |
| Payroll and benefits | ($89,153) |
| Occupancy, marketing, and other operating expense | ($68,038) |
| **EBITDA / operating cash proxy** | **$49,269** |

## Balance-sheet and owner-cash items

- Cash: $310,300
- Accounts receivable: $70,257
- Interest-bearing debt: $540,000
- Owner distribution declared: $15,766
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. The household completed initial onboarding. Nora and Daniel prioritized resilience over return maximization. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
