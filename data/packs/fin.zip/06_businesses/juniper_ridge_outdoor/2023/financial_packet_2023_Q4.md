# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2023 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2023-Q4`
- Document type: `business_financial_packet`
- As-of date: 2023-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $739,526 |
| Cost of goods or clinical supplies | ($414,135) |
| Payroll and benefits | ($140,510) |
| Occupancy, marketing, and other operating expense | ($107,231) |
| **EBITDA / operating cash proxy** | **$77,650** |

## Balance-sheet and owner-cash items

- Cash: $420,875
- Accounts receivable: $129,495
- Interest-bearing debt: $120,000
- Owner distribution declared: $24,848
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. An analyst draft proposing a 12% private-credit allocation was rejected because it would have breached the liquidity floor and illiquidity cap. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
