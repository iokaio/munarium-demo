# Juniper Ridge Outdoor Supply LLC Preliminary Tax Summary — 2022

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `TAX-BIZ-JRO-2022`
- Document type: `business_tax_summary`
- As-of date: 2023-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Preliminary owner tax summary

- Entity: Juniper Ridge Outdoor Supply LLC
- Tax year: 2022
- Federal tax classification: partnership
- Ownership reported for the Vale household: Daniel Vale 70%; Nora Vale 30%

| Tax workpaper item | Amount |
|---|---:|
| Gross receipts | $2,675,714 |
| EBITDA / operating cash proxy | $280,950 |
| Tax depreciation and amortization | ($93,650) |
| Interest expense | ($14,248) |
| Estimated ordinary business income | **$173,052** |
| Cash distributions to all owners | $89,904 |

## Reconciliation notes

Taxable income differs from cash distributions. The household tax organizer must use the final Schedule K-1, not this management estimate. Basis, passive-activity, at-risk, and state apportionment calculations remain with the tax preparer.

## Planning relevance

The advisory team may use this summary for preliminary estimated-tax and cash-flow planning, but may not count a projected distribution until it is declared. This document does not amend investment constraints.
