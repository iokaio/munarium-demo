# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2022 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2022-Q3`
- Document type: `business_financial_packet`
- As-of date: 2022-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $701,796 |
| Cost of goods or clinical supplies | ($393,006) |
| Payroll and benefits | ($133,341) |
| Occupancy, marketing, and other operating expense | ($101,760) |
| **EBITDA / operating cash proxy** | **$73,689** |

## Balance-sheet and owner-cash items

- Cash: $332,796
- Accounts receivable: $121,310
- Interest-bearing debt: $260,000
- Owner distribution declared: $23,580
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. Construction began on the Cresthaven residence. The documented two-year project budget is $2,400,000, so the liquid-asset floor increased to $2,500,000. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
