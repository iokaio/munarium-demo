# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2022 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2022-Q2`
- Document type: `business_financial_packet`
- As-of date: 2022-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $679,077 |
| Cost of goods or clinical supplies | ($380,283) |
| Payroll and benefits | ($129,025) |
| Occupancy, marketing, and other operating expense | ($98,466) |
| **EBITDA / operating cash proxy** | **$71,303** |

## Balance-sheet and owner-cash items

- Cash: $367,396
- Accounts receivable: $140,061
- Interest-bearing debt: $288,000
- Owner distribution declared: $22,817
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. Mesa Lantern acquired the Bellwether Commerce Center and the household committed $1,000,000 to Northline Climate Partners II. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
