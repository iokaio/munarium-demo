# Juniper Ridge Outdoor Supply LLC Quarterly Financial Packet — 2024 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `FIN-BIZ-JRO-2024-Q2`
- Document type: `business_financial_packet`
- As-of date: 2024-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Entity and ownership

- Legal entity: Juniper Ridge Outdoor Supply LLC
- Entity ID: BIZ-JRO
- Ownership at quarter end: Daniel Vale 70%; Nora Vale 30%

## Quarterly income summary

| Line item | Amount |
|---|---:|
| Revenue | $794,178 |
| Cost of goods or clinical supplies | ($444,740) |
| Payroll and benefits | ($150,894) |
| Occupancy, marketing, and other operating expense | ($115,156) |
| **EBITDA / operating cash proxy** | **$83,389** |

## Balance-sheet and owner-cash items

- Cash: $424,349
- Accounts receivable: $107,134
- Interest-bearing debt: $64,000
- Owner distribution declared: $26,684
- Distribution is a business cash-flow item, not guaranteed household income.

## Management commentary

Retail traffic, online conversion, inventory turns, seasonal purchasing, and the Trailhead catalog integration were reviewed. Nora assumed recurring care costs for her mother. Risk tolerance returned to moderate and the liquidity floor rose to $3,000,000; Kestrel Growth Fund I was approved only after this reserve was funded. No business cash balance is counted toward the household's personal liquidity floor unless a distribution has been legally declared and paid.

## Advisory relevance

This entity contributes concentration, income variability, and potential capital needs to the household profile. The adviser must not treat the enterprise value as a liquid security or infer a higher personal risk tolerance from a strong quarter.
