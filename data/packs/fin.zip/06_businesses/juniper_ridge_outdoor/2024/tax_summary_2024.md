# Juniper Ridge Outdoor Supply LLC Preliminary Tax Summary — 2024

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `TAX-BIZ-JRO-2024`
- Document type: `business_tax_summary`
- As-of date: 2025-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, BIZ-JRO

## Preliminary owner tax summary

- Entity: Juniper Ridge Outdoor Supply LLC
- Tax year: 2024
- Federal tax classification: partnership
- Ownership reported for the Vale household: Daniel Vale 70%; Nora Vale 30%

| Tax workpaper item | Amount |
|---|---:|
| Gross receipts | $3,438,785 |
| EBITDA / operating cash proxy | $361,073 |
| Tax depreciation and amortization | ($120,357) |
| Interest expense | ($15,145) |
| Estimated ordinary business income | **$225,571** |
| Cash distributions to all owners | $115,543 |

## Reconciliation notes

Taxable income differs from cash distributions. The household tax organizer must use the final Schedule K-1, not this management estimate. Basis, passive-activity, at-risk, and state apportionment calculations remain with the tax preparer.

## Planning relevance

The advisory team may use this summary for preliminary estimated-tax and cash-flow planning, but may not count a projected distribution until it is declared. This document does not amend investment constraints.
