# Copperline Industrial Partners LLC Monthly Operating Report — October 2016

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2016-10`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2016-10-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## October 2016 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $220,589 |
| Property operating expense | ($43,558) |
| On-site payroll and management | ($9,933) |
| Insurance, tax accrual, and administration | ($28,127) |
| **Net operating income** | **$138,971** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $547,408 |
| Net Operating Income | $138,971 |
| Interest and scheduled principal | ($28,131) |
| Recurring capital expenditure | ($5,568) |
| Owner distribution | ($75,796) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$576,884** |

- Beginning debt: $3,608,000
- New debt funded: $0
- Ending debt: $3,594,000

## Operating indicators

- Economic occupancy: 91.4%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
