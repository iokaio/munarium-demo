# Copperline Industrial Partners LLC Monthly Operating Report — July 2016

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2016-07`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2016-07-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## July 2016 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $227,257 |
| Property operating expense | ($41,305) |
| On-site payroll and management | ($10,338) |
| Insurance, tax accrual, and administration | ($32,442) |
| **Net operating income** | **$143,172** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $460,000 |
| Net Operating Income | $143,172 |
| Interest and scheduled principal | ($28,296) |
| Recurring capital expenditure | ($3,816) |
| Owner distribution | ($79,963) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$491,097** |

- Beginning debt: $3,650,000
- New debt funded: $0
- Ending debt: $3,636,000

## Operating indicators

- Economic occupancy: 93.4%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Material event: Forge Park I acquisition. The closing is documented separately and does not itself change household investment-policy constraints. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
