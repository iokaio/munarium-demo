# Copperline Industrial Partners LLC Monthly Operating Report — August 2016

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2016-08`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2016-08-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## August 2016 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $229,191 |
| Property operating expense | ($40,155) |
| On-site payroll and management | ($10,924) |
| Insurance, tax accrual, and administration | ($33,721) |
| **Net operating income** | **$144,391** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $491,097 |
| Net Operating Income | $144,391 |
| Interest and scheduled principal | ($28,241) |
| Recurring capital expenditure | ($3,615) |
| Owner distribution | ($81,025) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$522,607** |

- Beginning debt: $3,636,000
- New debt funded: $0
- Ending debt: $3,622,000

## Operating indicators

- Economic occupancy: 96.1%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was tenant renewals. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
