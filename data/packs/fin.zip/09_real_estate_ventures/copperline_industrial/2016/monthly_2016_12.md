# Copperline Industrial Partners LLC Monthly Operating Report — December 2016

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2016-12`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2016-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## December 2016 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $233,988 |
| Property operating expense | ($42,623) |
| On-site payroll and management | ($13,137) |
| Insurance, tax accrual, and administration | ($30,815) |
| **Net operating income** | **$147,413** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $607,872 |
| Net Operating Income | $147,413 |
| Interest and scheduled principal | ($28,022) |
| Recurring capital expenditure | ($7,095) |
| Owner distribution | ($87,591) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$632,577** |

- Beginning debt: $3,580,000
- New debt funded: $0
- Ending debt: $3,566,000

## Operating indicators

- Economic occupancy: 93.3%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was tenant renewals. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
