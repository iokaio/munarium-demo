# Copperline Industrial Partners LLC Monthly Operating Report — November 2020

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2020-11`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2020-11-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## November 2020 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $388,274 |
| Property operating expense | ($72,354) |
| On-site payroll and management | ($20,645) |
| Insurance, tax accrual, and administration | ($50,663) |
| **Net operating income** | **$244,612** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $2,384,664 |
| Net Operating Income | $244,612 |
| Interest and scheduled principal | ($45,615) |
| Recurring capital expenditure | ($12,115) |
| Owner distribution | ($134,555) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$2,436,991** |

- Beginning debt: $8,072,000
- New debt funded: $0
- Ending debt: $8,058,000

## Operating indicators

- Economic occupancy: 96.0%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was loading-bay utilization. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
