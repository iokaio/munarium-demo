# Copperline Industrial Partners LLC Monthly Operating Report — April 2020

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2020-04`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2020-04-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## April 2020 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $403,110 |
| Property operating expense | ($73,361) |
| On-site payroll and management | ($19,098) |
| Insurance, tax accrual, and administration | ($56,692) |
| **Net operating income** | **$253,959** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $2,025,092 |
| Net Operating Income | $253,959 |
| Interest and scheduled principal | ($45,999) |
| Recurring capital expenditure | ($9,070) |
| Owner distribution | ($143,201) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$2,080,781** |

- Beginning debt: $8,170,000
- New debt funded: $0
- Ending debt: $8,156,000

## Operating indicators

- Economic occupancy: 90.8%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was tenant renewals. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
