# Copperline Industrial Partners LLC Quarterly Asset Management Report — 2020 Q2

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `QTR-RE-CIP-2020-Q2`
- Document type: `real_estate_quarterly_asset_management_report`
- As-of date: 2020-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Review scope

- Entity: Copperline Industrial Partners LLC (`RE-CIP`)
- Majority owner: Daniel Vale
- Ownership: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Reporting body: asset-management committee

## Quarterly consolidated results

| Measure | Quarter total |
|---|---:|
| Revenue | $1,187,482 |
| Direct/property costs | ($222,379) |
| Payroll and on-site management | ($60,545) |
| Other operating expense | ($156,445) |
| **NOI** | **$748,113** |
| Debt service | ($137,833) |
| Capital expenditure | ($31,635) |
| Owner distributions | ($428,264) |

## Balance sheet and covenant review

- Quarter-end operating cash: $2,175,473
- Quarter-end interest-bearing debt: $8,128,000
- NOI-to-debt-service ratio: 5.43x
- Owner capital contributed during quarter: $0
- Distribution status: permitted by operating cash flow, subject to lender tests

## Household advisory treatment

Distributions are counted as household cash only after payment. Enterprise and property values remain illiquid and concentrated. The entity report does not amend the signed Vale household risk band, product prohibitions, growth-asset cap, or liquidity floor.
