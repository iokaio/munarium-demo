# Copperline Industrial Partners LLC Monthly Operating Report — June 2020

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2020-06`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2020-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## June 2020 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $398,923 |
| Property operating expense | ($71,094) |
| On-site payroll and management | ($22,738) |
| Insurance, tax accrual, and administration | ($53,770) |
| **Net operating income** | **$251,321** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $2,132,797 |
| Net Operating Income | $251,321 |
| Interest and scheduled principal | ($45,890) |
| Recurring capital expenditure | ($11,449) |
| Owner distribution | ($151,306) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$2,175,473** |

- Beginning debt: $8,142,000
- New debt funded: $0
- Ending debt: $8,128,000

## Operating indicators

- Economic occupancy: 95.2%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
