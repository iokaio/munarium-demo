# Copperline Industrial Partners LLC Preliminary Tax Summary — 2018

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VTAX-RE-CIP-2018`
- Document type: `venture_business_tax_summary`
- As-of date: 2019-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP, CPA-LUIS-ORTEGA

## Preliminary pass-through tax schedule

- Entity: Copperline Industrial Partners LLC
- Tax year: 2018
- Federal classification: partnership
- Daniel Vale ownership at year end: Daniel Vale 68%

| Workpaper item | Amount |
|---|---:|
| Gross revenue | $2,884,095 |
| Net operating income | $1,816,980 |
| Interest expense | ($156,087) |
| Tax depreciation and amortization | ($461,455) |
| Estimated ordinary income before special allocations | **$1,199,438** |
| Cash distributions to all owners | $1,054,997 |

## Tax and planning notes

This schedule is preliminary until final K-1 preparation. Taxable income, basis, at-risk amounts, passive losses, depreciation recapture, and debt allocations are not interchangeable with cash distributions. The advisory team may reserve for estimated tax but may not treat entity cash or tax basis as personal liquidity.
