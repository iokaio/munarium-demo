# Copperline Industrial Partners LLC Monthly Operating Report — February 2018

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2018-02`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2018-02-28
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## February 2018 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $229,487 |
| Property operating expense | ($45,329) |
| On-site payroll and management | ($10,370) |
| Insurance, tax accrual, and administration | ($29,211) |
| **Net operating income** | **$144,577** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,022,000 |
| Net Operating Income | $144,577 |
| Interest and scheduled principal | ($27,254) |
| Recurring capital expenditure | ($6,482) |
| Owner distribution | ($79,806) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,053,035** |

- Beginning debt: $3,384,000
- New debt funded: $0
- Ending debt: $3,370,000

## Operating indicators

- Economic occupancy: 93.8%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
