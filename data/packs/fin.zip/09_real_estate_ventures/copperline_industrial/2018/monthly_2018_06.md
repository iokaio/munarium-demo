# Copperline Industrial Partners LLC Monthly Operating Report — June 2018

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2018-06`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2018-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## June 2018 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $242,751 |
| Property operating expense | ($44,265) |
| On-site payroll and management | ($13,849) |
| Insurance, tax accrual, and administration | ($31,704) |
| **Net operating income** | **$152,933** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,147,984 |
| Net Operating Income | $152,933 |
| Interest and scheduled principal | ($27,035) |
| Recurring capital expenditure | ($6,245) |
| Owner distribution | ($93,329) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,174,308** |

- Beginning debt: $3,328,000
- New debt funded: $0
- Ending debt: $3,314,000

## Operating indicators

- Economic occupancy: 92.3%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
