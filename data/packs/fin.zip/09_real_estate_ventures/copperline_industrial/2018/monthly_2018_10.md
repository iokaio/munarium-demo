# Copperline Industrial Partners LLC Monthly Operating Report — October 2018

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2018-10`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2018-10-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## October 2018 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $246,213 |
| Property operating expense | ($44,412) |
| On-site payroll and management | ($14,526) |
| Insurance, tax accrual, and administration | ($32,161) |
| **Net operating income** | **$155,114** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,267,847 |
| Net Operating Income | $155,114 |
| Interest and scheduled principal | ($26,815) |
| Recurring capital expenditure | ($5,735) |
| Owner distribution | ($88,246) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,302,165** |

- Beginning debt: $3,272,000
- New debt funded: $0
- Ending debt: $3,258,000

## Operating indicators

- Economic occupancy: 93.7%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
