# Copperline Industrial Partners LLC Monthly Operating Report — July 2018

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2018-07`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2018-07-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## July 2018 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $248,338 |
| Property operating expense | ($46,017) |
| On-site payroll and management | ($11,380) |
| Insurance, tax accrual, and administration | ($34,488) |
| **Net operating income** | **$156,453** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,174,308 |
| Net Operating Income | $156,453 |
| Interest and scheduled principal | ($26,980) |
| Recurring capital expenditure | ($6,870) |
| Owner distribution | ($88,274) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,208,637** |

- Beginning debt: $3,314,000
- New debt funded: $0
- Ending debt: $3,300,000

## Operating indicators

- Economic occupancy: 95.4%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was loading-bay utilization. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
