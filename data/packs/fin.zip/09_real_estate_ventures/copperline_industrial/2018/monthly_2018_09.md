# Copperline Industrial Partners LLC Monthly Operating Report — September 2018

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2018-09`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2018-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## September 2018 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $238,062 |
| Property operating expense | ($43,296) |
| On-site payroll and management | ($13,964) |
| Insurance, tax accrual, and administration | ($30,823) |
| **Net operating income** | **$149,979** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,241,711 |
| Net Operating Income | $149,979 |
| Interest and scheduled principal | ($26,870) |
| Recurring capital expenditure | ($4,310) |
| Owner distribution | ($92,663) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,267,847** |

- Beginning debt: $3,286,000
- New debt funded: $0
- Ending debt: $3,272,000

## Operating indicators

- Economic occupancy: 92.5%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was roof and paving reserves. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
