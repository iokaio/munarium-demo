# Copperline Industrial Partners LLC Monthly Operating Report — October 2017

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2017-10`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2017-10-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## October 2017 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $240,986 |
| Property operating expense | ($49,272) |
| On-site payroll and management | ($13,396) |
| Insurance, tax accrual, and administration | ($26,497) |
| **Net operating income** | **$151,821** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $897,381 |
| Net Operating Income | $151,821 |
| Interest and scheduled principal | ($27,473) |
| Recurring capital expenditure | ($5,991) |
| Owner distribution | ($85,217) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$930,521** |

- Beginning debt: $3,440,000
- New debt funded: $0
- Ending debt: $3,426,000

## Operating indicators

- Economic occupancy: 89.8%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
