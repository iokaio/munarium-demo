# Copperline Industrial Partners LLC Quarterly Asset Management Report — 2017 Q4

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `QTR-RE-CIP-2017-Q4`
- Document type: `real_estate_quarterly_asset_management_report`
- As-of date: 2017-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Review scope

- Entity: Copperline Industrial Partners LLC (`RE-CIP`)
- Majority owner: Daniel Vale
- Ownership: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Reporting body: asset-management committee

## Quarterly consolidated results

| Measure | Quarter total |
|---|---:|
| Revenue | $728,667 |
| Direct/property costs | ($140,625) |
| Payroll and on-site management | ($42,797) |
| Other operating expense | ($86,185) |
| **NOI** | **$459,060** |
| Debt service | ($82,255) |
| Capital expenditure | ($15,515) |
| Owner distributions | ($267,476) |

## Balance sheet and covenant review

- Quarter-end operating cash: $991,195
- Quarter-end interest-bearing debt: $3,398,000
- NOI-to-debt-service ratio: 5.58x
- Owner capital contributed during quarter: $0
- Distribution status: permitted by operating cash flow, subject to lender tests

## Household advisory treatment

Distributions are counted as household cash only after payment. Enterprise and property values remain illiquid and concentrated. The entity report does not amend the signed Vale household risk band, product prohibitions, growth-asset cap, or liquidity floor.
