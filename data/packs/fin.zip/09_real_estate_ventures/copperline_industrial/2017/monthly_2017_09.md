# Copperline Industrial Partners LLC Monthly Operating Report — September 2017

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2017-09`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2017-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## September 2017 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $233,580 |
| Property operating expense | ($47,112) |
| On-site payroll and management | ($13,802) |
| Insurance, tax accrual, and administration | ($25,510) |
| **Net operating income** | **$147,156** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $872,540 |
| Net Operating Income | $147,156 |
| Interest and scheduled principal | ($27,528) |
| Recurring capital expenditure | ($6,714) |
| Owner distribution | ($88,073) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$897,381** |

- Beginning debt: $3,454,000
- New debt funded: $0
- Ending debt: $3,440,000

## Operating indicators

- Economic occupancy: 91.8%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was roof and paving reserves. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
