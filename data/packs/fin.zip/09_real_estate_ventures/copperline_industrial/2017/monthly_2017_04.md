# Copperline Industrial Partners LLC Monthly Operating Report — April 2017

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2017-04`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2017-04-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## April 2017 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $233,829 |
| Property operating expense | ($47,296) |
| On-site payroll and management | ($10,954) |
| Insurance, tax accrual, and administration | ($28,266) |
| **Net operating income** | **$147,313** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $719,710 |
| Net Operating Income | $147,313 |
| Interest and scheduled principal | ($27,802) |
| Recurring capital expenditure | ($6,628) |
| Owner distribution | ($81,276) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$751,317** |

- Beginning debt: $3,524,000
- New debt funded: $0
- Ending debt: $3,510,000

## Operating indicators

- Economic occupancy: 90.3%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was tenant renewals. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
