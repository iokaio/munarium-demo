# Copperline Industrial Partners LLC Monthly Operating Report — February 2017

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2017-02`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2017-02-28
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## February 2017 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $231,977 |
| Property operating expense | ($47,419) |
| On-site payroll and management | ($11,336) |
| Insurance, tax accrual, and administration | ($27,076) |
| **Net operating income** | **$146,146** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $662,926 |
| Net Operating Income | $146,146 |
| Interest and scheduled principal | ($27,912) |
| Recurring capital expenditure | ($3,979) |
| Owner distribution | ($82,264) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$694,917** |

- Beginning debt: $3,552,000
- New debt funded: $0
- Ending debt: $3,538,000

## Operating indicators

- Economic occupancy: 89.4%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
