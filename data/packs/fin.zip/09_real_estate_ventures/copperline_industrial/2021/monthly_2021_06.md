# Copperline Industrial Partners LLC Monthly Operating Report — June 2021

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2021-06`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2021-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## June 2021 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $404,476 |
| Property operating expense | ($80,191) |
| On-site payroll and management | ($19,504) |
| Insurance, tax accrual, and administration | ($49,962) |
| **Net operating income** | **$254,819** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $2,748,033 |
| Net Operating Income | $254,819 |
| Interest and scheduled principal | ($45,232) |
| Recurring capital expenditure | ($12,033) |
| Owner distribution | ($154,092) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$2,791,495** |

- Beginning debt: $7,974,000
- New debt funded: $0
- Ending debt: $7,960,000

## Operating indicators

- Economic occupancy: 93.2%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
