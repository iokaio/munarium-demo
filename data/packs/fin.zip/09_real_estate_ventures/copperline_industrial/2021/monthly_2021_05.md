# Copperline Industrial Partners LLC Monthly Operating Report — May 2021

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2021-05`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2021-05-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## May 2021 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $412,983 |
| Property operating expense | ($80,647) |
| On-site payroll and management | ($23,433) |
| Insurance, tax accrual, and administration | ($48,724) |
| **Net operating income** | **$260,179** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $2,691,269 |
| Net Operating Income | $260,179 |
| Interest and scheduled principal | ($45,286) |
| Recurring capital expenditure | ($12,166) |
| Owner distribution | ($145,963) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$2,748,033** |

- Beginning debt: $7,988,000
- New debt funded: $0
- Ending debt: $7,974,000

## Operating indicators

- Economic occupancy: 93.2%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was roof and paving reserves. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
