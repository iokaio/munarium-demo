# Copperline Industrial Partners LLC Monthly Operating Report — January 2021

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2021-01`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2021-01-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## January 2021 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $393,115 |
| Property operating expense | ($69,909) |
| On-site payroll and management | ($20,521) |
| Insurance, tax accrual, and administration | ($55,023) |
| **Net operating income** | **$247,662** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $2,481,278 |
| Net Operating Income | $247,662 |
| Interest and scheduled principal | ($45,506) |
| Recurring capital expenditure | ($11,554) |
| Owner distribution | ($137,233) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$2,534,647** |

- Beginning debt: $8,044,000
- New debt funded: $0
- Ending debt: $8,030,000

## Operating indicators

- Economic occupancy: 94.6%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was roof and paving reserves. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
