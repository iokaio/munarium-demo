# Copperline Industrial Partners LLC Quarterly Asset Management Report — 2021 Q2

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `QTR-RE-CIP-2021-Q2`
- Document type: `real_estate_quarterly_asset_management_report`
- As-of date: 2021-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Review scope

- Entity: Copperline Industrial Partners LLC (`RE-CIP`)
- Majority owner: Daniel Vale
- Ownership: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Reporting body: asset-management committee

## Quarterly consolidated results

| Measure | Quarter total |
|---|---:|
| Revenue | $1,231,424 |
| Direct/property costs | ($244,955) |
| Payroll and on-site management | ($62,754) |
| Other operating expense | ($147,919) |
| **NOI** | **$775,796** |
| Debt service | ($135,859) |
| Capital expenditure | ($34,193) |
| Owner distributions | ($447,988) |

## Balance sheet and covenant review

- Quarter-end operating cash: $2,791,495
- Quarter-end interest-bearing debt: $7,960,000
- NOI-to-debt-service ratio: 5.71x
- Owner capital contributed during quarter: $0
- Distribution status: permitted by operating cash flow, subject to lender tests

## Household advisory treatment

Distributions are counted as household cash only after payment. Enterprise and property values remain illiquid and concentrated. The entity report does not amend the signed Vale household risk band, product prohibitions, growth-asset cap, or liquidity floor.
