# Copperline Industrial Partners LLC Monthly Operating Report — October 2019

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2019-10`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2019-10-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## October 2019 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $396,253 |
| Property operating expense | ($70,961) |
| On-site payroll and management | ($20,636) |
| Insurance, tax accrual, and administration | ($55,017) |
| **Net operating income** | **$249,639** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,729,721 |
| Net Operating Income | $249,639 |
| Interest and scheduled principal | ($46,328) |
| Recurring capital expenditure | ($10,232) |
| Owner distribution | ($139,017) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,783,783** |

- Beginning debt: $8,254,000
- New debt funded: $0
- Ending debt: $8,240,000

## Operating indicators

- Economic occupancy: 90.1%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
