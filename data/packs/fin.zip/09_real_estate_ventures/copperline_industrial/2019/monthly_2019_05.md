# Copperline Industrial Partners LLC Monthly Operating Report — May 2019

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2019-05`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2019-05-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## May 2019 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $382,729 |
| Property operating expense | ($74,195) |
| On-site payroll and management | ($19,430) |
| Insurance, tax accrual, and administration | ($47,984) |
| **Net operating income** | **$241,120** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,490,644 |
| Net Operating Income | $241,120 |
| Interest and scheduled principal | ($36,517) |
| Recurring capital expenditure | ($11,870) |
| Owner distribution | ($138,768) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,544,609** |

- Beginning debt: $3,174,000
- New debt funded: $5,150,000
- Ending debt: $8,310,000

## Operating indicators

- Economic occupancy: 95.9%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Material event: Forge Park II acquisition. The closing is documented separately and does not itself change household investment-policy constraints. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
