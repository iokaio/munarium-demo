# Copperline Industrial Partners LLC Monthly Operating Report — February 2019

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `MONTH-RE-CIP-2019-02`
- Document type: `real_estate_monthly_operating_report`
- As-of date: 2019-02-28
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP

## Entity and ownership

- Legal entity: Copperline Industrial Partners LLC
- Entity ID: RE-CIP
- Majority owner: **Daniel Vale**
- Ownership at month end: Daniel Vale 68%; Nora Vale 8%; outside investors 24%
- Operations: multi-tenant light-industrial and last-mile flex space

## February 2019 operating statement

| Line item | Amount |
|---|---:|
| Revenue | $243,172 |
| Property operating expense | ($46,758) |
| On-site payroll and management | ($11,517) |
| Insurance, tax accrual, and administration | ($31,698) |
| **Net operating income** | **$153,199** |

## Cash and debt roll-forward

| Cash-flow item | Amount |
|---|---:|
| Beginning operating cash | $1,395,636 |
| Net Operating Income | $153,199 |
| Interest and scheduled principal | ($26,596) |
| Recurring capital expenditure | ($4,175) |
| Owner distribution | ($88,148) |
| Relief proceeds or insurance recovery | $0 |
| Owner capital contribution | $0 |
| **Ending operating cash** | **$1,429,916** |

- Beginning debt: $3,216,000
- New debt funded: $0
- Ending debt: $3,202,000

## Operating indicators

- Economic occupancy: 94.0%
- Portfolio: Forge Park I, Forge Park II, Meridian Yard, and North Loop Flex

## Management commentary

Management's monthly focus was leasing commissions. Results remain an entity-level operating record, not a statement of personal liquidity. Daniel's majority ownership creates economic concentration, but company cash, property equity, deposits, and undrawn facilities are not personal liquid assets.
