# Copperline Industrial Partners LLC Preliminary Tax Summary — 2019

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VTAX-RE-CIP-2019`
- Document type: `venture_business_tax_summary`
- As-of date: 2020-02-15
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless explicitly labeled preliminary, draft, or superseded
- Entities: HH-VALE-001, PERSON-DANIEL-VALE, RE-CIP, CPA-LUIS-ORTEGA

## Preliminary pass-through tax schedule

- Entity: Copperline Industrial Partners LLC
- Tax year: 2019
- Federal classification: partnership
- Daniel Vale ownership at year end: Daniel Vale 68%

| Workpaper item | Amount |
|---|---:|
| Gross revenue | $4,059,318 |
| Net operating income | $2,557,371 |
| Interest expense | ($299,472) |
| Tax depreciation and amortization | ($649,491) |
| Estimated ordinary income before special allocations | **$1,608,408** |
| Cash distributions to all owners | $1,472,773 |

## Tax and planning notes

This schedule is preliminary until final K-1 preparation. Taxable income, basis, at-risk amounts, passive losses, depreciation recapture, and debt allocations are not interchangeable with cash distributions. The advisory team may reserve for estimated tax but may not treat entity cash or tax basis as personal liquidity.
