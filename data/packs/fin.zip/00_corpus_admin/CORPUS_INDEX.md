# Vale Family Ten-Year Financial Advisory Corpus

> **Synthetic fixture.** All people, entities, properties, account numbers, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Purpose

This corpus supports long-horizon financial-advisory, retrieval, canonical-memory, contradiction, and suitability-drift experiments. It follows the fictional Vale household for exactly 120 months, from July 2016 through June 2026.

## Scale and scope

- Financial documents: **1,232**
- Coverage: **2016-07-31 through 2026-06-30** (120 months / 40 quarters)
- Existing advisory picture retained: three liquid portfolios, four original businesses, five VC engagements, taxes, insurance, signed constraints, profiles, and quarterly recommendations
- Real-estate expansion: Copperline Industrial Partners and Harbor Pine Residential Holdings
- Hospitality expansion: Ember & Pine Hospitality, High Mesa Lodging, and Bluebird Events & Catering
- Daniel Vale remains majority shareholder of all five expansion ventures throughout their documented lives.

## Canonical reading rules

1. The latest signed quarterly constraint sheet in `03_constraints/` governs personal risk, liquidity, product prohibitions, concentration limits, and illiquidity limits.
2. Company cash, lender reserves, restricted deposits, property equity, undrawn debt, and forecast distributions never count toward the household liquidity floor.
3. Monthly reports roll cash and debt forward; quarterly reports aggregate the three underlying months; annual tax summaries are preliminary until final K-1 preparation.
4. Transaction records change entity ownership, debt, or operations only when explicitly effective. They do not change the household investment profile.
5. Rejected proposals remain noncanonical.

## Folder map

- `01_client_profile/`–`08_tax_insurance/`: original 2020–2026 advisory corpus
- `09_real_estate_ventures/`: monthly, quarterly, and annual records for two majority-owned property ventures
- `10_hospitality_ventures/`: monthly, quarterly, and annual records for three majority-owned hospitality ventures
- `11_transactions_and_financing/`: 20 acquisitions, recapitalizations, modifications, and facilities
- `12_historical_household/`: pre-onboarding personal, advisory, tax, estate, and insurance history
- `13_consolidated_business_interests/`: annual ownership, valuation, exposure, and liquidity schedules

## Document inventory

| Document type | Count |
|---|---:|
| advisory_meeting_note | 26 |
| business_financial_packet | 104 |
| business_tax_summary | 24 |
| client_profile | 7 |
| consolidated_business_interest_schedule | 11 |
| historical_advisory_review | 4 |
| historical_estate_insurance_review | 4 |
| historical_household_tax_organizer | 4 |
| historical_personal_financial_statement | 4 |
| hospitality_monthly_operating_report | 327 |
| hospitality_quarterly_board_packet | 109 |
| household_net_worth_statement | 7 |
| household_tax_organizer | 6 |
| insurance_review | 4 |
| investment_policy_statement | 7 |
| portfolio_allocation_review | 21 |
| portfolio_statement | 78 |
| real_estate_monthly_operating_report | 222 |
| real_estate_quarterly_asset_management_report | 74 |
| signed_constraints_sheet | 26 |
| venture_business_tax_summary | 45 |
| venture_capital_capital_call_notice | 9 |
| venture_capital_distribution_notice | 3 |
| venture_capital_quarterly_report | 86 |
| venture_transaction_financing_record | 20 |

Machine-readable paths, dates, types, entity IDs, tags, ownership scope, and validation totals are in `manifest.json`.
