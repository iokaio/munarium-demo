# Vale Family Insurance Review — 2024

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `INS-2024`
- Document type: `insurance_review`
- As-of date: 2024-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, PERSON-NORA-VALE, PERSON-DANIEL-VALE

## Coverage inventory

| Coverage | Insured / owner | Limit or benefit | Planning note |
|---|---|---:|---|
| Term life | Nora Vale / Daniel Vale beneficiary | $4,000,000 | Level term through 2032 |
| Term life | Daniel Vale / Nora Vale beneficiary | $3,000,000 | Level term through 2032 |
| Own-occupation disability | Nora Vale | $18,000 monthly | Coordinates with practice overhead coverage |
| Key-person life | Vale Dental Group on Nora Vale | $3,000,000 | Reduced after majority recapitalization |
| Personal umbrella liability | Vale household | $10,000,000 | Increased with property and board exposure |
| Long-term care hybrid policies | Nora and Daniel Vale | $300 daily each | Six-year initial benefit pool |

## Review findings

Beneficiary designations match the current estate summary. Business policies are not personal liquid assets. The adviser should revisit disability and key-person coverage after any change in Nora's clinical role, and should maintain high umbrella limits while the family owns rental property and serves on private-company boards.

## Suitability relevance

Insurance reduces selected catastrophic risks but does not justify exceeding investment-risk limits. Policy cash values, where any exist, are excluded from the household's readily available liquidity floor.
