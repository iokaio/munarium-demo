# Vale Family Tax Organizer — 2025

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `HHTAX-2025`
- Document type: `household_tax_organizer`
- As-of date: 2026-02-28
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, CPA-LUIS-ORTEGA

## Preliminary household tax inputs

- Tax year: 2025
- Filing status: married filing jointly
- State of residence: Colorado
- This organizer is a planning compilation; filed returns and final K-1s control.

| Input category | Preliminary amount |
|---|---:|
| W-2 wages and guaranteed payments | $550,000 |
| Estimated pass-through business income before final K-1 adjustments | $3,214,244 |
| Realized capital gains and transaction gains | $137,484 |
| Charitable gifts | $185,000 |
| Federal and state estimated payments made | $1,131,501 |

## Open items

- Await final K-1s from all operating businesses and venture vehicles.
- Reconcile basis, passive losses, qualified business income, and state apportionment.
- Confirm tax-lot detail for charitable gifts and realized gains.
- Refresh fourth-quarter estimates after final business distributions and capital gains are known.

## Advisory constraint

Amounts reserved for estimated taxes are unavailable for investment rebalancing or new private commitments. This organizer does not itself amend the signed liquidity floor.
