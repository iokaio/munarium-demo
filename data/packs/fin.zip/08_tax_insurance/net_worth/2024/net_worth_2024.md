# Vale Family Net Worth Statement — 2024

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `NW-2024`
- Document type: `household_net_worth_statement`
- As-of date: 2024-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001

## Household balance sheet

| Asset or liability category | Estimated value |
|---|---:|
| Three liquid investment portfolios | $14,406,769 |
| Venture and private-fund reported NAV | $3,074,699 |
| Closely held business interests | $13,345,136 |
| Residence and investment real estate | $8,600,000 |
| Personal bank cash outside portfolios | $540,000 |
| Mortgages, entity debt attributable to owners, and seller notes | ($6,990,000) |
| **Estimated household net worth** | **$32,976,604** |

## Valuation limitations

Business and private-fund values are planning estimates, not realizable cash. Entity debt and property ownership are simplified for household planning. The net-worth total must not be substituted for liquidity, risk capacity, or an account statement.

## Planning conclusions

The household remains economically concentrated in Vale Dental, Juniper Ridge, Colorado commercial property, and venture funds. The current signed constraint sheet requires $3,000,000 of readily available assets regardless of estimated net worth.

## Consolidated venture cross-reference

The `BIZSCHED-2024` supporting schedule provides the entity-by-entity breakdown of Daniel's two majority-owned real-estate ventures and three majority-owned hospitality ventures. The net-worth category is a planning estimate; operating cash, restricted reserves, appraised property value, and undrawn credit remain unavailable for the signed personal liquidity floor.
