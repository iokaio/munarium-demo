# Vale Family Net Worth Statement — 2021

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `NW-2021`
- Document type: `household_net_worth_statement`
- As-of date: 2021-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001

## Household balance sheet

| Asset or liability category | Estimated value |
|---|---:|
| Three liquid investment portfolios | $13,375,852 |
| Venture and private-fund reported NAV | $515,117 |
| Closely held business interests | $10,438,649 |
| Residence and investment real estate | $4,200,000 |
| Personal bank cash outside portfolios | $270,000 |
| Mortgages, entity debt attributable to owners, and seller notes | ($5,110,000) |
| **Estimated household net worth** | **$23,689,618** |

## Valuation limitations

Business and private-fund values are planning estimates, not realizable cash. Entity debt and property ownership are simplified for household planning. The net-worth total must not be substituted for liquidity, risk capacity, or an account statement.

## Planning conclusions

The household remains economically concentrated in Vale Dental, Juniper Ridge, Colorado commercial property, and venture funds. The current signed constraint sheet requires $1,500,000 of readily available assets regardless of estimated net worth.

## Consolidated venture cross-reference

The `BIZSCHED-2021` supporting schedule provides the entity-by-entity breakdown of Daniel's two majority-owned real-estate ventures and three majority-owned hospitality ventures. The net-worth category is a planning estimate; operating cash, restricted reserves, appraised property value, and undrawn credit remain unavailable for the signed personal liquidity floor.
