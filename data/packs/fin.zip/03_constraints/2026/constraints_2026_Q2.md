# Signed Suitability Constraints — 2026 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `CON-2026-Q2`
- Document type: `signed_constraints_sheet`
- As-of date: 2026-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, ADVISER-MAYA-CHEN

## Governing status

- Authority: client-approved constraint sheet
- Version relationship: Supersedes `CON-2026-Q1` effective 2026-06-30
- Risk score: 5 of 10
- Risk band: **moderate**
- Maximum aggregate growth assets: 68% of liquid portfolios
- Minimum readily available liquidity: **$4,250,000**
- Liquidity purpose: April 2027 tax payment on the dental sale, family reserve, and unfunded commitments
- Planning horizon: retirement target remains 2032; planning horizon exceeds 20 years

## Standing product prohibitions

- No uncovered options, naked short positions, or single-stock margin borrowing.
- No leveraged or inverse exchange-traded products.
- No non-traded REITs or variable annuities with surrender schedules.
- Direct cryptocurrency exposure may not exceed 2% of liquid investable assets.
- No private placement outside a documented diligence review approved by both clients.
- No new illiquid commitment if aggregate private investments exceed 15% of investable assets or if the liquidity floor would be breached under the 24-month capital-call schedule.

## Concentration and implementation limits

- Any one public issuer is capped at 5% of liquid investable assets; employer or closely held business interests are reported separately.
- Aggregate public-equity exposure may not exceed the growth-asset cap above.
- Temporary settlement overdrafts may not exceed $250,000 or ten business days.
- Tax reserve funds must be held in Treasury bills, government money-market funds, or insured deposits with maturities aligned to payment dates.

## Current evidence and change rationale

The first post-transaction review restored a moderate risk band while preserving the $4,250,000 liquid reserve and all product prohibitions.

The clients reviewed these constraints with adviser Maya Chen. Any recommendation inconsistent with this sheet requires a new signed profile update; an unsigned draft does not amend canonical constraints.
