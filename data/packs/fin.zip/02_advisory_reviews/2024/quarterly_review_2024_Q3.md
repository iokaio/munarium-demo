# Quarterly Advisory Review — 2024 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `ADV-2024-Q3`
- Document type: `advisory_meeting_note`
- As-of date: 2024-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, ADVISER-MAYA-CHEN

## Attendees and purpose

- Clients: Eleanor “Nora” Vale and Daniel Vale
- Adviser: Maya Chen, CFP®, partner at Summit Loom Advisory
- Tax adviser: Luis Ortega, CPA (tax segments only)
- Purpose: quarterly suitability, liquidity, business, portfolio, and private-investment review

## Current household snapshot

- Estimated liquid investable assets: $14,287,274
- Reported private-fund NAV: $2,656,067
- Current risk result: 5/10, moderate
- Current liquidity floor: $3,000,000
- Target retirement: 2032
- Target first-year after-tax retirement spending: $450,000

## Material developments

Juniper Ridge acquired Trailhead Outfitters' online catalog for $900,000, financed with $400,000 cash and a $500,000 seller note. Business reports, portfolio statements, and capital-account reports for this quarter were reviewed as separate source documents.

## Suitability discussion

The clients confirmed that the liquidity floor is a hard constraint, not a target allocation. They remain able to tolerate normal market volatility only within the current risk band. Closely held businesses and venture funds are counted when assessing economic concentration and illiquidity, even though they sit outside the three liquid portfolios.

## Approved actions

- Maintain at least $3,000,000 in cash, Treasury bills, and government money-market funds.
- Keep combined liquid-portfolio growth assets at or below 68%.
- Rebalance with cash flows and tax-aware loss harvesting before selling appreciated core positions.
- Model all known capital calls over a rolling 24-month horizon before approving another private investment.

## Rejected or unapproved alternatives

No proposal was rejected this quarter.

## Follow-up

- Adviser to compare actual allocations against `CON-2024-Q3`.
- Clients to provide any new capital-call notice within five business days.
- CPA to refresh estimated-tax amounts after any business sale or major distribution.
- Next formal review is scheduled for the following calendar quarter.
