# FoundryWorks Opportunity SPV 7 LLC Capital Call Notice — 2023 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-09`
- Document type: `venture_capital_capital_call_notice`
- As-of date: 2023-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FW7

## Notice

- Vehicle: FoundryWorks Opportunity SPV 7 LLC
- Notice sequence: 09
- Event: capital call
- Amount: $350,000

A capital contribution of **$350,000** is due 15 calendar days after this notice.

## Capital-account position after event

- Cumulative called capital: $350,000
- Cumulative distributions: $0
- Remaining unfunded commitment: $0

## Household instruction

Fund from the designated Treasury-bill ladder; do not use margin and do not reduce the household below its governing liquidity floor. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
