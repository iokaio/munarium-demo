# Aster Health Ventures I LP Capital Call Notice — 2021 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-04`
- Document type: `venture_capital_capital_call_notice`
- As-of date: 2021-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-AHV1

## Notice

- Vehicle: Aster Health Ventures I LP
- Notice sequence: 04
- Event: capital call
- Amount: $150,000

A capital contribution of **$150,000** is due 15 calendar days after this notice.

## Capital-account position after event

- Cumulative called capital: $150,000
- Cumulative distributions: $0
- Remaining unfunded commitment: $450,000

## Household instruction

Fund from the designated Treasury-bill ladder; do not use margin and do not reduce the household below its governing liquidity floor. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
