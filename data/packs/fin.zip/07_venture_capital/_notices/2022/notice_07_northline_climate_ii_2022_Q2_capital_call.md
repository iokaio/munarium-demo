# Northline Climate Partners II LP Capital Call Notice — 2022 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-07`
- Document type: `venture_capital_capital_call_notice`
- As-of date: 2022-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-NCP2

## Notice

- Vehicle: Northline Climate Partners II LP
- Notice sequence: 07
- Event: capital call
- Amount: $200,000

A capital contribution of **$200,000** is due 15 calendar days after this notice.

## Capital-account position after event

- Cumulative called capital: $200,000
- Cumulative distributions: $0
- Remaining unfunded commitment: $800,000

## Household instruction

Fund from the designated Treasury-bill ladder; do not use margin and do not reduce the household below its governing liquidity floor. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
