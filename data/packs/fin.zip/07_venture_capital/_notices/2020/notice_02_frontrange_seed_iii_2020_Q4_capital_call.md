# FrontRange Seed Fund III LP Capital Call Notice — 2020 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-02`
- Document type: `venture_capital_capital_call_notice`
- As-of date: 2020-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FRS3

## Notice

- Vehicle: FrontRange Seed Fund III LP
- Notice sequence: 02
- Event: capital call
- Amount: $120,000

A capital contribution of **$120,000** is due 15 calendar days after this notice.

## Capital-account position after event

- Cumulative called capital: $270,000
- Cumulative distributions: $0
- Remaining unfunded commitment: $480,000

## Household instruction

Fund from the designated Treasury-bill ladder; do not use margin and do not reduce the household below its governing liquidity floor. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
