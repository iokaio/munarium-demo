# Aster Health Ventures I LP Distribution Notice — 2026 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-06`
- Document type: `venture_capital_distribution_notice`
- As-of date: 2026-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-AHV1

## Notice

- Vehicle: Aster Health Ventures I LP
- Notice sequence: 06
- Event: distribution
- Amount: $45,000

A cash distribution of **$45,000** was authorized and will be remitted to the taxable account.

## Capital-account position after event

- Cumulative called capital: $540,000
- Cumulative distributions: $45,000
- Remaining unfunded commitment: $60,000

## Household instruction

Hold proceeds in the government money-market sleeve until the adviser and CPA complete tax and liquidity review. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
