# FrontRange Seed Fund III LP Distribution Notice — 2025 Q3

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-03`
- Document type: `venture_capital_distribution_notice`
- As-of date: 2025-09-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FRS3

## Notice

- Vehicle: FrontRange Seed Fund III LP
- Notice sequence: 03
- Event: distribution
- Amount: $85,000

A cash distribution of **$85,000** was authorized and will be remitted to the taxable account.

## Capital-account position after event

- Cumulative called capital: $645,000
- Cumulative distributions: $85,000
- Remaining unfunded commitment: $105,000

## Household instruction

Hold proceeds in the government money-market sleeve until the adviser and CPA complete tax and liquidity review. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
