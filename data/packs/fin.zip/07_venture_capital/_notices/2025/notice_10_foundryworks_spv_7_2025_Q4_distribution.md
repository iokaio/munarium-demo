# FoundryWorks Opportunity SPV 7 LLC Distribution Notice — 2025 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCNOTICE-10`
- Document type: `venture_capital_distribution_notice`
- As-of date: 2025-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FW7

## Notice

- Vehicle: FoundryWorks Opportunity SPV 7 LLC
- Notice sequence: 10
- Event: distribution
- Amount: $40,000

A cash distribution of **$40,000** was authorized and will be remitted to the taxable account.

## Capital-account position after event

- Cumulative called capital: $350,000
- Cumulative distributions: $40,000
- Remaining unfunded commitment: $0

## Household instruction

Hold proceeds in the government money-market sleeve until the adviser and CPA complete tax and liquidity review. This notice changes cash-flow timing but does not change risk tolerance, product prohibitions, or investment-policy limits.
