# Kestrel Growth Fund I LP Limited-Partner Report — 2026 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-KGF1-2026-Q1`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2026-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-KGF1

## Limited-partner capital account

- Vehicle: Kestrel Growth Fund I LP
- Internal entity ID: VC-KGF1
- Strategy: lower-middle-market vertical software
- Household commitment: $1,250,000
- Fund stage: investment period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $880,000 |
| Cumulative distributions | $0 |
| Reported net asset value | $863,964 |
| Remaining unfunded commitment | **$370,000** |

## Performance indicators

- Net TVPI: 0.98x
- Net DPI: 0.00x
- Since-inception net IRR: -7.5% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2026 Q1 focused on lower-middle-market vertical software. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $370,000 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $4,250,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2026-Q1`.
