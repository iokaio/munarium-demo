# Aster Health Ventures I LP Limited-Partner Report — 2023 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-AHV1-2023-Q2`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2023-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-AHV1

## Limited-partner capital account

- Vehicle: Aster Health Ventures I LP
- Internal entity ID: VC-AHV1
- Strategy: health-services technology and diagnostics
- Household commitment: $600,000
- Fund stage: investment period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $390,000 |
| Cumulative distributions | $0 |
| Reported net asset value | $376,076 |
| Remaining unfunded commitment | **$210,000** |

## Performance indicators

- Net TVPI: 0.96x
- Net DPI: 0.00x
- Since-inception net IRR: -3.9% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2023 Q2 focused on health-services technology and diagnostics. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $210,000 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $2,750,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2023-Q2`.
