# Aster Health Ventures I LP Limited-Partner Report — 2026 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-AHV1-2026-Q2`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2026-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-AHV1

## Limited-partner capital account

- Vehicle: Aster Health Ventures I LP
- Internal entity ID: VC-AHV1
- Strategy: health-services technology and diagnostics
- Household commitment: $600,000
- Fund stage: harvest and follow-on period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $540,000 |
| Cumulative distributions | $45,000 |
| Reported net asset value | $744,055 |
| Remaining unfunded commitment | **$60,000** |

## Performance indicators

- Net TVPI: 1.46x
- Net DPI: 0.08x
- Since-inception net IRR: 20.0% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2026 Q2 focused on health-services technology and diagnostics. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $60,000 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $4,250,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2026-Q2`.
