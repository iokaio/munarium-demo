# Aster Health Ventures I LP Limited-Partner Report — 2025 Q4

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-AHV1-2025-Q4`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2025-12-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-AHV1

## Limited-partner capital account

- Vehicle: Aster Health Ventures I LP
- Internal entity ID: VC-AHV1
- Strategy: health-services technology and diagnostics
- Household commitment: $600,000
- Fund stage: harvest and follow-on period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $540,000 |
| Cumulative distributions | $0 |
| Reported net asset value | $713,197 |
| Remaining unfunded commitment | **$60,000** |

## Performance indicators

- Net TVPI: 1.32x
- Net DPI: 0.00x
- Since-inception net IRR: 15.7% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2025 Q4 focused on health-services technology and diagnostics. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $60,000 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $3,500,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2025-Q4`.
