# FoundryWorks Opportunity SPV 7 LLC Limited-Partner Report — 2025 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-FW7-2025-Q1`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2025-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FW7

## Limited-partner capital account

- Vehicle: FoundryWorks Opportunity SPV 7 LLC
- Internal entity ID: VC-FW7
- Strategy: single-company growth investment in industrial automation
- Household commitment: $350,000
- Fund stage: harvest and follow-on period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $350,000 |
| Cumulative distributions | $0 |
| Reported net asset value | $356,859 |
| Remaining unfunded commitment | **$0** |

## Performance indicators

- Net TVPI: 1.02x
- Net DPI: 0.00x
- Since-inception net IRR: -1.9% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2025 Q1 focused on single-company growth investment in industrial automation. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $0 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $3,000,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2025-Q1`.
