# FrontRange Seed Fund III LP Limited-Partner Report — 2022 Q2

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-FRS3-2022-Q2`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2022-06-30
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FRS3

## Limited-partner capital account

- Vehicle: FrontRange Seed Fund III LP
- Internal entity ID: VC-FRS3
- Strategy: enterprise software and data infrastructure
- Household commitment: $750,000
- Fund stage: investment period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $495,000 |
| Cumulative distributions | $0 |
| Reported net asset value | $510,771 |
| Remaining unfunded commitment | **$255,000** |

## Performance indicators

- Net TVPI: 1.03x
- Net DPI: 0.00x
- Since-inception net IRR: 0.6% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2022 Q2 focused on enterprise software and data infrastructure. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $255,000 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $1,500,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2022-Q2`.
