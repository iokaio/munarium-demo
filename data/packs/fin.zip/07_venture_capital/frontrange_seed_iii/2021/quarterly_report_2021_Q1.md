# FrontRange Seed Fund III LP Limited-Partner Report — 2021 Q1

> **Synthetic fixture.** All people, entities, account numbers, addresses, and transactions in this document are fictional and were created for the Muninn Mesh Lab.

## Document control

- Document ID: `VCREP-VC-FRS3-2021-Q1`
- Document type: `venture_capital_quarterly_report`
- As-of date: 2021-03-31
- Household: Vale Family (`HH-VALE-001`)
- Status: Final unless a section is explicitly labeled draft or rejected
- Entities: HH-VALE-001, VC-FRS3

## Limited-partner capital account

- Vehicle: FrontRange Seed Fund III LP
- Internal entity ID: VC-FRS3
- Strategy: enterprise software and data infrastructure
- Household commitment: $750,000
- Fund stage: investment period

| Capital-account item | Amount |
|---|---:|
| Cumulative contributed capital | $270,000 |
| Cumulative distributions | $0 |
| Reported net asset value | $250,572 |
| Remaining unfunded commitment | **$480,000** |

## Performance indicators

- Net TVPI: 0.93x
- Net DPI: 0.00x
- Since-inception net IRR: -11.1% (not meaningful early in the fund life)
- Valuations are manager estimates and are not liquid-market values.

## Manager update

Portfolio work during 2021 Q1 focused on enterprise software and data infrastructure. Management reported mixed operating conditions, longer financing timelines, and adequate reserves for current portfolio companies. No secondary-market liquidity should be assumed.

## Household planning treatment

The full unfunded amount of $480,000 remains part of the household's 24-month stress test. This interest is illiquid, is excluded from the personal liquidity floor of $1,500,000, and does not authorize another private investment. Any new commitment must satisfy `CON-2021-Q1`.
