# Northgate Systems Virtual Data Room Index

This synthetic corpus supports the Munarium due-diligence consistency experiment.
It contains 612 transaction documents plus this index and a machine-readable manifest.
All people, entities, amounts, incidents, and agreements are fictional.

## Transaction

Aster Peak Holdings, Inc. proposes to acquire all equity of Northgate Systems Ltd. in a change-of-control transaction.
The data room intentionally contains duplicates, omissions, superseded records, side letters, and contradictory assertions.
Documents must be evaluated independently before cross-source reconciliation.

## Category counts

- `01_corporate`: 42
- `02_equity`: 48
- `03_finance`: 78
- `04_tax`: 45
- `05_commercial`: 96
- `06_employment`: 66
- `07_intellectual_property`: 54
- `08_legal_compliance`: 48
- `09_privacy_security`: 48
- `10_real_estate_environment`: 30
- `11_insurance`: 24
- `12_operations_regulatory`: 33

## Seeded diligence themes

- FY2023 revenue differs between audited statements, the CIM, and seller adjustments.
- Granite Bank debt is approved and outstanding despite a no-long-term-debt assertion.
- A SAFE and bank warrant are omitted or inconsistently treated in capitalization records.
- Meridian concentration, payment disputes, change-of-control rights, and a controlling side letter interact.
- Related-party SableWorks arrangements create disclosure, approval, expense, and IP-title issues.
- VectorPay breach scope, notification timing, insurance coverage, and regulatory exposure conflict across files.
- Tax nexus, worker classification, transaction bonuses, and retention accruals create unrecorded liabilities.
- Founder code, contractor work, copyleft software, and nonassignable licenses cloud IP ownership and operability.
- Litigation, sanctions, anti-bribery, environmental, clinical-software, and continuity records create contingent risk.

See `corpus_manifest.json` for paths, dates, categories, and content hashes.
