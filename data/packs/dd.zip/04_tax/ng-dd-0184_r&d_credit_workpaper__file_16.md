---
document_id: NG-DD-0184
category: 04_tax
title: R&D Credit Workpaper — File 16
document_date: 2024-03-04
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# R&D Credit Workpaper — File 16

## Filing profile
Jurisdiction: New York. Tax year: 2020. Responsible owner: Priya Nair.

## R&D credit risk
The company claimed USD 880,000 of federal R&D credits for 2022 and 2023. Time records substantiate approximately 54% of qualified wages; executive interviews were used for the remainder.
