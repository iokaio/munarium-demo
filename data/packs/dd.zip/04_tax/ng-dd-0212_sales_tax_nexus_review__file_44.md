---
document_id: NG-DD-0212
category: 04_tax
title: Sales Tax Nexus Review — File 44
document_date: 2022-11-14
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 44

## Filing profile
Jurisdiction: California. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 155,148. Open workpaper reference: TAX-CA-0044.

No closing agreement or tax holiday is identified in this file.
