---
document_id: NG-DD-0213
category: 04_tax
title: Payroll Tax Notice — File 45
document_date: 2022-10-28
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 45

## Filing profile
Jurisdiction: Texas. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 158,265. Open workpaper reference: TAX-TE-0045.

No closing agreement or tax holiday is identified in this file.
