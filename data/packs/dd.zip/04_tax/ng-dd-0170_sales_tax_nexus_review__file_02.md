---
document_id: NG-DD-0170
category: 04_tax
title: Sales Tax Nexus Review — File 02
document_date: 2020-07-31
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 02

## Filing profile
Jurisdiction: California. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 24,234. Open workpaper reference: TAX-CA-0002.

No closing agreement or tax holiday is identified in this file.
