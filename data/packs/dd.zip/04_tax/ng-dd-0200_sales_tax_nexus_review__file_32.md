---
document_id: NG-DD-0200
category: 04_tax
title: Sales Tax Nexus Review — File 32
document_date: 2023-06-06
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 32

## Filing profile
Jurisdiction: California. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 117,744. Open workpaper reference: TAX-CA-0032.

No closing agreement or tax holiday is identified in this file.
