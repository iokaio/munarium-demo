---
document_id: NG-DD-0187
category: 04_tax
title: Income Tax Return Summary — File 19
document_date: 2024-01-13
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 19

## Filing profile
Jurisdiction: Colorado. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 77,223. Open workpaper reference: TAX-CO-0019.

No closing agreement or tax holiday is identified in this file.
