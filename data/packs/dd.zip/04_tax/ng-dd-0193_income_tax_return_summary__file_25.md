---
document_id: NG-DD-0193
category: 04_tax
title: Income Tax Return Summary — File 25
document_date: 2023-10-03
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 25

## Filing profile
Jurisdiction: Colorado. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 95,925. Open workpaper reference: TAX-CO-0025.

No closing agreement or tax holiday is identified in this file.
