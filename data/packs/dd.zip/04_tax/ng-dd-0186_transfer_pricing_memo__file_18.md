---
document_id: NG-DD-0186
category: 04_tax
title: Transfer Pricing Memo — File 18
document_date: 2024-01-30
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Transfer Pricing Memo — File 18

## Filing profile
Jurisdiction: Delaware. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 74,106. Open workpaper reference: TAX-DE-0018.

No closing agreement or tax holiday is identified in this file.
