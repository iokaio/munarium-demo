---
document_id: NG-DD-0188
category: 04_tax
title: Sales Tax Nexus Review — File 20
document_date: 2023-12-27
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 20

## Filing profile
Jurisdiction: California. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 80,340. Open workpaper reference: TAX-CA-0020.

No closing agreement or tax holiday is identified in this file.
