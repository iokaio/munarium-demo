---
document_id: NG-DD-0174
category: 04_tax
title: Transfer Pricing Memo — File 06
document_date: 2020-05-24
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Transfer Pricing Memo — File 06

## Filing profile
Jurisdiction: Delaware. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 36,702. Open workpaper reference: TAX-DE-0006.

No closing agreement or tax holiday is identified in this file.
