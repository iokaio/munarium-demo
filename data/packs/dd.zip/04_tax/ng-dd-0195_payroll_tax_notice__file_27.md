---
document_id: NG-DD-0195
category: 04_tax
title: Payroll Tax Notice — File 27
document_date: 2023-08-30
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 27

## Filing profile
Jurisdiction: Texas. Tax year: 2023. Responsible owner: Priya Nair.

## Payroll classification
Colorado issued a preliminary USD 340,000 payroll-tax assessment concerning 23 implementation consultants treated as independent contractors.
