---
document_id: NG-DD-0198
category: 04_tax
title: Transfer Pricing Memo — File 30
document_date: 2023-07-10
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Transfer Pricing Memo — File 30

## Filing profile
Jurisdiction: Delaware. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 111,510. Open workpaper reference: TAX-DE-0030.

No closing agreement or tax holiday is identified in this file.
