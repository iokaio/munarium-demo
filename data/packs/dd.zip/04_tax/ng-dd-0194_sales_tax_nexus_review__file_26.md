---
document_id: NG-DD-0194
category: 04_tax
title: Sales Tax Nexus Review — File 26
document_date: 2023-09-16
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 26

## Filing profile
Jurisdiction: California. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 99,042. Open workpaper reference: TAX-CA-0026.

No closing agreement or tax holiday is identified in this file.
