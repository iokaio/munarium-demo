---
document_id: NG-DD-0190
category: 04_tax
title: R&D Credit Workpaper — File 22
document_date: 2023-11-23
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# R&D Credit Workpaper — File 22

## Filing profile
Jurisdiction: New York. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 86,574. Open workpaper reference: TAX-NE-0022.

No closing agreement or tax holiday is identified in this file.
