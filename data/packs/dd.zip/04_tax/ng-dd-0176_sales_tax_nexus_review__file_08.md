---
document_id: NG-DD-0176
category: 04_tax
title: Sales Tax Nexus Review — File 08
document_date: 2020-04-20
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 08

## Filing profile
Jurisdiction: California. Tax year: 2020. Responsible owner: Priya Nair.

## Nexus exposure
Northgate exceeded economic-nexus thresholds in 14 states beginning in 2021 but registered in only six. The advisor estimates unpaid sales and use tax of USD 1,260,000 before interest and penalties.
