---
document_id: NG-DD-0211
category: 04_tax
title: Income Tax Return Summary — File 43
document_date: 2022-12-01
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 43

## Filing profile
Jurisdiction: Colorado. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 152,031. Open workpaper reference: TAX-CO-0043.

No closing agreement or tax holiday is identified in this file.
