---
document_id: NG-DD-0169
category: 04_tax
title: Income Tax Return Summary — File 01
document_date: 2020-08-17
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 01

## Filing profile
Jurisdiction: Colorado. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 21,117. Open workpaper reference: TAX-CO-0001.

No closing agreement or tax holiday is identified in this file.
