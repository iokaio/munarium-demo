---
document_id: NG-DD-0196
category: 04_tax
title: R&D Credit Workpaper — File 28
document_date: 2023-08-13
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# R&D Credit Workpaper — File 28

## Filing profile
Jurisdiction: New York. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 105,276. Open workpaper reference: TAX-NE-0028.

No closing agreement or tax holiday is identified in this file.
