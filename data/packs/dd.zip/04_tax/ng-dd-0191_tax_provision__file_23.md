---
document_id: NG-DD-0191
category: 04_tax
title: Tax Provision — File 23
document_date: 2023-11-06
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Tax Provision — File 23

## Filing profile
Jurisdiction: Washington. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 89,691. Open workpaper reference: TAX-WA-0023.

No closing agreement or tax holiday is identified in this file.
