---
document_id: NG-DD-0177
category: 04_tax
title: Payroll Tax Notice — File 09
document_date: 2020-04-03
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 09

## Filing profile
Jurisdiction: Texas. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 46,053. Open workpaper reference: TAX-TE-0009.

No closing agreement or tax holiday is identified in this file.
