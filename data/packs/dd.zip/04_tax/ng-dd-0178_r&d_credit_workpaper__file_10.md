---
document_id: NG-DD-0178
category: 04_tax
title: R&D Credit Workpaper — File 10
document_date: 2020-03-17
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# R&D Credit Workpaper — File 10

## Filing profile
Jurisdiction: New York. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 49,170. Open workpaper reference: TAX-NE-0010.

No closing agreement or tax holiday is identified in this file.
