---
document_id: NG-DD-0199
category: 04_tax
title: Income Tax Return Summary — File 31
document_date: 2023-06-23
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 31

## Filing profile
Jurisdiction: Colorado. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 114,627. Open workpaper reference: TAX-CO-0031.

No closing agreement or tax holiday is identified in this file.
