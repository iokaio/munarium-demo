---
document_id: NG-DD-0209
category: 04_tax
title: Tax Provision — File 41
document_date: 2023-01-04
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Tax Provision — File 41

## Filing profile
Jurisdiction: Washington. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 145,797. Open workpaper reference: TAX-WA-0041.

No closing agreement or tax holiday is identified in this file.
