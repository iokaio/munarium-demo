---
document_id: NG-DD-0197
category: 04_tax
title: Tax Provision — File 29
document_date: 2023-07-27
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Tax Provision — File 29

## Filing profile
Jurisdiction: Washington. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 108,393. Open workpaper reference: TAX-WA-0029.

No closing agreement or tax holiday is identified in this file.
