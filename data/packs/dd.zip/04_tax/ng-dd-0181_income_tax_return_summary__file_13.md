---
document_id: NG-DD-0181
category: 04_tax
title: Income Tax Return Summary — File 13
document_date: 2020-01-26
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 13

## Filing profile
Jurisdiction: Colorado. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 58,521. Open workpaper reference: TAX-CO-0013.

No closing agreement or tax holiday is identified in this file.
