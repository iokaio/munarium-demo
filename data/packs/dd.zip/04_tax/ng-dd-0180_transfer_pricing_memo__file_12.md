---
document_id: NG-DD-0180
category: 04_tax
title: Transfer Pricing Memo — File 12
document_date: 2020-02-12
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Transfer Pricing Memo — File 12

## Filing profile
Jurisdiction: Delaware. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 55,404. Open workpaper reference: TAX-DE-0012.

No closing agreement or tax holiday is identified in this file.
