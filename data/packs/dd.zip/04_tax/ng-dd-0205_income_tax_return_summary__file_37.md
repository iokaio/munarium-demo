---
document_id: NG-DD-0205
category: 04_tax
title: Income Tax Return Summary — File 37
document_date: 2023-03-13
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 37

## Filing profile
Jurisdiction: Colorado. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 133,329. Open workpaper reference: TAX-CO-0037.

No closing agreement or tax holiday is identified in this file.
