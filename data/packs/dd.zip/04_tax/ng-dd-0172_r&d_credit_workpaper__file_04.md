---
document_id: NG-DD-0172
category: 04_tax
title: R&D Credit Workpaper — File 04
document_date: 2020-06-27
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# R&D Credit Workpaper — File 04

## Filing profile
Jurisdiction: New York. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 30,468. Open workpaper reference: TAX-NE-0004.

No closing agreement or tax holiday is identified in this file.
