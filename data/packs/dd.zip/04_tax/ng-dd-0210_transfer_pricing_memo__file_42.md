---
document_id: NG-DD-0210
category: 04_tax
title: Transfer Pricing Memo — File 42
document_date: 2022-12-18
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Transfer Pricing Memo — File 42

## Filing profile
Jurisdiction: Delaware. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 148,914. Open workpaper reference: TAX-DE-0042.

No closing agreement or tax holiday is identified in this file.
