---
document_id: NG-DD-0175
category: 04_tax
title: Income Tax Return Summary — File 07
document_date: 2020-05-07
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Income Tax Return Summary — File 07

## Filing profile
Jurisdiction: Colorado. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 39,819. Open workpaper reference: TAX-CO-0007.

No closing agreement or tax holiday is identified in this file.
