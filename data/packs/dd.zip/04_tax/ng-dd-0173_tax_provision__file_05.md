---
document_id: NG-DD-0173
category: 04_tax
title: Tax Provision — File 05
document_date: 2020-06-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Tax Provision — File 05

## Filing profile
Jurisdiction: Washington. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 33,585. Open workpaper reference: TAX-WA-0005.

No closing agreement or tax holiday is identified in this file.
