---
document_id: NG-DD-0189
category: 04_tax
title: Payroll Tax Notice — File 21
document_date: 2023-12-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 21

## Filing profile
Jurisdiction: Texas. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 83,457. Open workpaper reference: TAX-TE-0021.

No closing agreement or tax holiday is identified in this file.
