---
document_id: NG-DD-0207
category: 04_tax
title: Payroll Tax Notice — File 39
document_date: 2023-02-07
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 39

## Filing profile
Jurisdiction: Texas. Tax year: 2023. Responsible owner: Priya Nair.

## UK transfer pricing
Northgate Health UK Ltd charged no service fee to the parent during 2023 despite employing the EMEA sales team. The advisor recommends a retrospective cost-plus true-up of USD 410,000.
