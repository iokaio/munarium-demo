---
document_id: NG-DD-0192
category: 04_tax
title: Transfer Pricing Memo — File 24
document_date: 2023-10-20
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Transfer Pricing Memo — File 24

## Filing profile
Jurisdiction: Delaware. Tax year: 2020. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 92,808. Open workpaper reference: TAX-DE-0024.

No closing agreement or tax holiday is identified in this file.
