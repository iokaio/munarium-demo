---
document_id: NG-DD-0183
category: 04_tax
title: Payroll Tax Notice — File 15
document_date: 2024-03-21
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 15

## Filing profile
Jurisdiction: Texas. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 64,755. Open workpaper reference: TAX-TE-0015.

No closing agreement or tax holiday is identified in this file.
