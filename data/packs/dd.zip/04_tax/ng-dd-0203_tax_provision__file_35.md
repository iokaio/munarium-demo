---
document_id: NG-DD-0203
category: 04_tax
title: Tax Provision — File 35
document_date: 2023-04-16
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Tax Provision — File 35

## Filing profile
Jurisdiction: Washington. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 127,095. Open workpaper reference: TAX-WA-0035.

No closing agreement or tax holiday is identified in this file.
