---
document_id: NG-DD-0171
category: 04_tax
title: Payroll Tax Notice — File 03
document_date: 2020-07-14
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Payroll Tax Notice — File 03

## Filing profile
Jurisdiction: Texas. Tax year: 2023. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 27,351. Open workpaper reference: TAX-TE-0003.

No closing agreement or tax holiday is identified in this file.
