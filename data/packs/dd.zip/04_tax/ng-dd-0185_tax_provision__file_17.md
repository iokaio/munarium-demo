---
document_id: NG-DD-0185
category: 04_tax
title: Tax Provision — File 17
document_date: 2024-02-16
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Tax Provision — File 17

## Filing profile
Jurisdiction: Washington. Tax year: 2021. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 70,989. Open workpaper reference: TAX-WA-0017.

No closing agreement or tax holiday is identified in this file.
