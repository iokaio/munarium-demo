---
document_id: NG-DD-0182
category: 04_tax
title: Sales Tax Nexus Review — File 14
document_date: 2020-01-09
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Sales Tax Nexus Review — File 14

## Filing profile
Jurisdiction: California. Tax year: 2022. Responsible owner: Priya Nair.

## Status
The filing reports tax due or provision of USD 61,638. Open workpaper reference: TAX-CA-0014.

No closing agreement or tax holiday is identified in this file.
