---
document_id: NG-DD-0147
category: 03_finance
title: Monthly Close Package — Period 57
document_date: 2021-08-26
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 57

## Summary
Gross revenue recorded for the referenced period was USD 1,111,500. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 46,667 remains open under ticket FIN-0057. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 37% of the activity in this record.
