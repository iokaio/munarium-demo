---
document_id: NG-DD-0149
category: 03_finance
title: Revenue Detail — Period 59
document_date: 2021-07-23
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 59

## Summary
Gross revenue recorded for the referenced period was USD 1,158,500. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 48,129 remains open under ticket FIN-0059. The preparer assessed the item as timing.

Meridian-related billings represented 39% of the activity in this record.
