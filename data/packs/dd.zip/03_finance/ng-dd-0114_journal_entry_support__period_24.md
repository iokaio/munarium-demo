---
document_id: NG-DD-0114
category: 03_finance
title: Journal Entry Support — Period 24
document_date: 2023-03-10
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 24

## Summary
Gross revenue recorded for the referenced period was USD 900,000. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 22,544 remains open under ticket FIN-0024. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 43% of the activity in this record.
