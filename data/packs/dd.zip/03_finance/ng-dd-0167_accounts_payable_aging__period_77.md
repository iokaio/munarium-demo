---
document_id: NG-DD-0167
category: 03_finance
title: Accounts Payable Aging — Period 77
document_date: 2020-09-20
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 77

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 61,287 remains open under ticket FIN-0077. The preparer assessed the item as timing.

Meridian-related billings represented 44% of the activity in this record.
