---
document_id: NG-DD-0119
category: 03_finance
title: Accounts Payable Aging — Period 29
document_date: 2022-12-15
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 29

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 26,199 remains open under ticket FIN-0029. The preparer assessed the item as timing.

Meridian-related billings represented 35% of the activity in this record.
