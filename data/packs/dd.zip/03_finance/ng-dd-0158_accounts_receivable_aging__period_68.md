---
document_id: NG-DD-0158
category: 03_finance
title: Accounts Receivable Aging — Period 68
document_date: 2021-02-20
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 68

## Summary
Gross revenue recorded for the referenced period was USD 1,088,000. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 54,708 remains open under ticket FIN-0068. The preparer assessed the item as timing.

Meridian-related billings represented 35% of the activity in this record.
