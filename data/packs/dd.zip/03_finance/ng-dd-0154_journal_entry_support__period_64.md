---
document_id: NG-DD-0154
category: 03_finance
title: Journal Entry Support — Period 64
document_date: 2021-04-29
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 64

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 51,784 remains open under ticket FIN-0064. The preparer assessed the item as timing.

Meridian-related billings represented 44% of the activity in this record.
