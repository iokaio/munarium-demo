---
document_id: NG-DD-0098
category: 03_finance
title: Journal Entry Support — Period 08
document_date: 2023-12-07
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 08

## Summary
Gross revenue recorded for the referenced period was USD 1,088,000. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 10,848 remains open under ticket FIN-0008. The preparer assessed the item as timing.

Meridian-related billings represented 40% of the activity in this record.
