---
document_id: NG-DD-0133
category: 03_finance
title: Revenue Detail — Period 43
document_date: 2022-04-21
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 43

## Summary
Gross revenue recorded for the referenced period was USD 1,064,500. Cash balance was USD 3,170,000.

## Review notes
A reconciling item of USD 36,433 remains open under ticket FIN-0043. The preparer assessed the item as timing.

Meridian-related billings represented 36% of the activity in this record.
