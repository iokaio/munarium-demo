---
document_id: NG-DD-0148
category: 03_finance
title: Bank Reconciliation — Period 58
document_date: 2021-08-09
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 58

## Summary
Gross revenue recorded for the referenced period was USD 1,135,000. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 47,398 remains open under ticket FIN-0058. The preparer assessed the item as timing.

Meridian-related billings represented 38% of the activity in this record.
