---
document_id: NG-DD-0108
category: 03_finance
title: Bank Reconciliation — Period 18
document_date: 2023-06-20
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 18

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 18,158 remains open under ticket FIN-0018. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 37% of the activity in this record.
