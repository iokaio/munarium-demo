---
document_id: NG-DD-0116
category: 03_finance
title: Bank Reconciliation — Period 26
document_date: 2023-02-04
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 26

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 24,006 remains open under ticket FIN-0026. The preparer assessed the item as timing.

Meridian-related billings represented 32% of the activity in this record.
