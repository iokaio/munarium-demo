---
document_id: NG-DD-0094
category: 03_finance
title: Accounts Receivable Aging — Period 04
document_date: 2024-02-13
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 04

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 7,924 remains open under ticket FIN-0004. The preparer assessed the item as timing.

Meridian-related billings represented 36% of the activity in this record.
