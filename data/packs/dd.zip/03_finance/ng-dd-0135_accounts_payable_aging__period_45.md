---
document_id: NG-DD-0135
category: 03_finance
title: Accounts Payable Aging — Period 45
document_date: 2022-03-18
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 45

## Summary
Gross revenue recorded for the referenced period was USD 1,111,500. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 37,895 remains open under ticket FIN-0045. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 38% of the activity in this record.
