---
document_id: NG-DD-0152
category: 03_finance
title: Debt Schedule — Period 62
document_date: 2021-06-02
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 62

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 50,322 remains open under ticket FIN-0062. The preparer assessed the item as timing.

Meridian-related billings represented 42% of the activity in this record.
