---
document_id: NG-DD-0128
category: 03_finance
title: Debt Schedule — Period 38
document_date: 2022-07-15
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 38

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 32,778 remains open under ticket FIN-0038. The preparer assessed the item as timing.

Meridian-related billings represented 44% of the activity in this record.
