---
document_id: NG-DD-0095
category: 03_finance
title: Accounts Payable Aging — Period 05
document_date: 2024-01-27
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 05

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 8,655 remains open under ticket FIN-0005. The preparer assessed the item as timing.

Meridian-related billings represented 37% of the activity in this record.
