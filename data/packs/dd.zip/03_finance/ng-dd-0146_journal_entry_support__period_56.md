---
document_id: NG-DD-0146
category: 03_finance
title: Journal Entry Support — Period 56
document_date: 2021-09-12
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 56

## Summary
Gross revenue recorded for the referenced period was USD 1,088,000. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 45,936 remains open under ticket FIN-0056. The preparer assessed the item as timing.

Meridian-related billings represented 36% of the activity in this record.
