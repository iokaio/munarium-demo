---
document_id: NG-DD-0123
category: 03_finance
title: Monthly Close Package — Period 33
document_date: 2022-10-08
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 33

## Summary
Gross revenue recorded for the referenced period was USD 1,111,500. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 29,123 remains open under ticket FIN-0033. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 39% of the activity in this record.
