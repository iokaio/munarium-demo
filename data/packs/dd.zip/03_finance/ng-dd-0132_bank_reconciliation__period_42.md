---
document_id: NG-DD-0132
category: 03_finance
title: Bank Reconciliation — Period 42
document_date: 2022-05-08
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 42

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 35,702 remains open under ticket FIN-0042. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 35% of the activity in this record.
