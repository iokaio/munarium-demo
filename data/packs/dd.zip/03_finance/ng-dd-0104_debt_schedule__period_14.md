---
document_id: NG-DD-0104
category: 03_finance
title: Debt Schedule — Period 14
document_date: 2023-08-27
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 14

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 15,234 remains open under ticket FIN-0014. The preparer assessed the item as timing.

Meridian-related billings represented 33% of the activity in this record.
