---
document_id: NG-DD-0122
category: 03_finance
title: Journal Entry Support — Period 32
document_date: 2022-10-25
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 32

## Summary
Gross revenue recorded for the referenced period was USD 1,088,000. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 28,392 remains open under ticket FIN-0032. The preparer assessed the item as timing.

Meridian-related billings represented 38% of the activity in this record.
