---
document_id: NG-DD-0100
category: 03_finance
title: Bank Reconciliation — Period 10
document_date: 2023-11-03
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 10

## Summary
Gross revenue recorded for the referenced period was USD 1,135,000. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 12,310 remains open under ticket FIN-0010. The preparer assessed the item as timing.

Meridian-related billings represented 42% of the activity in this record.
