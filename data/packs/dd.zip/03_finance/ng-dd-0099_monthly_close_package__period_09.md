---
document_id: NG-DD-0099
category: 03_finance
title: Monthly Close Package — Period 09
document_date: 2023-11-20
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 09

## Summary
Gross revenue recorded for the referenced period was USD 1,111,500. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 11,579 remains open under ticket FIN-0009. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 41% of the activity in this record.
