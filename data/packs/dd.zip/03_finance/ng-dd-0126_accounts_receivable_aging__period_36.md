---
document_id: NG-DD-0126
category: 03_finance
title: Accounts Receivable Aging — Period 36
document_date: 2022-08-18
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 36

## Summary
Gross revenue recorded for the referenced period was USD 900,000. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 31,316 remains open under ticket FIN-0036. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 42% of the activity in this record.
