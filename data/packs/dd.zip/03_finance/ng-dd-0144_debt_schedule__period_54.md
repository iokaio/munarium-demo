---
document_id: NG-DD-0144
category: 03_finance
title: Debt Schedule — Period 54
document_date: 2021-10-16
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 54

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 44,474 remains open under ticket FIN-0054. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 34% of the activity in this record.
