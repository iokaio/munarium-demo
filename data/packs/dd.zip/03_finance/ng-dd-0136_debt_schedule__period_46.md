---
document_id: NG-DD-0136
category: 03_finance
title: Debt Schedule — Period 46
document_date: 2022-03-01
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 46

## Summary
Gross revenue recorded for the referenced period was USD 1,135,000. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 38,626 remains open under ticket FIN-0046. The preparer assessed the item as timing.

Meridian-related billings represented 39% of the activity in this record.
