---
document_id: NG-DD-0115
category: 03_finance
title: Monthly Close Package — Period 25
document_date: 2023-02-21
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 25

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 3,170,000.

## Review notes
A reconciling item of USD 23,275 remains open under ticket FIN-0025. The preparer assessed the item as timing.

Meridian-related billings represented 44% of the activity in this record.
