---
document_id: NG-DD-0091
category: 03_finance
title: Monthly Close Package — Period 01
document_date: 2020-01-06
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 01

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 2,510,000.

## FY2023 audited totals
Audited revenue was USD 12,400,000 and EBITDA was USD 2,100,000. Cash and equivalents were USD 3,300,000 at December 31, 2023.
