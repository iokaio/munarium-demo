---
document_id: NG-DD-0168
category: 03_finance
title: Debt Schedule — Period 78
document_date: 2020-09-03
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 78

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 62,018 remains open under ticket FIN-0078. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 32% of the activity in this record.
