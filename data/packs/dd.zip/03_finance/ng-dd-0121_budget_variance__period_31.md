---
document_id: NG-DD-0121
category: 03_finance
title: Budget Variance — Period 31
document_date: 2022-11-11
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 31

## Summary
Gross revenue recorded for the referenced period was USD 1,064,500. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 27,661 remains open under ticket FIN-0031. The preparer assessed the item as timing.

Meridian-related billings represented 37% of the activity in this record.
