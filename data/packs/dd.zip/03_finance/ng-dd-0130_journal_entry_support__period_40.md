---
document_id: NG-DD-0130
category: 03_finance
title: Journal Entry Support — Period 40
document_date: 2022-06-11
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 40

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 34,240 remains open under ticket FIN-0040. The preparer assessed the item as timing.

Meridian-related billings represented 33% of the activity in this record.
