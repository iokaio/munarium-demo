---
document_id: NG-DD-0141
category: 03_finance
title: Revenue Detail — Period 51
document_date: 2021-12-06
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 51

## Summary
Gross revenue recorded for the referenced period was USD 970,500. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 42,281 remains open under ticket FIN-0051. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 44% of the activity in this record.
