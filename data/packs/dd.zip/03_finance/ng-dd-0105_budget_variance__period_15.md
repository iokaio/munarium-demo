---
document_id: NG-DD-0105
category: 03_finance
title: Budget Variance — Period 15
document_date: 2023-08-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 15

## Summary
Gross revenue recorded for the referenced period was USD 970,500. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 15,965 remains open under ticket FIN-0015. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 34% of the activity in this record.
