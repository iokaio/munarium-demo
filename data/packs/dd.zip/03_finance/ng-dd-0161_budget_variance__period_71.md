---
document_id: NG-DD-0161
category: 03_finance
title: Budget Variance — Period 71
document_date: 2020-12-31
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 71

## Summary
Gross revenue recorded for the referenced period was USD 1,158,500. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 56,901 remains open under ticket FIN-0071. The preparer assessed the item as timing.

Meridian-related billings represented 38% of the activity in this record.
