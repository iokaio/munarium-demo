---
document_id: NG-DD-0110
category: 03_finance
title: Accounts Receivable Aging — Period 20
document_date: 2023-05-17
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 20

## Summary
Gross revenue recorded for the referenced period was USD 1,088,000. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 19,620 remains open under ticket FIN-0020. The preparer assessed the item as timing.

Meridian-related billings represented 39% of the activity in this record.
