---
document_id: NG-DD-0101
category: 03_finance
title: Revenue Detail — Period 11
document_date: 2023-10-17
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 11

## Summary
Gross revenue recorded for the referenced period was USD 1,158,500. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 13,041 remains open under ticket FIN-0011. The preparer assessed the item as timing.

Meridian-related billings represented 43% of the activity in this record.
