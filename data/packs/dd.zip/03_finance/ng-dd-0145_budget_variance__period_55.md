---
document_id: NG-DD-0145
category: 03_finance
title: Budget Variance — Period 55
document_date: 2021-09-29
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 55

## Summary
Gross revenue recorded for the referenced period was USD 1,064,500. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 45,205 remains open under ticket FIN-0055. The preparer assessed the item as timing.

Meridian-related billings represented 35% of the activity in this record.
