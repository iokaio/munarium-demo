---
document_id: NG-DD-0131
category: 03_finance
title: Monthly Close Package — Period 41
document_date: 2022-05-25
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 41

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 34,971 remains open under ticket FIN-0041. The preparer assessed the item as timing.

Meridian-related billings represented 34% of the activity in this record.
