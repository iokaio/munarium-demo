---
document_id: NG-DD-0106
category: 03_finance
title: Journal Entry Support — Period 16
document_date: 2023-07-24
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 16

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 3,170,000.

## Review notes
A reconciling item of USD 16,696 remains open under ticket FIN-0016. The preparer assessed the item as timing.

Meridian-related billings represented 35% of the activity in this record.
