---
document_id: NG-DD-0159
category: 03_finance
title: Accounts Payable Aging — Period 69
document_date: 2021-02-03
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 69

## Summary
Gross revenue recorded for the referenced period was USD 1,111,500. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 55,439 remains open under ticket FIN-0069. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 36% of the activity in this record.
