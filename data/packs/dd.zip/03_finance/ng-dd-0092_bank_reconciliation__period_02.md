---
document_id: NG-DD-0092
category: 03_finance
title: Bank Reconciliation — Period 02
document_date: 2024-03-18
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 02

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 6,462 remains open under ticket FIN-0002. The preparer assessed the item as timing.

Meridian-related billings represented 34% of the activity in this record.
