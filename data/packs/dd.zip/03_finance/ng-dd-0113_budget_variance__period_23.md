---
document_id: NG-DD-0113
category: 03_finance
title: Budget Variance — Period 23
document_date: 2023-03-27
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 23

## Summary
Gross revenue recorded for the referenced period was USD 1,158,500. Cash balance was USD 2,950,000.

## Revenue-recognition adjustment
A USD 1,700,000 Meridian implementation fee was posted to FY2023 revenue on invoice. The auditor proposed deferral through June 2025; management did not book the adjustment in the seller quality-of-earnings schedule.
