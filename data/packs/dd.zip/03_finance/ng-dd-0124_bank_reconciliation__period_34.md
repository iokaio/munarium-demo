---
document_id: NG-DD-0124
category: 03_finance
title: Bank Reconciliation — Period 34
document_date: 2022-09-21
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 34

## Summary
Gross revenue recorded for the referenced period was USD 1,135,000. Cash balance was USD 3,170,000.

## Review notes
A reconciling item of USD 29,854 remains open under ticket FIN-0034. The preparer assessed the item as timing.

Meridian-related billings represented 40% of the activity in this record.
