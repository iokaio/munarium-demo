---
document_id: NG-DD-0107
category: 03_finance
title: Monthly Close Package — Period 17
document_date: 2023-07-07
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 17

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 17,427 remains open under ticket FIN-0017. The preparer assessed the item as timing.

Meridian-related billings represented 36% of the activity in this record.
