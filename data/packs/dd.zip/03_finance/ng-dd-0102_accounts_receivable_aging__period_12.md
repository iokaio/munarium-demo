---
document_id: NG-DD-0102
category: 03_finance
title: Accounts Receivable Aging — Period 12
document_date: 2023-09-30
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 12

## Summary
Gross revenue recorded for the referenced period was USD 900,000. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 13,772 remains open under ticket FIN-0012. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 44% of the activity in this record.
