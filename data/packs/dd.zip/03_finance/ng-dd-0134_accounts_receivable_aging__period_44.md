---
document_id: NG-DD-0134
category: 03_finance
title: Accounts Receivable Aging — Period 44
document_date: 2022-04-04
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 44

## Summary
Gross revenue recorded for the referenced period was USD 1,088,000. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 37,164 remains open under ticket FIN-0044. The preparer assessed the item as timing.

Meridian-related billings represented 37% of the activity in this record.
