---
document_id: NG-DD-0129
category: 03_finance
title: Budget Variance — Period 39
document_date: 2022-06-28
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 39

## Summary
Gross revenue recorded for the referenced period was USD 970,500. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 33,509 remains open under ticket FIN-0039. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 32% of the activity in this record.
