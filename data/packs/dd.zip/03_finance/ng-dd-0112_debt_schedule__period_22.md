---
document_id: NG-DD-0112
category: 03_finance
title: Debt Schedule — Period 22
document_date: 2023-04-13
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 22

## Summary
Gross revenue recorded for the referenced period was USD 1,135,000. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 21,082 remains open under ticket FIN-0022. The preparer assessed the item as timing.

Meridian-related billings represented 41% of the activity in this record.
