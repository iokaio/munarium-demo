---
document_id: NG-DD-0162
category: 03_finance
title: Journal Entry Support — Period 72
document_date: 2020-12-14
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 72

## Summary
Gross revenue recorded for the referenced period was USD 900,000. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 57,632 remains open under ticket FIN-0072. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 39% of the activity in this record.
