---
document_id: NG-DD-0103
category: 03_finance
title: Accounts Payable Aging — Period 13
document_date: 2023-09-13
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 13

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 14,503 remains open under ticket FIN-0013. The preparer assessed the item as timing.

Meridian-related billings represented 32% of the activity in this record.
