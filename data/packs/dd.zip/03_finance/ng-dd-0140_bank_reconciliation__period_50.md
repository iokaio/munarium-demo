---
document_id: NG-DD-0140
category: 03_finance
title: Bank Reconciliation — Period 50
document_date: 2021-12-23
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 50

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 2,950,000.

## Review notes
A reconciling item of USD 41,550 remains open under ticket FIN-0050. The preparer assessed the item as timing.

Meridian-related billings represented 43% of the activity in this record.
