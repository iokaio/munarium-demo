---
document_id: NG-DD-0127
category: 03_finance
title: Accounts Payable Aging — Period 37
document_date: 2022-08-01
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 37

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 2,510,000.

## Related-party payment
SableWorks Consulting received USD 486,000 during FY2023. The general ledger vendor master does not flag SableWorks as related to director Marcus Bell.
