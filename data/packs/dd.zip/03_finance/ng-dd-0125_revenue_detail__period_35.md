---
document_id: NG-DD-0125
category: 03_finance
title: Revenue Detail — Period 35
document_date: 2022-09-04
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 35

## Summary
Gross revenue recorded for the referenced period was USD 1,158,500. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 30,585 remains open under ticket FIN-0035. The preparer assessed the item as timing.

Meridian-related billings represented 41% of the activity in this record.
