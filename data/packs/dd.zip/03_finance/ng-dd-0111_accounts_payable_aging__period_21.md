---
document_id: NG-DD-0111
category: 03_finance
title: Accounts Payable Aging — Period 21
document_date: 2023-04-30
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 21

## Summary
Gross revenue recorded for the referenced period was USD 1,111,500. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 20,351 remains open under ticket FIN-0021. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 40% of the activity in this record.
