---
document_id: NG-DD-0163
category: 03_finance
title: Monthly Close Package — Period 73
document_date: 2020-11-27
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 73

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 58,363 remains open under ticket FIN-0073. The preparer assessed the item as timing.

Meridian-related billings represented 40% of the activity in this record.
