---
document_id: NG-DD-0139
category: 03_finance
title: Monthly Close Package — Period 49
document_date: 2022-01-09
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 49

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 40,819 remains open under ticket FIN-0049. The preparer assessed the item as timing.

Meridian-related billings represented 42% of the activity in this record.
