---
document_id: NG-DD-0153
category: 03_finance
title: Budget Variance — Period 63
document_date: 2021-05-16
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 63

## Summary
Gross revenue recorded for the referenced period was USD 970,500. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 51,053 remains open under ticket FIN-0063. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 43% of the activity in this record.
