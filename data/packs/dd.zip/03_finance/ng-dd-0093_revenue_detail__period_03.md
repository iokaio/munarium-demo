---
document_id: NG-DD-0093
category: 03_finance
title: Revenue Detail — Period 03
document_date: 2024-03-01
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 03

## Summary
Gross revenue recorded for the referenced period was USD 970,500. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 7,193 remains open under ticket FIN-0003. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 35% of the activity in this record.
