---
document_id: NG-DD-0166
category: 03_finance
title: Accounts Receivable Aging — Period 76
document_date: 2020-10-07
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 76

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 60,556 remains open under ticket FIN-0076. The preparer assessed the item as timing.

Meridian-related billings represented 43% of the activity in this record.
