---
document_id: NG-DD-0143
category: 03_finance
title: Accounts Payable Aging — Period 53
document_date: 2021-11-02
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 53

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 3,280,000.

## Review notes
A reconciling item of USD 43,743 remains open under ticket FIN-0053. The preparer assessed the item as timing.

Meridian-related billings represented 33% of the activity in this record.
