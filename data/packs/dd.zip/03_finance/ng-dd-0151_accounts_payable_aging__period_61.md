---
document_id: NG-DD-0151
category: 03_finance
title: Accounts Payable Aging — Period 61
document_date: 2021-06-19
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Payable Aging — Period 61

## Summary
Gross revenue recorded for the referenced period was USD 923,500. Cash balance was USD 3,170,000.

## Review notes
A reconciling item of USD 49,591 remains open under ticket FIN-0061. The preparer assessed the item as timing.

Meridian-related billings represented 41% of the activity in this record.
