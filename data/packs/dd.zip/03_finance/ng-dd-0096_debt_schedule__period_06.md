---
document_id: NG-DD-0096
category: 03_finance
title: Debt Schedule — Period 06
document_date: 2024-01-10
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 06

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 3,060,000.

## Debt schedule
Granite Bank term-loan principal was USD 1,620,000 at December 31, 2023, plus a USD 500,000 undrawn revolver. Management classified the term loan within other non-current liabilities rather than debt.
