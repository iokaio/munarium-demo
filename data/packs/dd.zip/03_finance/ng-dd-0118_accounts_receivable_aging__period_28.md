---
document_id: NG-DD-0118
category: 03_finance
title: Accounts Receivable Aging — Period 28
document_date: 2023-01-01
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 28

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 25,468 remains open under ticket FIN-0028. The preparer assessed the item as timing.

Meridian-related billings represented 34% of the activity in this record.
