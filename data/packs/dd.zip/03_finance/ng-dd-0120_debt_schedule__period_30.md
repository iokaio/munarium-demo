---
document_id: NG-DD-0120
category: 03_finance
title: Debt Schedule — Period 30
document_date: 2022-11-28
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 30

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 26,930 remains open under ticket FIN-0030. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 36% of the activity in this record.
