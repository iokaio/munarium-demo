---
document_id: NG-DD-0156
category: 03_finance
title: Bank Reconciliation — Period 66
document_date: 2021-03-26
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 66

## Summary
Gross revenue recorded for the referenced period was USD 1,041,000. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 53,246 remains open under ticket FIN-0066. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 33% of the activity in this record.
