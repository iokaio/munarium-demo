---
document_id: NG-DD-0157
category: 03_finance
title: Revenue Detail — Period 67
document_date: 2021-03-09
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 67

## Summary
Gross revenue recorded for the referenced period was USD 1,064,500. Cash balance was USD 2,840,000.

## Review notes
A reconciling item of USD 53,977 remains open under ticket FIN-0067. The preparer assessed the item as timing.

Meridian-related billings represented 34% of the activity in this record.
