---
document_id: NG-DD-0109
category: 03_finance
title: Revenue Detail — Period 19
document_date: 2023-06-03
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 19

## Summary
Gross revenue recorded for the referenced period was USD 1,064,500. Cash balance was USD 2,510,000.

## Review notes
A reconciling item of USD 18,889 remains open under ticket FIN-0019. The preparer assessed the item as timing.

Meridian-related billings represented 38% of the activity in this record.
