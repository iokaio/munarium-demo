---
document_id: NG-DD-0138
category: 03_finance
title: Journal Entry Support — Period 48
document_date: 2022-01-26
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Journal Entry Support — Period 48

## Summary
Gross revenue recorded for the referenced period was USD 900,000. Cash balance was USD 2,730,000.

## Review notes
A reconciling item of USD 40,088 remains open under ticket FIN-0048. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 41% of the activity in this record.
