---
document_id: NG-DD-0097
category: 03_finance
title: Budget Variance — Period 07
document_date: 2023-12-24
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 07

## Summary
Gross revenue recorded for the referenced period was USD 1,064,500. Cash balance was USD 3,170,000.

## Review notes
A reconciling item of USD 10,117 remains open under ticket FIN-0007. The preparer assessed the item as timing.

Meridian-related billings represented 39% of the activity in this record.
