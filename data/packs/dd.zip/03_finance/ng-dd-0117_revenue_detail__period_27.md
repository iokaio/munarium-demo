---
document_id: NG-DD-0117
category: 03_finance
title: Revenue Detail — Period 27
document_date: 2023-01-18
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Revenue Detail — Period 27

## Summary
Gross revenue recorded for the referenced period was USD 970,500. Cash balance was USD 2,400,000.

## Review notes
A reconciling item of USD 24,737 remains open under ticket FIN-0027. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 33% of the activity in this record.
