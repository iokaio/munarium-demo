---
document_id: NG-DD-0164
category: 03_finance
title: Bank Reconciliation — Period 74
document_date: 2020-11-10
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bank Reconciliation — Period 74

## Summary
Gross revenue recorded for the referenced period was USD 947,000. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 59,094 remains open under ticket FIN-0074. The preparer assessed the item as timing.

Meridian-related billings represented 41% of the activity in this record.
