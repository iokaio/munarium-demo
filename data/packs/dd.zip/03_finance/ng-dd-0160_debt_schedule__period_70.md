---
document_id: NG-DD-0160
category: 03_finance
title: Debt Schedule — Period 70
document_date: 2021-01-17
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Debt Schedule — Period 70

## Summary
Gross revenue recorded for the referenced period was USD 1,135,000. Cash balance was USD 3,170,000.

## Off-ledger obligation
The controller's spreadsheet estimates USD 920,000 of unrecorded customer service credits associated with the March 2024 outage. No reserve appears in the March close package.
