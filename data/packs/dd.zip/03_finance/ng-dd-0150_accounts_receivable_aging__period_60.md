---
document_id: NG-DD-0150
category: 03_finance
title: Accounts Receivable Aging — Period 60
document_date: 2021-07-06
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 60

## Summary
Gross revenue recorded for the referenced period was USD 900,000. Cash balance was USD 3,060,000.

## Review notes
A reconciling item of USD 48,860 remains open under ticket FIN-0060. The preparer assessed the item as requiring controller review.

Meridian-related billings represented 40% of the activity in this record.
