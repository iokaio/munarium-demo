---
document_id: NG-DD-0137
category: 03_finance
title: Budget Variance — Period 47
document_date: 2022-02-12
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Budget Variance — Period 47

## Summary
Gross revenue recorded for the referenced period was USD 1,158,500. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 39,357 remains open under ticket FIN-0047. The preparer assessed the item as timing.

Meridian-related billings represented 40% of the activity in this record.
