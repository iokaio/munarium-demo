---
document_id: NG-DD-0142
category: 03_finance
title: Accounts Receivable Aging — Period 52
document_date: 2021-11-19
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Accounts Receivable Aging — Period 52

## Summary
Gross revenue recorded for the referenced period was USD 994,000. Cash balance was USD 3,170,000.

## Receivable concentration
Meridian Health accounts receivable totaled USD 1,980,000, 47% of gross receivables. USD 610,000 was more than 90 days past due and disputed under service-level credits.
