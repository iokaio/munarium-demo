---
document_id: NG-DD-0155
category: 03_finance
title: Monthly Close Package — Period 65
document_date: 2021-04-12
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Monthly Close Package — Period 65

## Summary
Gross revenue recorded for the referenced period was USD 1,017,500. Cash balance was USD 2,620,000.

## Review notes
A reconciling item of USD 52,515 remains open under ticket FIN-0065. The preparer assessed the item as timing.

Meridian-related billings represented 32% of the activity in this record.
