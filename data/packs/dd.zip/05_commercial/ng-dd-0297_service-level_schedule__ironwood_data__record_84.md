---
document_id: NG-DD-0297
category: 05_commercial
title: Service-Level Schedule — Ironwood Data — Record 84
document_date: 2023-02-27
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Ironwood Data — Record 84

## Parties and economics
Counterparty: Ironwood Data. Annual contract value: USD 4,632,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 4,632,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00084 with estimated exposure of USD 75,000.
