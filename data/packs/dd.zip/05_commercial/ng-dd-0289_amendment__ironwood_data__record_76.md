---
document_id: NG-DD-0289
category: 05_commercial
title: Amendment — Ironwood Data — Record 76
document_date: 2023-07-13
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Ironwood Data — Record 76

## Parties and economics
Counterparty: Ironwood Data. Annual contract value: USD 4,208,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,208,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00076 with estimated exposure of USD 100,000.
