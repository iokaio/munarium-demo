---
document_id: NG-DD-0273
category: 05_commercial
title: Service-Level Schedule — NovaWell Labs — Record 60
document_date: 2020-01-12
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — NovaWell Labs — Record 60

## Parties and economics
Counterparty: NovaWell Labs. Annual contract value: USD 3,360,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,360,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00060 with estimated exposure of USD 150,000.
