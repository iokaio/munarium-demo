---
document_id: NG-DD-0296
category: 05_commercial
title: Side Letter — VectorPay — Record 83
document_date: 2023-03-16
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — VectorPay — Record 83

## Parties and economics
Counterparty: VectorPay. Annual contract value: USD 4,579,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,579,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00083 with estimated exposure of USD 50,000.
