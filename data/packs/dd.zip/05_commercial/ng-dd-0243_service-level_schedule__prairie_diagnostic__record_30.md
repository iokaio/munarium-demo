---
document_id: NG-DD-0243
category: 05_commercial
title: Service-Level Schedule — Prairie Diagnostic — Record 30
document_date: 2021-06-05
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Prairie Diagnostic — Record 30

## Parties and economics
Counterparty: Prairie Diagnostic. Annual contract value: USD 1,770,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,770,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00030 with estimated exposure of USD 75,000.
