---
document_id: NG-DD-0307
category: 05_commercial
title: Amendment — Pinecone Telecom — Record 94
document_date: 2022-09-10
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Pinecone Telecom — Record 94

## Parties and economics
Counterparty: Pinecone Telecom. Annual contract value: USD 5,162,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 5,162,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00094 with estimated exposure of USD 100,000.
