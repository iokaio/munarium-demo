---
document_id: NG-DD-0298
category: 05_commercial
title: Master Services Agreement — Kestrel Support — Record 85
document_date: 2023-02-10
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — Kestrel Support — Record 85

## Parties and economics
Counterparty: Kestrel Support. Annual contract value: USD 4,685,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,685,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00085 with estimated exposure of USD 100,000.
