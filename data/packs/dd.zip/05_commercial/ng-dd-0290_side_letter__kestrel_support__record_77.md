---
document_id: NG-DD-0290
category: 05_commercial
title: Side Letter — Kestrel Support — Record 77
document_date: 2023-06-26
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — Kestrel Support — Record 77

## Parties and economics
Counterparty: Kestrel Support. Annual contract value: USD 4,261,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 4,261,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00077 with estimated exposure of USD 125,000.
