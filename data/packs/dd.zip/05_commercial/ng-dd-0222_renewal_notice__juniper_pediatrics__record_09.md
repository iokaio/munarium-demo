---
document_id: NG-DD-0222
category: 05_commercial
title: Renewal Notice — Juniper Pediatrics — Record 09
document_date: 2022-05-28
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Juniper Pediatrics — Record 09

## Parties and economics
Counterparty: Juniper Pediatrics. Annual contract value: USD 657,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 657,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00009 with estimated exposure of USD 0.
