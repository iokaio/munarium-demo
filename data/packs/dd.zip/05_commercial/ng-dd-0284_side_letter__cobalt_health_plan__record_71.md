---
document_id: NG-DD-0284
category: 05_commercial
title: Side Letter — Cobalt Health Plan — Record 71
document_date: 2023-10-06
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — Cobalt Health Plan — Record 71

## Parties and economics
Counterparty: Cobalt Health Plan. Annual contract value: USD 3,943,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,943,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00071 with estimated exposure of USD 200,000.
