---
document_id: NG-DD-0254
category: 05_commercial
title: Side Letter — SummitCare Network — Record 41
document_date: 2020-11-30
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — SummitCare Network — Record 41

## Parties and economics
Counterparty: SummitCare Network. Annual contract value: USD 2,353,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 2,353,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00041 with estimated exposure of USD 125,000.
