---
document_id: NG-DD-0229
category: 05_commercial
title: Amendment — Oriole Medical Group — Record 16
document_date: 2022-01-29
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Oriole Medical Group — Record 16

## Parties and economics
Counterparty: Oriole Medical Group. Annual contract value: USD 1,028,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,028,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00016 with estimated exposure of USD 175,000.
