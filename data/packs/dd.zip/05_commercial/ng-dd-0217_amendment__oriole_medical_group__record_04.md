---
document_id: NG-DD-0217
category: 05_commercial
title: Amendment — Oriole Medical Group — Record 04
document_date: 2022-08-21
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Oriole Medical Group — Record 04

## Parties and economics
Counterparty: Oriole Medical Group. Annual contract value: USD 392,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 392,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00004 with estimated exposure of USD 100,000.
