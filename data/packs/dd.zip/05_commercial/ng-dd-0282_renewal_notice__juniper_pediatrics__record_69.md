---
document_id: NG-DD-0282
category: 05_commercial
title: Renewal Notice — Juniper Pediatrics — Record 69
document_date: 2023-11-09
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Juniper Pediatrics — Record 69

## Parties and economics
Counterparty: Juniper Pediatrics. Annual contract value: USD 3,837,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,837,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00069 with estimated exposure of USD 150,000.
