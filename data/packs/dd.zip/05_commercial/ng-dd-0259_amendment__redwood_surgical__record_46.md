---
document_id: NG-DD-0259
category: 05_commercial
title: Amendment — Redwood Surgical — Record 46
document_date: 2020-09-06
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Redwood Surgical — Record 46

## Parties and economics
Counterparty: Redwood Surgical. Annual contract value: USD 2,618,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 2,618,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00046 with estimated exposure of USD 25,000.
