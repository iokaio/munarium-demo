---
document_id: NG-DD-0253
category: 05_commercial
title: Amendment — Oriole Medical Group — Record 40
document_date: 2020-12-17
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Oriole Medical Group — Record 40

## Parties and economics
Counterparty: Oriole Medical Group. Annual contract value: USD 2,300,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 2,300,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00040 with estimated exposure of USD 100,000.
