---
document_id: NG-DD-0299
category: 05_commercial
title: Order Form — Pinecone Telecom — Record 86
document_date: 2023-01-24
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Pinecone Telecom — Record 86

## Parties and economics
Counterparty: Pinecone Telecom. Annual contract value: USD 4,738,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,738,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00086 with estimated exposure of USD 125,000.
