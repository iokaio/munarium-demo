---
document_id: NG-DD-0304
category: 05_commercial
title: Master Services Agreement — VectorPay — Record 91
document_date: 2022-10-31
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — VectorPay — Record 91

## Parties and economics
Counterparty: VectorPay. Annual contract value: USD 5,003,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 5,003,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00091 with estimated exposure of USD 25,000.
