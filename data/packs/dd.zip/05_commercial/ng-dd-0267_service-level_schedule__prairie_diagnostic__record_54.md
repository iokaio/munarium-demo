---
document_id: NG-DD-0267
category: 05_commercial
title: Service-Level Schedule — Prairie Diagnostic — Record 54
document_date: 2020-04-23
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Prairie Diagnostic — Record 54

## Parties and economics
Counterparty: Prairie Diagnostic. Annual contract value: USD 3,042,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,042,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00054 with estimated exposure of USD 0.
