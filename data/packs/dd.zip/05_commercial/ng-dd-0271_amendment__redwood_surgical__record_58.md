---
document_id: NG-DD-0271
category: 05_commercial
title: Amendment — Redwood Surgical — Record 58
document_date: 2020-02-15
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Redwood Surgical — Record 58

## Parties and economics
Counterparty: Redwood Surgical. Annual contract value: USD 3,254,000. Initial term: 36 months. Payment terms: net 45.

## Government customer restriction
NGS Federal LLC's subcontract prohibits assignment by operation of law and requires prime-contractor consent before a change of control. Estimated backlog is USD 2,400,000.
