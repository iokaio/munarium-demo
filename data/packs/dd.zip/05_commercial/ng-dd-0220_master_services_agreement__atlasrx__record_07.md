---
document_id: NG-DD-0220
category: 05_commercial
title: Master Services Agreement — AtlasRx — Record 07
document_date: 2022-07-01
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — AtlasRx — Record 07

## Parties and economics
Counterparty: AtlasRx. Annual contract value: USD 551,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 551,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00007 with estimated exposure of USD 175,000.
