---
document_id: NG-DD-0292
category: 05_commercial
title: Master Services Agreement — Axiom Analytics — Record 79
document_date: 2023-05-23
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — Axiom Analytics — Record 79

## Parties and economics
Counterparty: Axiom Analytics. Annual contract value: USD 4,367,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,367,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00079 with estimated exposure of USD 175,000.
