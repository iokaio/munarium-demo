---
document_id: NG-DD-0269
category: 05_commercial
title: Order Form — Harborview Health — Record 56
document_date: 2020-03-20
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Harborview Health — Record 56

## Parties and economics
Counterparty: Harborview Health. Annual contract value: USD 3,148,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 3,148,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00056 with estimated exposure of USD 50,000.
