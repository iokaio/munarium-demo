---
document_id: NG-DD-0215
category: 05_commercial
title: Order Form — Blue Mesa Clinics — Record 02
document_date: 2022-09-24
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Blue Mesa Clinics — Record 02

## Parties and economics
Counterparty: Blue Mesa Clinics. Annual contract value: USD 286,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 286,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00002 with estimated exposure of USD 50,000.
