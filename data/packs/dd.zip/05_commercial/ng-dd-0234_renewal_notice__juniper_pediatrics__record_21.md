---
document_id: NG-DD-0234
category: 05_commercial
title: Renewal Notice — Juniper Pediatrics — Record 21
document_date: 2021-11-05
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Juniper Pediatrics — Record 21

## Parties and economics
Counterparty: Juniper Pediatrics. Annual contract value: USD 1,293,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 1,293,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00021 with estimated exposure of USD 75,000.
