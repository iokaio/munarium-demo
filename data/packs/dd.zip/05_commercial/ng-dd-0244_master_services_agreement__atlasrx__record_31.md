---
document_id: NG-DD-0244
category: 05_commercial
title: Master Services Agreement — AtlasRx — Record 31
document_date: 2021-05-19
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — AtlasRx — Record 31

## Parties and economics
Counterparty: AtlasRx. Annual contract value: USD 1,823,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,823,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00031 with estimated exposure of USD 100,000.
