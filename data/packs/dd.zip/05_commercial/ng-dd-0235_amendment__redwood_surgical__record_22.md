---
document_id: NG-DD-0235
category: 05_commercial
title: Amendment — Redwood Surgical — Record 22
document_date: 2021-10-19
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Redwood Surgical — Record 22

## Parties and economics
Counterparty: Redwood Surgical. Annual contract value: USD 1,346,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: termination right. Liability cap: USD 1,346,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00022 with estimated exposure of USD 100,000.
