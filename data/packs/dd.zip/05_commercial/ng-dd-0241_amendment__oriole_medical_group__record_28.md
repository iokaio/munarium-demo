---
document_id: NG-DD-0241
category: 05_commercial
title: Amendment — Oriole Medical Group — Record 28
document_date: 2021-07-09
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Oriole Medical Group — Record 28

## Parties and economics
Counterparty: Oriole Medical Group. Annual contract value: USD 1,664,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 1,664,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00028 with estimated exposure of USD 25,000.
