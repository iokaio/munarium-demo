---
document_id: NG-DD-0236
category: 05_commercial
title: Side Letter — Cobalt Health Plan — Record 23
document_date: 2021-10-02
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — Cobalt Health Plan — Record 23

## Parties and economics
Counterparty: Cobalt Health Plan. Annual contract value: USD 1,399,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,399,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00023 with estimated exposure of USD 125,000.
