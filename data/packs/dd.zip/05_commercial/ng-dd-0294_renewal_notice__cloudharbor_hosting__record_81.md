---
document_id: NG-DD-0294
category: 05_commercial
title: Renewal Notice — CloudHarbor Hosting — Record 81
document_date: 2023-04-19
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — CloudHarbor Hosting — Record 81

## Parties and economics
Counterparty: CloudHarbor Hosting. Annual contract value: USD 4,473,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,473,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00081 with estimated exposure of USD 0.
