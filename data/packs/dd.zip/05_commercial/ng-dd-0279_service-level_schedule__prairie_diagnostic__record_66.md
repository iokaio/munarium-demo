---
document_id: NG-DD-0279
category: 05_commercial
title: Service-Level Schedule — Prairie Diagnostic — Record 66
document_date: 2023-12-30
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Prairie Diagnostic — Record 66

## Parties and economics
Counterparty: Prairie Diagnostic. Annual contract value: USD 3,678,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: termination right. Liability cap: USD 3,678,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00066 with estimated exposure of USD 75,000.
