---
document_id: NG-DD-0309
category: 05_commercial
title: Service-Level Schedule — Northstar Devices — Record 96
document_date: 2022-08-07
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Northstar Devices — Record 96

## Parties and economics
Counterparty: Northstar Devices. Annual contract value: USD 5,268,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 5,268,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00096 with estimated exposure of USD 150,000.
