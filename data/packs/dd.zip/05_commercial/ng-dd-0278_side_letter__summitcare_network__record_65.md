---
document_id: NG-DD-0278
category: 05_commercial
title: Side Letter — SummitCare Network — Record 65
document_date: 2024-01-16
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — SummitCare Network — Record 65

## Parties and economics
Counterparty: SummitCare Network. Annual contract value: USD 3,625,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,625,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00065 with estimated exposure of USD 50,000.
