---
document_id: NG-DD-0286
category: 05_commercial
title: Master Services Agreement — CloudHarbor Hosting — Record 73
document_date: 2023-09-02
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — CloudHarbor Hosting — Record 73

## Parties and economics
Counterparty: CloudHarbor Hosting. Annual contract value: USD 4,049,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,049,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00073 with estimated exposure of USD 25,000.
