---
document_id: NG-DD-0266
category: 05_commercial
title: Side Letter — SummitCare Network — Record 53
document_date: 2020-05-10
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — SummitCare Network — Record 53

## Parties and economics
Counterparty: SummitCare Network. Annual contract value: USD 2,989,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 2,989,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00053 with estimated exposure of USD 200,000.
