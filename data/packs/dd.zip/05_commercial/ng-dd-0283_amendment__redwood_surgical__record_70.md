---
document_id: NG-DD-0283
category: 05_commercial
title: Amendment — Redwood Surgical — Record 70
document_date: 2023-10-23
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Redwood Surgical — Record 70

## Parties and economics
Counterparty: Redwood Surgical. Annual contract value: USD 3,890,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 3,890,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00070 with estimated exposure of USD 175,000.
