---
document_id: NG-DD-0287
category: 05_commercial
title: Order Form — SableWorks Consulting — Record 74
document_date: 2023-08-16
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — SableWorks Consulting — Record 74

## Parties and economics
Counterparty: SableWorks Consulting. Annual contract value: USD 4,102,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,102,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00074 with estimated exposure of USD 50,000.
