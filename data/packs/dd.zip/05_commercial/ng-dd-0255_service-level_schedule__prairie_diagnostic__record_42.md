---
document_id: NG-DD-0255
category: 05_commercial
title: Service-Level Schedule — Prairie Diagnostic — Record 42
document_date: 2020-11-13
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Prairie Diagnostic — Record 42

## Parties and economics
Counterparty: Prairie Diagnostic. Annual contract value: USD 2,406,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 2,406,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00042 with estimated exposure of USD 150,000.
