---
document_id: NG-DD-0219
category: 05_commercial
title: Service-Level Schedule — Prairie Diagnostic — Record 06
document_date: 2022-07-18
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Prairie Diagnostic — Record 06

## Parties and economics
Counterparty: Prairie Diagnostic. Annual contract value: USD 498,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 498,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00006 with estimated exposure of USD 150,000.
