---
document_id: NG-DD-0233
category: 05_commercial
title: Order Form — Harborview Health — Record 20
document_date: 2021-11-22
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Harborview Health — Record 20

## Parties and economics
Counterparty: Harborview Health. Annual contract value: USD 1,240,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,240,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00020 with estimated exposure of USD 50,000.
