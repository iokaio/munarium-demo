---
document_id: NG-DD-0218
category: 05_commercial
title: Side Letter — SummitCare Network — Record 05
document_date: 2022-08-04
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — SummitCare Network — Record 05

## Parties and economics
Counterparty: SummitCare Network. Annual contract value: USD 445,000. Initial term: 36 months. Payment terms: net 60.

## Meridian side letter
Northgate granted Meridian a most-favored-customer covenant, a USD 750,000 change-of-control credit, and immediate termination rights if the buyer owns a competing clinical workflow platform. The side letter says it controls over the master agreement.
