---
document_id: NG-DD-0281
category: 05_commercial
title: Order Form — Harborview Health — Record 68
document_date: 2023-11-26
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Harborview Health — Record 68

## Parties and economics
Counterparty: Harborview Health. Annual contract value: USD 3,784,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,784,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00068 with estimated exposure of USD 125,000.
