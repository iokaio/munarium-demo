---
document_id: NG-DD-0239
category: 05_commercial
title: Order Form — Blue Mesa Clinics — Record 26
document_date: 2021-08-12
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Blue Mesa Clinics — Record 26

## Parties and economics
Counterparty: Blue Mesa Clinics. Annual contract value: USD 1,558,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,558,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00026 with estimated exposure of USD 200,000.
