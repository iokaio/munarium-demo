---
document_id: NG-DD-0308
category: 05_commercial
title: Side Letter — Axiom Analytics — Record 95
document_date: 2022-08-24
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — Axiom Analytics — Record 95

## Parties and economics
Counterparty: Axiom Analytics. Annual contract value: USD 5,215,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 5,215,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00095 with estimated exposure of USD 125,000.
