---
document_id: NG-DD-0221
category: 05_commercial
title: Order Form — Harborview Health — Record 08
document_date: 2022-06-14
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Harborview Health — Record 08

## Parties and economics
Counterparty: Harborview Health. Annual contract value: USD 604,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 604,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00008 with estimated exposure of USD 200,000.
