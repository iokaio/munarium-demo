---
document_id: NG-DD-0225
category: 05_commercial
title: Service-Level Schedule — NovaWell Labs — Record 12
document_date: 2022-04-07
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — NovaWell Labs — Record 12

## Parties and economics
Counterparty: NovaWell Labs. Annual contract value: USD 816,000. Initial term: 36 months. Payment terms: net 30.

## Concentration report
The account plan attributes 38% of FY2023 revenue to Meridian based on audited revenue. The seller presentation uses 37.6% based on adjusted revenue.
