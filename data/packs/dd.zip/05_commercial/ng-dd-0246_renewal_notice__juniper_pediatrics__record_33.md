---
document_id: NG-DD-0246
category: 05_commercial
title: Renewal Notice — Juniper Pediatrics — Record 33
document_date: 2021-04-15
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Juniper Pediatrics — Record 33

## Parties and economics
Counterparty: Juniper Pediatrics. Annual contract value: USD 1,929,000. Initial term: 36 months. Payment terms: net 30.

## Oral concession
Sales notes state that Blue Mesa Clinics may cancel without penalty if uptime falls below 99.9% twice in a rolling year. The signed order form contains no such right, but email records show the CFO approved the concession.
