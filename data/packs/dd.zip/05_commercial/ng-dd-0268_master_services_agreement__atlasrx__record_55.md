---
document_id: NG-DD-0268
category: 05_commercial
title: Master Services Agreement — AtlasRx — Record 55
document_date: 2020-04-06
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — AtlasRx — Record 55

## Parties and economics
Counterparty: AtlasRx. Annual contract value: USD 3,095,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: termination right. Liability cap: USD 3,095,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00055 with estimated exposure of USD 25,000.
