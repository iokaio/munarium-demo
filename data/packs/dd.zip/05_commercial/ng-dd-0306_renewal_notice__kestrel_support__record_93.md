---
document_id: NG-DD-0306
category: 05_commercial
title: Renewal Notice — Kestrel Support — Record 93
document_date: 2022-09-27
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Kestrel Support — Record 93

## Parties and economics
Counterparty: Kestrel Support. Annual contract value: USD 5,109,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 5,109,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00093 with estimated exposure of USD 75,000.
