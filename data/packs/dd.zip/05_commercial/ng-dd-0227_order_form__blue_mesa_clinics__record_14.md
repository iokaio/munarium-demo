---
document_id: NG-DD-0227
category: 05_commercial
title: Order Form — Blue Mesa Clinics — Record 14
document_date: 2022-03-04
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Blue Mesa Clinics — Record 14

## Parties and economics
Counterparty: Blue Mesa Clinics. Annual contract value: USD 922,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 922,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00014 with estimated exposure of USD 125,000.
