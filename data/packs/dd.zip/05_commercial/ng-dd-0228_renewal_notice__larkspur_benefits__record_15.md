---
document_id: NG-DD-0228
category: 05_commercial
title: Renewal Notice — Larkspur Benefits — Record 15
document_date: 2022-02-15
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Larkspur Benefits — Record 15

## Parties and economics
Counterparty: Larkspur Benefits. Annual contract value: USD 975,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 975,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00015 with estimated exposure of USD 150,000.
