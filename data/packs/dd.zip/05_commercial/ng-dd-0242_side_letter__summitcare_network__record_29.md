---
document_id: NG-DD-0242
category: 05_commercial
title: Side Letter — SummitCare Network — Record 29
document_date: 2021-06-22
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — SummitCare Network — Record 29

## Parties and economics
Counterparty: SummitCare Network. Annual contract value: USD 1,717,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,717,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00029 with estimated exposure of USD 50,000.
