---
document_id: NG-DD-0288
category: 05_commercial
title: Renewal Notice — VectorPay — Record 75
document_date: 2023-07-30
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — VectorPay — Record 75

## Parties and economics
Counterparty: VectorPay. Annual contract value: USD 4,155,000. Initial term: 36 months. Payment terms: net 30.

## Cloud commitment
CloudHarbor Hosting requires minimum spend of USD 210,000 per month through December 2026. Early termination triggers 80% of remaining minimum fees, and assignment requires consent not to be unreasonably withheld.
