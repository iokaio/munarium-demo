---
document_id: NG-DD-0300
category: 05_commercial
title: Renewal Notice — Axiom Analytics — Record 87
document_date: 2023-01-07
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Axiom Analytics — Record 87

## Parties and economics
Counterparty: Axiom Analytics. Annual contract value: USD 4,791,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,791,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00087 with estimated exposure of USD 150,000.
