---
document_id: NG-DD-0257
category: 05_commercial
title: Order Form — Harborview Health — Record 44
document_date: 2020-10-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Harborview Health — Record 44

## Parties and economics
Counterparty: Harborview Health. Annual contract value: USD 2,512,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: termination right. Liability cap: USD 2,512,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00044 with estimated exposure of USD 200,000.
