---
document_id: NG-DD-0305
category: 05_commercial
title: Order Form — Ironwood Data — Record 92
document_date: 2022-10-14
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Ironwood Data — Record 92

## Parties and economics
Counterparty: Ironwood Data. Annual contract value: USD 5,056,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 5,056,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00092 with estimated exposure of USD 50,000.
