---
document_id: NG-DD-0295
category: 05_commercial
title: Amendment — SableWorks Consulting — Record 82
document_date: 2023-04-02
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — SableWorks Consulting — Record 82

## Parties and economics
Counterparty: SableWorks Consulting. Annual contract value: USD 4,526,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,526,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00082 with estimated exposure of USD 25,000.
