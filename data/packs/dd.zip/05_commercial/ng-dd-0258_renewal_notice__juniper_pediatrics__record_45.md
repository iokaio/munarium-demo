---
document_id: NG-DD-0258
category: 05_commercial
title: Renewal Notice — Juniper Pediatrics — Record 45
document_date: 2020-09-23
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Juniper Pediatrics — Record 45

## Parties and economics
Counterparty: Juniper Pediatrics. Annual contract value: USD 2,565,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 2,565,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00045 with estimated exposure of USD 0.
