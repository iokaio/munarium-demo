---
document_id: NG-DD-0291
category: 05_commercial
title: Service-Level Schedule — Pinecone Telecom — Record 78
document_date: 2023-06-09
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — Pinecone Telecom — Record 78

## Parties and economics
Counterparty: Pinecone Telecom. Annual contract value: USD 4,314,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,314,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00078 with estimated exposure of USD 150,000.
