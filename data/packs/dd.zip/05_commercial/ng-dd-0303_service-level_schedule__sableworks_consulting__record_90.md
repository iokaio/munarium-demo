---
document_id: NG-DD-0303
category: 05_commercial
title: Service-Level Schedule — SableWorks Consulting — Record 90
document_date: 2022-11-17
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Service-Level Schedule — SableWorks Consulting — Record 90

## Parties and economics
Counterparty: SableWorks Consulting. Annual contract value: USD 4,950,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,950,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00090 with estimated exposure of USD 0.
