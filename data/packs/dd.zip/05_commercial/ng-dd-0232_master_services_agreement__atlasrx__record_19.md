---
document_id: NG-DD-0232
category: 05_commercial
title: Master Services Agreement — AtlasRx — Record 19
document_date: 2021-12-09
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — AtlasRx — Record 19

## Parties and economics
Counterparty: AtlasRx. Annual contract value: USD 1,187,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,187,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00019 with estimated exposure of USD 25,000.
