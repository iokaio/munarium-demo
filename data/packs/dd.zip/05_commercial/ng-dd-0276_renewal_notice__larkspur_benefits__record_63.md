---
document_id: NG-DD-0276
category: 05_commercial
title: Renewal Notice — Larkspur Benefits — Record 63
document_date: 2024-02-19
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Larkspur Benefits — Record 63

## Parties and economics
Counterparty: Larkspur Benefits. Annual contract value: USD 3,519,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 3,519,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00063 with estimated exposure of USD 0.
