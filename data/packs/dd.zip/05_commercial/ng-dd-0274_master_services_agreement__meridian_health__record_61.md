---
document_id: NG-DD-0274
category: 05_commercial
title: Master Services Agreement — Meridian Health — Record 61
document_date: 2024-03-24
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — Meridian Health — Record 61

## Parties and economics
Counterparty: Meridian Health. Annual contract value: USD 3,413,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,413,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00061 with estimated exposure of USD 175,000.
