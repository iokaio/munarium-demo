---
document_id: NG-DD-0223
category: 05_commercial
title: Amendment — Redwood Surgical — Record 10
document_date: 2022-05-11
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Redwood Surgical — Record 10

## Parties and economics
Counterparty: Redwood Surgical. Annual contract value: USD 710,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 710,000. Auto-renewal notice window: 120 days.

Contract owner notes an open commercial issue under CRM-00010 with estimated exposure of USD 25,000.
