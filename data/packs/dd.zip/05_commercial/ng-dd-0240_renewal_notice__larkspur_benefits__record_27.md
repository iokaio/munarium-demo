---
document_id: NG-DD-0240
category: 05_commercial
title: Renewal Notice — Larkspur Benefits — Record 27
document_date: 2021-07-26
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Renewal Notice — Larkspur Benefits — Record 27

## Parties and economics
Counterparty: Larkspur Benefits. Annual contract value: USD 1,611,000. Initial term: 36 months. Payment terms: net 30.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,611,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00027 with estimated exposure of USD 0.
