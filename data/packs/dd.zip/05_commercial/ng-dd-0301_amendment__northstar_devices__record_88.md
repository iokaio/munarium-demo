---
document_id: NG-DD-0301
category: 05_commercial
title: Amendment — Northstar Devices — Record 88
document_date: 2022-12-21
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Northstar Devices — Record 88

## Parties and economics
Counterparty: Northstar Devices. Annual contract value: USD 4,844,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: termination right. Liability cap: USD 4,844,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00088 with estimated exposure of USD 175,000.
