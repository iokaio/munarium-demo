---
document_id: NG-DD-0293
category: 05_commercial
title: Order Form — Northstar Devices — Record 80
document_date: 2023-05-06
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Order Form — Northstar Devices — Record 80

## Parties and economics
Counterparty: Northstar Devices. Annual contract value: USD 4,420,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 4,420,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00080 with estimated exposure of USD 200,000.
