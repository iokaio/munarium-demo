---
document_id: NG-DD-0262
category: 05_commercial
title: Master Services Agreement — Meridian Health — Record 49
document_date: 2020-07-17
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — Meridian Health — Record 49

## Parties and economics
Counterparty: Meridian Health. Annual contract value: USD 2,777,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: consent required. Liability cap: USD 2,777,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00049 with estimated exposure of USD 100,000.
