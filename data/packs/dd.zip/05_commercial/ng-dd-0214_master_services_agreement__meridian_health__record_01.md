---
document_id: NG-DD-0214
category: 05_commercial
title: Master Services Agreement — Meridian Health — Record 01
document_date: 2022-10-11
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — Meridian Health — Record 01

## Parties and economics
Counterparty: Meridian Health. Annual contract value: USD 233,000. Initial term: 36 months. Payment terms: net 45.

## Meridian master terms
Meridian Health may terminate on 90 days' notice following any direct or indirect change of control of Northgate. Annual contract value is USD 5,300,000.
