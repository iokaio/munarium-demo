---
document_id: NG-DD-0260
category: 05_commercial
title: Side Letter — Cobalt Health Plan — Record 47
document_date: 2020-08-20
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — Cobalt Health Plan — Record 47

## Parties and economics
Counterparty: Cobalt Health Plan. Annual contract value: USD 2,671,000. Initial term: 36 months. Payment terms: net 60.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 2,671,000. Auto-renewal notice window: 150 days.

Contract owner notes an open commercial issue under CRM-00047 with estimated exposure of USD 50,000.
