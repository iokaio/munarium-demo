---
document_id: NG-DD-0277
category: 05_commercial
title: Amendment — Oriole Medical Group — Record 64
document_date: 2024-02-02
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Amendment — Oriole Medical Group — Record 64

## Parties and economics
Counterparty: Oriole Medical Group. Annual contract value: USD 3,572,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 3,572,000. Auto-renewal notice window: 60 days.

Contract owner notes an open commercial issue under CRM-00064 with estimated exposure of USD 25,000.
