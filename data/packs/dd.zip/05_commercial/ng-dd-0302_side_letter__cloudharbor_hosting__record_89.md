---
document_id: NG-DD-0302
category: 05_commercial
title: Side Letter — CloudHarbor Hosting — Record 89
document_date: 2022-12-04
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Side Letter — CloudHarbor Hosting — Record 89

## Parties and economics
Counterparty: CloudHarbor Hosting. Annual contract value: USD 4,897,000. Initial term: 36 months. Payment terms: net 60.

## Related-party vendor
SableWorks Consulting provides product engineering at USD 42,000 per month. Director Marcus Bell owns 35% of SableWorks. The agreement was not approved under the related-party transactions policy.
