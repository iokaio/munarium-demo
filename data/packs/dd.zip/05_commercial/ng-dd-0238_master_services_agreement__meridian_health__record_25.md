---
document_id: NG-DD-0238
category: 05_commercial
title: Master Services Agreement — Meridian Health — Record 25
document_date: 2021-08-29
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Master Services Agreement — Meridian Health — Record 25

## Parties and economics
Counterparty: Meridian Health. Annual contract value: USD 1,505,000. Initial term: 36 months. Payment terms: net 45.

## Key terms
Change-of-control treatment: no express restriction. Liability cap: USD 1,505,000. Auto-renewal notice window: 90 days.

Contract owner notes an open commercial issue under CRM-00025 with estimated exposure of USD 175,000.
