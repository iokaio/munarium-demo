---
document_id: NG-DD-0003
category: 01_corporate
title: Officer Certificate — Record 03
document_date: 2024-02-10
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Officer Certificate — Record 03

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 57,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2023-003. No undisclosed dividend was approved in this record.
