---
document_id: NG-DD-0028
category: 01_corporate
title: Subsidiary Register — Record 28
document_date: 2022-12-12
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Subsidiary Register — Record 28

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Health UK Ltd, delegated ordinary-course signing authority up to USD 120,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2023-028. No undisclosed dividend was approved in this record.
