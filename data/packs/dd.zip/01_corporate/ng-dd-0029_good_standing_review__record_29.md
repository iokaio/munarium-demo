---
document_id: NG-DD-0029
category: 01_corporate
title: Good Standing Review — Record 29
document_date: 2022-11-25
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Good Standing Review — Record 29

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 122,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2024-029. No undisclosed dividend was approved in this record.
