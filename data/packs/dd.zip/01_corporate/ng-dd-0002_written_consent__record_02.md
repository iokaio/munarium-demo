---
document_id: NG-DD-0002
category: 01_corporate
title: Written Consent — Record 02
document_date: 2024-02-27
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Written Consent — Record 02

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 55,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2022-002. No undisclosed dividend was approved in this record.
