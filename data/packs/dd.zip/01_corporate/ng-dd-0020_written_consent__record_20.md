---
document_id: NG-DD-0020
category: 01_corporate
title: Written Consent — Record 20
document_date: 2023-04-27
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Written Consent — Record 20

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 100,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2020-020. No undisclosed dividend was approved in this record.
