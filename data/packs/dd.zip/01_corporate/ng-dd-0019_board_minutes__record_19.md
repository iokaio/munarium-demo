---
document_id: NG-DD-0019
category: 01_corporate
title: Board Minutes — Record 19
document_date: 2023-05-14
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Board Minutes — Record 19

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Subsidiary status
The register lists Northgate Analytics LLC and Northgate Health UK Ltd. It does not list NGS Federal LLC, although federal contracting records identify it as a wholly owned subsidiary.
