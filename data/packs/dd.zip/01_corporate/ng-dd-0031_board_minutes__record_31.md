---
document_id: NG-DD-0031
category: 01_corporate
title: Board Minutes — Record 31
document_date: 2022-10-22
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Board Minutes — Record 31

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Records exception
Minutes for the September 2022 meeting could not be located. The missing meeting reportedly covered the VectorPay incident and the Granite Bank financing proposal.
