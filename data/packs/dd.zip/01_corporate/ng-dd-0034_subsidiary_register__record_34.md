---
document_id: NG-DD-0034
category: 01_corporate
title: Subsidiary Register — Record 34
document_date: 2022-09-01
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Subsidiary Register — Record 34

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Health UK Ltd, delegated ordinary-course signing authority up to USD 135,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2024-034. No undisclosed dividend was approved in this record.
