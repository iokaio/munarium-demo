---
document_id: NG-DD-0035
category: 01_corporate
title: Good Standing Review — Record 35
document_date: 2022-08-15
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Good Standing Review — Record 35

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 137,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2020-035. No undisclosed dividend was approved in this record.
