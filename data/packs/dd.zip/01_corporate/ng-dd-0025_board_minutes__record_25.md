---
document_id: NG-DD-0025
category: 01_corporate
title: Board Minutes — Record 25
document_date: 2023-02-01
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Board Minutes — Record 25

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Health UK Ltd, delegated ordinary-course signing authority up to USD 112,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2020-025. No undisclosed dividend was approved in this record.
