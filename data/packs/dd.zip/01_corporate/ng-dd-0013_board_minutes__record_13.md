---
document_id: NG-DD-0013
category: 01_corporate
title: Board Minutes — Record 13
document_date: 2023-08-24
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Board Minutes — Record 13

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Transaction discussion
The directors authorized management to enter exclusivity with Aster Peak through June 30, 2024. Approval does not constitute approval of the merger agreement.

Director Marcus Bell disclosed that he owns 35% of SableWorks Consulting and abstained from the vote on vendor-contract treatment.
