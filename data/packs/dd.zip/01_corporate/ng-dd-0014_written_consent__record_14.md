---
document_id: NG-DD-0014
category: 01_corporate
title: Written Consent — Record 14
document_date: 2023-08-07
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Written Consent — Record 14

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 85,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2024-014. No undisclosed dividend was approved in this record.
