---
document_id: NG-DD-0018
category: 01_corporate
title: Governance Questionnaire — Record 18
document_date: 2023-05-31
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Governance Questionnaire — Record 18

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 95,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2023-018. No undisclosed dividend was approved in this record.
