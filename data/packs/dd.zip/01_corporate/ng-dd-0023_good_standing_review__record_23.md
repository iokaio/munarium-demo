---
document_id: NG-DD-0023
category: 01_corporate
title: Good Standing Review — Record 23
document_date: 2023-03-07
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Good Standing Review — Record 23

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 107,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2023-023. No undisclosed dividend was approved in this record.
