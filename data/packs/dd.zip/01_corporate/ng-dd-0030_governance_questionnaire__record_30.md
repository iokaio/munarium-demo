---
document_id: NG-DD-0030
category: 01_corporate
title: Governance Questionnaire — Record 30
document_date: 2022-11-08
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Governance Questionnaire — Record 30

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 125,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2020-030. No undisclosed dividend was approved in this record.
