---
document_id: NG-DD-0015
category: 01_corporate
title: Officer Certificate — Record 15
document_date: 2023-07-21
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Officer Certificate — Record 15

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 87,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2020-015. No undisclosed dividend was approved in this record.
