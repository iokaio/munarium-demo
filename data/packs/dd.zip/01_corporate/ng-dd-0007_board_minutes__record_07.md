---
document_id: NG-DD-0007
category: 01_corporate
title: Board Minutes — Record 07
document_date: 2023-12-04
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Board Minutes — Record 07

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Financing approval
The board approved a USD 2,000,000 term loan from Granite Bank on February 15, 2023. The loan matures in 2027 and is secured by substantially all company assets.

This approval conflicts with later management statements that the company has no long-term debt.
