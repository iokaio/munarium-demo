---
document_id: NG-DD-0041
category: 01_corporate
title: Good Standing Review — Record 41
document_date: 2022-05-05
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Good Standing Review — Record 41

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 152,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2021-041. No undisclosed dividend was approved in this record.
