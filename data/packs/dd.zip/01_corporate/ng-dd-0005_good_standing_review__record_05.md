---
document_id: NG-DD-0005
category: 01_corporate
title: Good Standing Review — Record 05
document_date: 2024-01-07
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Good Standing Review — Record 05

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 62,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2020-005. No undisclosed dividend was approved in this record.
