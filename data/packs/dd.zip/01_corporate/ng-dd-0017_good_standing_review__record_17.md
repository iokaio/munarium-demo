---
document_id: NG-DD-0017
category: 01_corporate
title: Good Standing Review — Record 17
document_date: 2023-06-17
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Good Standing Review — Record 17

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of NGS Federal LLC, delegated ordinary-course signing authority up to USD 92,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2022-017. No undisclosed dividend was approved in this record.
