---
document_id: NG-DD-0039
category: 01_corporate
title: Officer Certificate — Record 39
document_date: 2022-06-08
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Officer Certificate — Record 39

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 147,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2024-039. No undisclosed dividend was approved in this record.
