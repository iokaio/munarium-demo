---
document_id: NG-DD-0021
category: 01_corporate
title: Officer Certificate — Record 21
document_date: 2023-04-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Officer Certificate — Record 21

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 102,500, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2021-021. No undisclosed dividend was approved in this record.
