---
document_id: NG-DD-0016
category: 01_corporate
title: Subsidiary Register — Record 16
document_date: 2023-07-04
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Subsidiary Register — Record 16

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Health UK Ltd, delegated ordinary-course signing authority up to USD 90,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2021-016. No undisclosed dividend was approved in this record.
