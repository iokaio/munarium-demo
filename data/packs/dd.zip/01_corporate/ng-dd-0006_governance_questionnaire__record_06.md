---
document_id: NG-DD-0006
category: 01_corporate
title: Governance Questionnaire — Record 06
document_date: 2023-12-21
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Governance Questionnaire — Record 06

## Purpose
This record concerns governance and transaction readiness for Northgate Systems Ltd. and was maintained by the corporate secretary.

## Resolutions and observations
The board reviewed operations of Northgate Analytics LLC, delegated ordinary-course signing authority up to USD 65,000, and confirmed quarterly reporting obligations.

The record refers to corporate record book item CR-2021-006. No undisclosed dividend was approved in this record.
