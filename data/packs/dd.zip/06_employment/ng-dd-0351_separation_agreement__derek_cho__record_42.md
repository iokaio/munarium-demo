---
document_id: NG-DD-0351
category: 06_employment
title: Separation Agreement — Derek Cho — Record 42
document_date: 2020-08-23
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Derek Cho — Record 42

## Personnel terms
Worker: Derek Cho. Department code: D-106. Base compensation or annualized fees: USD 184,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0042: signed IP assignment present.
