---
document_id: NG-DD-0360
category: 06_employment
title: Bonus Plan — Priya Nair — Record 51
document_date: 2020-03-23
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Priya Nair — Record 51

## Personnel terms
Worker: Priya Nair. Department code: D-106. Base compensation or annualized fees: USD 204,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0051: signed IP assignment present.
