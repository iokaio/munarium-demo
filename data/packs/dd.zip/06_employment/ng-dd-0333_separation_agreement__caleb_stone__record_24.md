---
document_id: NG-DD-0333
category: 06_employment
title: Separation Agreement — Caleb Stone — Record 24
document_date: 2021-06-25
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Caleb Stone — Record 24

## Personnel terms
Worker: Caleb Stone. Department code: D-106. Base compensation or annualized fees: USD 144,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 6 months.

File review item HR-0024: signed IP assignment present.
