---
document_id: NG-DD-0336
category: 06_employment
title: Bonus Plan — Priya Nair — Record 27
document_date: 2021-05-05
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Priya Nair — Record 27

## Personnel terms
Worker: Priya Nair. Department code: D-100. Base compensation or annualized fees: USD 150,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0027: signed IP assignment present.
