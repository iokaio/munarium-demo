---
document_id: NG-DD-0357
category: 06_employment
title: Separation Agreement — Caleb Stone — Record 48
document_date: 2020-05-13
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Caleb Stone — Record 48

## Personnel terms
Worker: Caleb Stone. Department code: D-103. Base compensation or annualized fees: USD 198,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 6 months.

File review item HR-0048: signed IP assignment present.
