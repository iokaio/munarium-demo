---
document_id: NG-DD-0349
category: 06_employment
title: Contractor File — Jonah Reed — Record 40
document_date: 2020-09-26
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Jonah Reed — Record 40

## Personnel terms
Worker: Jonah Reed. Department code: D-104. Base compensation or annualized fees: USD 180,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 12 months.

File review item HR-0040: IP assignment not located.
