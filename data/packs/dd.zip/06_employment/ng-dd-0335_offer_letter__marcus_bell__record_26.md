---
document_id: NG-DD-0335
category: 06_employment
title: Offer Letter — Marcus Bell — Record 26
document_date: 2021-05-22
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Marcus Bell — Record 26

## Personnel terms
Worker: Marcus Bell. Department code: D-108. Base compensation or annualized fees: USD 148,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0026: signed IP assignment present.
