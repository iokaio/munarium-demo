---
document_id: NG-DD-0320
category: 06_employment
title: Benefits Summary — Mei Tan — Record 11
document_date: 2022-02-01
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Mei Tan — Record 11

## Personnel terms
Worker: Mei Tan. Department code: D-102. Base compensation or annualized fees: USD 114,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0011: signed IP assignment present.
