---
document_id: NG-DD-0337
category: 06_employment
title: Contractor File — Jonah Reed — Record 28
document_date: 2021-04-18
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Jonah Reed — Record 28

## Personnel terms
Worker: Jonah Reed. Department code: D-101. Base compensation or annualized fees: USD 153,000.

## Retention program
The board-approved retention pool is USD 2,400,000, payable 50% at closing and 50% after twelve months. Finance accrued only the first installment.
