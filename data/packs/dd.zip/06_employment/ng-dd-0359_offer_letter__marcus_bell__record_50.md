---
document_id: NG-DD-0359
category: 06_employment
title: Offer Letter — Marcus Bell — Record 50
document_date: 2020-04-09
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Marcus Bell — Record 50

## Personnel terms
Worker: Marcus Bell. Department code: D-105. Base compensation or annualized fees: USD 202,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0050: IP assignment not located.
