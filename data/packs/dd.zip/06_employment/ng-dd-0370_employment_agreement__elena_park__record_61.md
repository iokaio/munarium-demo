---
document_id: NG-DD-0370
category: 06_employment
title: Employment Agreement — Elena Park — Record 61
document_date: 2024-01-02
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Elena Park — Record 61

## Personnel terms
Worker: Elena Park. Department code: D-107. Base compensation or annualized fees: USD 227,250.

## Works council
The UK employee representative asserts that consultation must begin at least 30 days before a binding sale agreement. No consultation notice has been delivered.
