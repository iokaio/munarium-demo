---
document_id: NG-DD-0363
category: 06_employment
title: Separation Agreement — Derek Cho — Record 54
document_date: 2020-02-01
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Derek Cho — Record 54

## Personnel terms
Worker: Derek Cho. Department code: D-100. Base compensation or annualized fees: USD 211,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0054: signed IP assignment present.
