---
document_id: NG-DD-0373
category: 06_employment
title: Contractor File — Jonah Reed — Record 64
document_date: 2023-11-12
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Jonah Reed — Record 64

## Personnel terms
Worker: Jonah Reed. Department code: D-101. Base compensation or annualized fees: USD 234,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 12 months.

File review item HR-0064: signed IP assignment present.
