---
document_id: NG-DD-0315
category: 06_employment
title: Separation Agreement — Derek Cho — Record 06
document_date: 2022-04-27
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Derek Cho — Record 06

## Personnel terms
Worker: Derek Cho. Department code: D-106. Base compensation or annualized fees: USD 103,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0006: signed IP assignment present.
