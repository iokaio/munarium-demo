---
document_id: NG-DD-0310
category: 06_employment
title: Employment Agreement — Elena Park — Record 01
document_date: 2022-07-21
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Elena Park — Record 01

## Personnel terms
Worker: Elena Park. Department code: D-101. Base compensation or annualized fees: USD 92,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0001: signed IP assignment present.
