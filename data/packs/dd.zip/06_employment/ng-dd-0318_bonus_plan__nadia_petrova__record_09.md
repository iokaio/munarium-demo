---
document_id: NG-DD-0318
category: 06_employment
title: Bonus Plan — Nadia Petrova — Record 09
document_date: 2022-03-07
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Nadia Petrova — Record 09

## Personnel terms
Worker: Nadia Petrova. Department code: D-100. Base compensation or annualized fees: USD 110,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0009: signed IP assignment present.
