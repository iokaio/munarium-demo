---
document_id: NG-DD-0366
category: 06_employment
title: Bonus Plan — Nadia Petrova — Record 57
document_date: 2024-03-10
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Nadia Petrova — Record 57

## Personnel terms
Worker: Nadia Petrova. Department code: D-103. Base compensation or annualized fees: USD 218,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0057: signed IP assignment present.
