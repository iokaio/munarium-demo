---
document_id: NG-DD-0350
category: 06_employment
title: Benefits Summary — Sofia Alvarez — Record 41
document_date: 2020-09-09
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Sofia Alvarez — Record 41

## Personnel terms
Worker: Sofia Alvarez. Department code: D-105. Base compensation or annualized fees: USD 182,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0041: signed IP assignment present.
