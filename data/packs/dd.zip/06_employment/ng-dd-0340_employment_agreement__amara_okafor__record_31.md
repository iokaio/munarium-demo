---
document_id: NG-DD-0340
category: 06_employment
title: Employment Agreement — Amara Okafor — Record 31
document_date: 2021-02-26
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Amara Okafor — Record 31

## Personnel terms
Worker: Amara Okafor. Department code: D-104. Base compensation or annualized fees: USD 159,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0031: signed IP assignment present.
