---
document_id: NG-DD-0339
category: 06_employment
title: Separation Agreement — Derek Cho — Record 30
document_date: 2021-03-15
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Derek Cho — Record 30

## Personnel terms
Worker: Derek Cho. Department code: D-103. Base compensation or annualized fees: USD 157,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0030: IP assignment not located.
