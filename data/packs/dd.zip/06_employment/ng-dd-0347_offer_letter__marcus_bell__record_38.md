---
document_id: NG-DD-0347
category: 06_employment
title: Offer Letter — Marcus Bell — Record 38
document_date: 2020-10-30
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Marcus Bell — Record 38

## Personnel terms
Worker: Marcus Bell. Department code: D-102. Base compensation or annualized fees: USD 175,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0038: signed IP assignment present.
