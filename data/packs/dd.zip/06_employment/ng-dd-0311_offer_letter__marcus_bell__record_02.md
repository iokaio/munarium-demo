---
document_id: NG-DD-0311
category: 06_employment
title: Offer Letter — Marcus Bell — Record 02
document_date: 2022-07-04
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Marcus Bell — Record 02

## Personnel terms
Worker: Marcus Bell. Department code: D-102. Base compensation or annualized fees: USD 94,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0002: signed IP assignment present.
