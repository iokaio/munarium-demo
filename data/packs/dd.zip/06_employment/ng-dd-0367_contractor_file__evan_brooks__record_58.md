---
document_id: NG-DD-0367
category: 06_employment
title: Contractor File — Evan Brooks — Record 58
document_date: 2024-02-22
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Evan Brooks — Record 58

## Personnel terms
Worker: Evan Brooks. Department code: D-104. Base compensation or annualized fees: USD 220,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0058: signed IP assignment present.
