---
document_id: NG-DD-0354
category: 06_employment
title: Bonus Plan — Nadia Petrova — Record 45
document_date: 2020-07-03
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Nadia Petrova — Record 45

## Personnel terms
Worker: Nadia Petrova. Department code: D-100. Base compensation or annualized fees: USD 191,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0045: IP assignment not located.
