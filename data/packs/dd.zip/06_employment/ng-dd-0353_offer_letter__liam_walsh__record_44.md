---
document_id: NG-DD-0353
category: 06_employment
title: Offer Letter — Liam Walsh — Record 44
document_date: 2020-07-20
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Liam Walsh — Record 44

## Personnel terms
Worker: Liam Walsh. Department code: D-108. Base compensation or annualized fees: USD 189,000.

## Wage claim
A former sales director alleges unpaid commissions of USD 385,000 and challenges the plan's post-termination forfeiture clause. Mediation is scheduled for July 2024.
