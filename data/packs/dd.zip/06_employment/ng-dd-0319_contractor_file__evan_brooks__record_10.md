---
document_id: NG-DD-0319
category: 06_employment
title: Contractor File — Evan Brooks — Record 10
document_date: 2022-02-18
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Evan Brooks — Record 10

## Personnel terms
Worker: Evan Brooks. Department code: D-101. Base compensation or annualized fees: USD 112,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0010: IP assignment not located.
