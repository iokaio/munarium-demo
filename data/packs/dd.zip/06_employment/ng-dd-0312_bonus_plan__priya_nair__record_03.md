---
document_id: NG-DD-0312
category: 06_employment
title: Bonus Plan — Priya Nair — Record 03
document_date: 2022-06-17
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Priya Nair — Record 03

## Personnel terms
Worker: Priya Nair. Department code: D-103. Base compensation or annualized fees: USD 96,750.

## CEO transaction benefit
Elena Park receives a USD 1,200,000 transaction bonus at closing plus 12 months of salary upon a qualifying termination. The bonus is not included in the seller's transaction-expense schedule.
