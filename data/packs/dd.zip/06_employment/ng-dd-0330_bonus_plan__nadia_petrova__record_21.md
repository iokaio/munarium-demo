---
document_id: NG-DD-0330
category: 06_employment
title: Bonus Plan — Nadia Petrova — Record 21
document_date: 2021-08-15
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Nadia Petrova — Record 21

## Personnel terms
Worker: Nadia Petrova. Department code: D-103. Base compensation or annualized fees: USD 137,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0021: signed IP assignment present.
