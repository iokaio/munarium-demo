---
document_id: NG-DD-0345
category: 06_employment
title: Separation Agreement — Caleb Stone — Record 36
document_date: 2020-12-03
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Caleb Stone — Record 36

## Personnel terms
Worker: Caleb Stone. Department code: D-100. Base compensation or annualized fees: USD 171,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 6 months.

File review item HR-0036: signed IP assignment present.
