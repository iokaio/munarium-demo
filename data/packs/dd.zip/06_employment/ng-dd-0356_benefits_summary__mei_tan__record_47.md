---
document_id: NG-DD-0356
category: 06_employment
title: Benefits Summary — Mei Tan — Record 47
document_date: 2020-05-30
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Mei Tan — Record 47

## Personnel terms
Worker: Mei Tan. Department code: D-102. Base compensation or annualized fees: USD 195,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0047: signed IP assignment present.
