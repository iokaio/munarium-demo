---
document_id: NG-DD-0346
category: 06_employment
title: Employment Agreement — Elena Park — Record 37
document_date: 2020-11-16
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Elena Park — Record 37

## Personnel terms
Worker: Elena Park. Department code: D-101. Base compensation or annualized fees: USD 173,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0037: signed IP assignment present.
