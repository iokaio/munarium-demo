---
document_id: NG-DD-0374
category: 06_employment
title: Benefits Summary — Sofia Alvarez — Record 65
document_date: 2023-10-26
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Sofia Alvarez — Record 65

## Personnel terms
Worker: Sofia Alvarez. Department code: D-102. Base compensation or annualized fees: USD 236,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0065: IP assignment not located.
