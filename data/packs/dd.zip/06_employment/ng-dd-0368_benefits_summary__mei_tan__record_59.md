---
document_id: NG-DD-0368
category: 06_employment
title: Benefits Summary — Mei Tan — Record 59
document_date: 2024-02-05
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Mei Tan — Record 59

## Personnel terms
Worker: Mei Tan. Department code: D-105. Base compensation or annualized fees: USD 222,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0059: signed IP assignment present.
