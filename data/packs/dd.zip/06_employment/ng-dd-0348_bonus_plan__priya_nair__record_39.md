---
document_id: NG-DD-0348
category: 06_employment
title: Bonus Plan — Priya Nair — Record 39
document_date: 2020-10-13
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Priya Nair — Record 39

## Personnel terms
Worker: Priya Nair. Department code: D-103. Base compensation or annualized fees: USD 177,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0039: signed IP assignment present.
