---
document_id: NG-DD-0325
category: 06_employment
title: Contractor File — Jonah Reed — Record 16
document_date: 2021-11-08
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Jonah Reed — Record 16

## Personnel terms
Worker: Jonah Reed. Department code: D-107. Base compensation or annualized fees: USD 126,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 12 months.

File review item HR-0016: signed IP assignment present.
