---
document_id: NG-DD-0369
category: 06_employment
title: Separation Agreement — Caleb Stone — Record 60
document_date: 2024-01-19
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Caleb Stone — Record 60

## Personnel terms
Worker: Caleb Stone. Department code: D-106. Base compensation or annualized fees: USD 225,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 6 months.

File review item HR-0060: IP assignment not located.
