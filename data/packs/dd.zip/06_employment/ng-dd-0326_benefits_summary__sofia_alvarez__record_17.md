---
document_id: NG-DD-0326
category: 06_employment
title: Benefits Summary — Sofia Alvarez — Record 17
document_date: 2021-10-22
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Sofia Alvarez — Record 17

## Personnel terms
Worker: Sofia Alvarez. Department code: D-108. Base compensation or annualized fees: USD 128,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0017: signed IP assignment present.
