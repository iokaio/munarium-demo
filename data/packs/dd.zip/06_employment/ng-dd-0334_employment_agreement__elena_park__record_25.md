---
document_id: NG-DD-0334
category: 06_employment
title: Employment Agreement — Elena Park — Record 25
document_date: 2021-06-08
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Elena Park — Record 25

## Personnel terms
Worker: Elena Park. Department code: D-107. Base compensation or annualized fees: USD 146,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0025: IP assignment not located.
