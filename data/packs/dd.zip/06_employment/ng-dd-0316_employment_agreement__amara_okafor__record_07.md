---
document_id: NG-DD-0316
category: 06_employment
title: Employment Agreement — Amara Okafor — Record 07
document_date: 2022-04-10
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Amara Okafor — Record 07

## Personnel terms
Worker: Amara Okafor. Department code: D-107. Base compensation or annualized fees: USD 105,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0007: signed IP assignment present.
