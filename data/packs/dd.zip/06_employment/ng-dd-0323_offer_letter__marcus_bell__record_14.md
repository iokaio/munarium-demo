---
document_id: NG-DD-0323
category: 06_employment
title: Offer Letter — Marcus Bell — Record 14
document_date: 2021-12-12
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Marcus Bell — Record 14

## Personnel terms
Worker: Marcus Bell. Department code: D-105. Base compensation or annualized fees: USD 121,500.

## Worker classification
Twenty-three implementation consultants work full time, use Northgate equipment, report to Northgate managers, and have been engaged as independent contractors for more than two years.
