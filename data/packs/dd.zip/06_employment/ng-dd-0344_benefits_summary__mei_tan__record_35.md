---
document_id: NG-DD-0344
category: 06_employment
title: Benefits Summary — Mei Tan — Record 35
document_date: 2020-12-20
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Mei Tan — Record 35

## Personnel terms
Worker: Mei Tan. Department code: D-108. Base compensation or annualized fees: USD 168,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0035: IP assignment not located.
