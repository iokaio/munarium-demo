---
document_id: NG-DD-0342
category: 06_employment
title: Bonus Plan — Nadia Petrova — Record 33
document_date: 2021-01-23
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Nadia Petrova — Record 33

## Personnel terms
Worker: Nadia Petrova. Department code: D-106. Base compensation or annualized fees: USD 164,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0033: signed IP assignment present.
