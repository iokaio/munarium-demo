---
document_id: NG-DD-0371
category: 06_employment
title: Offer Letter — Marcus Bell — Record 62
document_date: 2023-12-16
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Marcus Bell — Record 62

## Personnel terms
Worker: Marcus Bell. Department code: D-108. Base compensation or annualized fees: USD 229,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0062: signed IP assignment present.
