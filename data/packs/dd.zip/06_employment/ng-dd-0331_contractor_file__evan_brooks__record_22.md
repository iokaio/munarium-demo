---
document_id: NG-DD-0331
category: 06_employment
title: Contractor File — Evan Brooks — Record 22
document_date: 2021-07-29
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Evan Brooks — Record 22

## Personnel terms
Worker: Evan Brooks. Department code: D-104. Base compensation or annualized fees: USD 139,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0022: signed IP assignment present.
