---
document_id: NG-DD-0324
category: 06_employment
title: Bonus Plan — Priya Nair — Record 15
document_date: 2021-11-25
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Priya Nair — Record 15

## Personnel terms
Worker: Priya Nair. Department code: D-106. Base compensation or annualized fees: USD 123,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0015: IP assignment not located.
