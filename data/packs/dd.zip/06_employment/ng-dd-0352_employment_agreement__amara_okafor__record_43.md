---
document_id: NG-DD-0352
category: 06_employment
title: Employment Agreement — Amara Okafor — Record 43
document_date: 2020-08-06
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Amara Okafor — Record 43

## Personnel terms
Worker: Amara Okafor. Department code: D-107. Base compensation or annualized fees: USD 186,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0043: signed IP assignment present.
