---
document_id: NG-DD-0358
category: 06_employment
title: Employment Agreement — Elena Park — Record 49
document_date: 2020-04-26
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Elena Park — Record 49

## Personnel terms
Worker: Elena Park. Department code: D-104. Base compensation or annualized fees: USD 200,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0049: signed IP assignment present.
