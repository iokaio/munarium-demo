---
document_id: NG-DD-0338
category: 06_employment
title: Benefits Summary — Sofia Alvarez — Record 29
document_date: 2021-04-01
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Sofia Alvarez — Record 29

## Personnel terms
Worker: Sofia Alvarez. Department code: D-102. Base compensation or annualized fees: USD 155,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0029: signed IP assignment present.
