---
document_id: NG-DD-0364
category: 06_employment
title: Employment Agreement — Amara Okafor — Record 55
document_date: 2020-01-15
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Employment Agreement — Amara Okafor — Record 55

## Personnel terms
Worker: Amara Okafor. Department code: D-101. Base compensation or annualized fees: USD 213,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0055: IP assignment not located.
