---
document_id: NG-DD-0343
category: 06_employment
title: Contractor File — Evan Brooks — Record 34
document_date: 2021-01-06
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Evan Brooks — Record 34

## Personnel terms
Worker: Evan Brooks. Department code: D-107. Base compensation or annualized fees: USD 166,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 12 months.

File review item HR-0034: signed IP assignment present.
