---
document_id: NG-DD-0317
category: 06_employment
title: Offer Letter — Liam Walsh — Record 08
document_date: 2022-03-24
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Offer Letter — Liam Walsh — Record 08

## Personnel terms
Worker: Liam Walsh. Department code: D-108. Base compensation or annualized fees: USD 108,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 18 months.

File review item HR-0008: signed IP assignment present.
