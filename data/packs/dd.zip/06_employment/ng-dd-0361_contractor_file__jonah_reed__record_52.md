---
document_id: NG-DD-0361
category: 06_employment
title: Contractor File — Jonah Reed — Record 52
document_date: 2020-03-06
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Contractor File — Jonah Reed — Record 52

## Personnel terms
Worker: Jonah Reed. Department code: D-107. Base compensation or annualized fees: USD 207,000.

## Change-of-control and restrictions
Transaction acceleration: single-trigger for 50% of unvested award. Restrictive covenant term: 12 months.

File review item HR-0052: signed IP assignment present.
