---
document_id: NG-DD-0314
category: 06_employment
title: Benefits Summary — Sofia Alvarez — Record 05
document_date: 2022-05-14
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Benefits Summary — Sofia Alvarez — Record 05

## Personnel terms
Worker: Sofia Alvarez. Department code: D-105. Base compensation or annualized fees: USD 101,250.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 18 months.

File review item HR-0005: IP assignment not located.
