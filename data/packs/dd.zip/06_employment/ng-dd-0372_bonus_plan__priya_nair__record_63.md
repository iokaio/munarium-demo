---
document_id: NG-DD-0372
category: 06_employment
title: Bonus Plan — Priya Nair — Record 63
document_date: 2023-11-29
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Bonus Plan — Priya Nair — Record 63

## Personnel terms
Worker: Priya Nair. Department code: D-100. Base compensation or annualized fees: USD 231,750.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0063: signed IP assignment present.
