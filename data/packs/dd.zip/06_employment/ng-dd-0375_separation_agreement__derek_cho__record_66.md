---
document_id: NG-DD-0375
category: 06_employment
title: Separation Agreement — Derek Cho — Record 66
document_date: 2023-10-09
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Separation Agreement — Derek Cho — Record 66

## Personnel terms
Worker: Derek Cho. Department code: D-103. Base compensation or annualized fees: USD 238,500.

## Change-of-control and restrictions
Transaction acceleration: double-trigger. Restrictive covenant term: 6 months.

File review item HR-0066: signed IP assignment present.
