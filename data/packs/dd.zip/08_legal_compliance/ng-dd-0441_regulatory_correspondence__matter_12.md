---
document_id: NG-DD-0441
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 12
document_date: 2020-09-12
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 12

## Matter profile
Matter number: LEG-2022-0012. Responsible lawyer: Nadia Petrova. Status date: 2020-09-12.

## Assessment
Claimed or estimated exposure: USD 235,000. Probability classification: remote.

Preservation hold applies to custodians Elena Park and Sofia Alvarez. No admission is made.
