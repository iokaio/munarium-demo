---
document_id: NG-DD-0474
category: 08_legal_compliance
title: Settlement Agreement — Matter 45
document_date: 2023-05-29
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 45

## Matter profile
Matter number: LEG-2020-0045. Responsible lawyer: Nadia Petrova. Status date: 2023-05-29.

## Anti-bribery review
A Brazil channel partner received success fees totaling USD 420,000 without documented services. Two invoices describe payments as licensing facilitation. The distributor is partly owned by a public hospital official's sibling.
