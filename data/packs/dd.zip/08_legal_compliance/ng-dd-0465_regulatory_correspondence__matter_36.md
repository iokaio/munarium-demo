---
document_id: NG-DD-0465
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 36
document_date: 2023-10-29
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 36

## Matter profile
Matter number: LEG-2021-0036. Responsible lawyer: Nadia Petrova. Status date: 2023-10-29.

## Assessment
Claimed or estimated exposure: USD 655,000. Probability classification: remote.

Preservation hold applies to custodians Elena Park and Sofia Alvarez. No admission is made.
