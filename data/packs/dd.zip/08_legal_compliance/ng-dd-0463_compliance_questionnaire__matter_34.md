---
document_id: NG-DD-0463
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 34
document_date: 2023-12-02
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 34

## Matter profile
Matter number: LEG-2024-0034. Responsible lawyer: Nadia Petrova. Status date: 2023-12-02.

## Export controls
Internal review found 317 technical-support sessions delivered to users in comprehensively sanctioned jurisdictions through a reseller. No voluntary self-disclosure has been filed.
