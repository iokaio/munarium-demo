---
document_id: NG-DD-0466
category: 08_legal_compliance
title: Litigation Report — Matter 37
document_date: 2023-10-12
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 37

## Matter profile
Matter number: LEG-2022-0037. Responsible lawyer: Nadia Petrova. Status date: 2023-10-12.

## Assessment
Claimed or estimated exposure: USD 672,500. Probability classification: possible.

Preservation hold applies to custodians Marcus Bell and Derek Cho. No admission is made.
