---
document_id: NG-DD-0453
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 24
document_date: 2020-02-21
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 24

## Matter profile
Matter number: LEG-2024-0024. Responsible lawyer: Nadia Petrova. Status date: 2020-02-21.

## Assessment
Claimed or estimated exposure: USD 445,000. Probability classification: remote.

Preservation hold applies to custodians Elena Park and Sofia Alvarez. No admission is made.
