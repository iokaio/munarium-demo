---
document_id: NG-DD-0437
category: 08_legal_compliance
title: Demand Letter — Matter 08
document_date: 2020-11-19
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 08

## Matter profile
Matter number: LEG-2023-0008. Responsible lawyer: Nadia Petrova. Status date: 2020-11-19.

## Assessment
Claimed or estimated exposure: USD 165,000. Probability classification: probable.

Preservation hold applies to custodians Nadia Petrova and Elena Park. No admission is made.
