---
document_id: NG-DD-0462
category: 08_legal_compliance
title: Settlement Agreement — Matter 33
document_date: 2023-12-19
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 33

## Matter profile
Matter number: LEG-2023-0033. Responsible lawyer: Nadia Petrova. Status date: 2023-12-19.

## Assessment
Claimed or estimated exposure: USD 602,500. Probability classification: remote.

Preservation hold applies to custodians Evan Brooks and Marcus Bell. No admission is made.
