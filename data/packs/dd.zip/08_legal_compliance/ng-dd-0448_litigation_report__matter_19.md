---
document_id: NG-DD-0448
category: 08_legal_compliance
title: Litigation Report — Matter 19
document_date: 2020-05-16
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 19

## Matter profile
Matter number: LEG-2024-0019. Responsible lawyer: Nadia Petrova. Status date: 2020-05-16.

## Assessment
Claimed or estimated exposure: USD 357,500. Probability classification: possible.

Preservation hold applies to custodians Liam Walsh and Caleb Stone. No admission is made.
