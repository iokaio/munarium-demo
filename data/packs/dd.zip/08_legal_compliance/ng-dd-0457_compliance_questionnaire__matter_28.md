---
document_id: NG-DD-0457
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 28
document_date: 2024-03-13
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 28

## Matter profile
Matter number: LEG-2023-0028. Responsible lawyer: Nadia Petrova. Status date: 2024-03-13.

## Assessment
Claimed or estimated exposure: USD 515,000. Probability classification: possible.

Preservation hold applies to custodians Sofia Alvarez and Nadia Petrova. No admission is made.
