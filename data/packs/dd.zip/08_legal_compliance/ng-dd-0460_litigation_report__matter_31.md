---
document_id: NG-DD-0460
category: 08_legal_compliance
title: Litigation Report — Matter 31
document_date: 2024-01-22
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 31

## Matter profile
Matter number: LEG-2021-0031. Responsible lawyer: Nadia Petrova. Status date: 2024-01-22.

## Assessment
Claimed or estimated exposure: USD 567,500. Probability classification: possible.

Preservation hold applies to custodians Liam Walsh and Caleb Stone. No admission is made.
