---
document_id: NG-DD-0454
category: 08_legal_compliance
title: Litigation Report — Matter 25
document_date: 2020-02-04
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 25

## Matter profile
Matter number: LEG-2020-0025. Responsible lawyer: Nadia Petrova. Status date: 2020-02-04.

## Assessment
Claimed or estimated exposure: USD 462,500. Probability classification: possible.

Preservation hold applies to custodians Marcus Bell and Derek Cho. No admission is made.
