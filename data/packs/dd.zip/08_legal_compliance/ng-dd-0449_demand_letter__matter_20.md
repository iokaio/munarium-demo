---
document_id: NG-DD-0449
category: 08_legal_compliance
title: Demand Letter — Matter 20
document_date: 2020-04-29
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 20

## Matter profile
Matter number: LEG-2020-0020. Responsible lawyer: Nadia Petrova. Status date: 2020-04-29.

## Assessment
Claimed or estimated exposure: USD 375,000. Probability classification: probable.

Preservation hold applies to custodians Nadia Petrova and Elena Park. No admission is made.
