---
document_id: NG-DD-0445
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 16
document_date: 2020-07-06
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 16

## Matter profile
Matter number: LEG-2021-0016. Responsible lawyer: Nadia Petrova. Status date: 2020-07-06.

## Assessment
Claimed or estimated exposure: USD 305,000. Probability classification: possible.

Preservation hold applies to custodians Sofia Alvarez and Nadia Petrova. No admission is made.
