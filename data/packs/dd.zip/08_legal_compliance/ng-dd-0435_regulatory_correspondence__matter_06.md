---
document_id: NG-DD-0435
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 06
document_date: 2020-12-23
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 06

## Matter profile
Matter number: LEG-2021-0006. Responsible lawyer: Nadia Petrova. Status date: 2020-12-23.

## Assessment
Claimed or estimated exposure: USD 130,000. Probability classification: remote.

Preservation hold applies to custodians Amara Okafor and Mei Tan. No admission is made.
