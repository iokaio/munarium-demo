---
document_id: NG-DD-0433
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 04
document_date: 2021-01-26
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 04

## Matter profile
Matter number: LEG-2024-0004. Responsible lawyer: Nadia Petrova. Status date: 2021-01-26.

## Assessment
Claimed or estimated exposure: USD 95,000. Probability classification: possible.

Preservation hold applies to custodians Sofia Alvarez and Nadia Petrova. No admission is made.
