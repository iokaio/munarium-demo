---
document_id: NG-DD-0467
category: 08_legal_compliance
title: Demand Letter — Matter 38
document_date: 2023-09-25
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 38

## Matter profile
Matter number: LEG-2023-0038. Responsible lawyer: Nadia Petrova. Status date: 2023-09-25.

## Assessment
Claimed or estimated exposure: USD 690,000. Probability classification: probable.

Preservation hold applies to custodians Priya Nair and Amara Okafor. No admission is made.
