---
document_id: NG-DD-0472
category: 08_legal_compliance
title: Litigation Report — Matter 43
document_date: 2023-07-02
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 43

## Matter profile
Matter number: LEG-2023-0043. Responsible lawyer: Nadia Petrova. Status date: 2023-07-02.

## Assessment
Claimed or estimated exposure: USD 777,500. Probability classification: possible.

Preservation hold applies to custodians Liam Walsh and Caleb Stone. No admission is made.
