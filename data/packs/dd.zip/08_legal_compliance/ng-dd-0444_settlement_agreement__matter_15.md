---
document_id: NG-DD-0444
category: 08_legal_compliance
title: Settlement Agreement — Matter 15
document_date: 2020-07-23
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 15

## Matter profile
Matter number: LEG-2020-0015. Responsible lawyer: Nadia Petrova. Status date: 2020-07-23.

## Assessment
Claimed or estimated exposure: USD 287,500. Probability classification: remote.

Preservation hold applies to custodians Jonah Reed and Liam Walsh. No admission is made.
