---
document_id: NG-DD-0431
category: 08_legal_compliance
title: Demand Letter — Matter 02
document_date: 2021-03-01
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 02

## Matter profile
Matter number: LEG-2022-0002. Responsible lawyer: Nadia Petrova. Status date: 2021-03-01.

## Ardent Logic claim
Ardent Logic alleges patent infringement and trade-secret misuse by two former employees. Demand: USD 8,000,000 plus an injunction. Management's disclosure schedule lists the matter as an ordinary-course inquiry with exposure below USD 250,000.
