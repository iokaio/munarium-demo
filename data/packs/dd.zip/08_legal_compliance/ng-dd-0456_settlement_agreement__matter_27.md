---
document_id: NG-DD-0456
category: 08_legal_compliance
title: Settlement Agreement — Matter 27
document_date: 2024-03-30
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 27

## Matter profile
Matter number: LEG-2022-0027. Responsible lawyer: Nadia Petrova. Status date: 2024-03-30.

## Assessment
Claimed or estimated exposure: USD 497,500. Probability classification: remote.

Preservation hold applies to custodians Jonah Reed and Liam Walsh. No admission is made.
