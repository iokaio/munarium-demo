---
document_id: NG-DD-0469
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 40
document_date: 2023-08-22
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 40

## Matter profile
Matter number: LEG-2020-0040. Responsible lawyer: Nadia Petrova. Status date: 2023-08-22.

## Assessment
Claimed or estimated exposure: USD 725,000. Probability classification: possible.

Preservation hold applies to custodians Sofia Alvarez and Nadia Petrova. No admission is made.
