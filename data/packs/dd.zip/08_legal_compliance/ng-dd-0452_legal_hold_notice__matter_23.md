---
document_id: NG-DD-0452
category: 08_legal_compliance
title: Legal Hold Notice — Matter 23
document_date: 2020-03-09
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 23

## Matter profile
Matter number: LEG-2023-0023. Responsible lawyer: Nadia Petrova. Status date: 2020-03-09.

## Assessment
Claimed or estimated exposure: USD 427,500. Probability classification: probable.

Preservation hold applies to custodians Caleb Stone and Jonah Reed. No admission is made.
