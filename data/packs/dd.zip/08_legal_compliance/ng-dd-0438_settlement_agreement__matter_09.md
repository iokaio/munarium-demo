---
document_id: NG-DD-0438
category: 08_legal_compliance
title: Settlement Agreement — Matter 09
document_date: 2020-11-02
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 09

## Matter profile
Matter number: LEG-2024-0009. Responsible lawyer: Nadia Petrova. Status date: 2020-11-02.

## Assessment
Claimed or estimated exposure: USD 182,500. Probability classification: remote.

Preservation hold applies to custodians Evan Brooks and Marcus Bell. No admission is made.
