---
document_id: NG-DD-0443
category: 08_legal_compliance
title: Demand Letter — Matter 14
document_date: 2020-08-09
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 14

## Matter profile
Matter number: LEG-2024-0014. Responsible lawyer: Nadia Petrova. Status date: 2020-08-09.

## Assessment
Claimed or estimated exposure: USD 270,000. Probability classification: probable.

Preservation hold applies to custodians Priya Nair and Amara Okafor. No admission is made.
