---
document_id: NG-DD-0464
category: 08_legal_compliance
title: Legal Hold Notice — Matter 35
document_date: 2023-11-15
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 35

## Matter profile
Matter number: LEG-2020-0035. Responsible lawyer: Nadia Petrova. Status date: 2023-11-15.

## Assessment
Claimed or estimated exposure: USD 637,500. Probability classification: probable.

Preservation hold applies to custodians Caleb Stone and Jonah Reed. No admission is made.
