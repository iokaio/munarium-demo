---
document_id: NG-DD-0477
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 48
document_date: 2023-04-08
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 48

## Matter profile
Matter number: LEG-2023-0048. Responsible lawyer: Nadia Petrova. Status date: 2023-04-08.

## Assessment
Claimed or estimated exposure: USD 865,000. Probability classification: remote.

Preservation hold applies to custodians Elena Park and Sofia Alvarez. No admission is made.
