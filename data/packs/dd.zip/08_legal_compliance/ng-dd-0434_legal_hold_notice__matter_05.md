---
document_id: NG-DD-0434
category: 08_legal_compliance
title: Legal Hold Notice — Matter 05
document_date: 2021-01-09
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 05

## Matter profile
Matter number: LEG-2020-0005. Responsible lawyer: Nadia Petrova. Status date: 2021-01-09.

## Assessment
Claimed or estimated exposure: USD 112,500. Probability classification: probable.

Preservation hold applies to custodians Derek Cho and Evan Brooks. No admission is made.
