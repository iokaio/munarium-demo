---
document_id: NG-DD-0461
category: 08_legal_compliance
title: Demand Letter — Matter 32
document_date: 2024-01-05
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 32

## Matter profile
Matter number: LEG-2022-0032. Responsible lawyer: Nadia Petrova. Status date: 2024-01-05.

## Assessment
Claimed or estimated exposure: USD 585,000. Probability classification: probable.

Preservation hold applies to custodians Nadia Petrova and Elena Park. No admission is made.
