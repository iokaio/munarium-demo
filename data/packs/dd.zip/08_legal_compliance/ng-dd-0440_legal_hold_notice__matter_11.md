---
document_id: NG-DD-0440
category: 08_legal_compliance
title: Legal Hold Notice — Matter 11
document_date: 2020-09-29
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 11

## Matter profile
Matter number: LEG-2021-0011. Responsible lawyer: Nadia Petrova. Status date: 2020-09-29.

## False Claims Act inquiry
The U.S. Attorney requested documents concerning NGS Federal LLC's small-business subcontracting certifications. The subpoena prohibits no disclosure but has not been provided to the buyer's diligence team.
