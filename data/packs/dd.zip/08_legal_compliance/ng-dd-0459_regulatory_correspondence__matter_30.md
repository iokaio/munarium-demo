---
document_id: NG-DD-0459
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 30
document_date: 2024-02-08
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 30

## Matter profile
Matter number: LEG-2020-0030. Responsible lawyer: Nadia Petrova. Status date: 2024-02-08.

## Assessment
Claimed or estimated exposure: USD 550,000. Probability classification: remote.

Preservation hold applies to custodians Amara Okafor and Mei Tan. No admission is made.
