---
document_id: NG-DD-0458
category: 08_legal_compliance
title: Legal Hold Notice — Matter 29
document_date: 2024-02-25
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 29

## Matter profile
Matter number: LEG-2024-0029. Responsible lawyer: Nadia Petrova. Status date: 2024-02-25.

## Assessment
Claimed or estimated exposure: USD 532,500. Probability classification: probable.

Preservation hold applies to custodians Derek Cho and Evan Brooks. No admission is made.
