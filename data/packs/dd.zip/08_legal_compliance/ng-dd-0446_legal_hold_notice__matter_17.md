---
document_id: NG-DD-0446
category: 08_legal_compliance
title: Legal Hold Notice — Matter 17
document_date: 2020-06-19
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 17

## Matter profile
Matter number: LEG-2022-0017. Responsible lawyer: Nadia Petrova. Status date: 2020-06-19.

## Assessment
Claimed or estimated exposure: USD 322,500. Probability classification: probable.

Preservation hold applies to custodians Derek Cho and Evan Brooks. No admission is made.
