---
document_id: NG-DD-0439
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 10
document_date: 2020-10-16
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 10

## Matter profile
Matter number: LEG-2020-0010. Responsible lawyer: Nadia Petrova. Status date: 2020-10-16.

## Assessment
Claimed or estimated exposure: USD 200,000. Probability classification: possible.

Preservation hold applies to custodians Mei Tan and Priya Nair. No admission is made.
