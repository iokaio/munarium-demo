---
document_id: NG-DD-0432
category: 08_legal_compliance
title: Settlement Agreement — Matter 03
document_date: 2021-02-12
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 03

## Matter profile
Matter number: LEG-2023-0003. Responsible lawyer: Nadia Petrova. Status date: 2021-02-12.

## Assessment
Claimed or estimated exposure: USD 77,500. Probability classification: remote.

Preservation hold applies to custodians Jonah Reed and Liam Walsh. No admission is made.
