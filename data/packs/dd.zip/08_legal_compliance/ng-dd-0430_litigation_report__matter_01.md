---
document_id: NG-DD-0430
category: 08_legal_compliance
title: Litigation Report — Matter 01
document_date: 2021-03-18
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 01

## Matter profile
Matter number: LEG-2021-0001. Responsible lawyer: Nadia Petrova. Status date: 2021-03-18.

## Assessment
Claimed or estimated exposure: USD 42,500. Probability classification: possible.

Preservation hold applies to custodians Marcus Bell and Derek Cho. No admission is made.
