---
document_id: NG-DD-0451
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 22
document_date: 2020-03-26
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 22

## Matter profile
Matter number: LEG-2022-0022. Responsible lawyer: Nadia Petrova. Status date: 2020-03-26.

## Assessment
Claimed or estimated exposure: USD 410,000. Probability classification: possible.

Preservation hold applies to custodians Mei Tan and Priya Nair. No admission is made.
