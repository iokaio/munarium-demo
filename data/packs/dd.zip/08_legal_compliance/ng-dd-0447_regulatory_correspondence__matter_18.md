---
document_id: NG-DD-0447
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 18
document_date: 2020-06-02
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 18

## Matter profile
Matter number: LEG-2023-0018. Responsible lawyer: Nadia Petrova. Status date: 2020-06-02.

## Assessment
Claimed or estimated exposure: USD 340,000. Probability classification: remote.

Preservation hold applies to custodians Amara Okafor and Mei Tan. No admission is made.
