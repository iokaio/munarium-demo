---
document_id: NG-DD-0475
category: 08_legal_compliance
title: Compliance Questionnaire — Matter 46
document_date: 2023-05-12
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Compliance Questionnaire — Matter 46

## Matter profile
Matter number: LEG-2021-0046. Responsible lawyer: Nadia Petrova. Status date: 2023-05-12.

## Assessment
Claimed or estimated exposure: USD 830,000. Probability classification: possible.

Preservation hold applies to custodians Mei Tan and Priya Nair. No admission is made.
