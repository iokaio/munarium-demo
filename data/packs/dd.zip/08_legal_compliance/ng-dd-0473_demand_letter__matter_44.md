---
document_id: NG-DD-0473
category: 08_legal_compliance
title: Demand Letter — Matter 44
document_date: 2023-06-15
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 44

## Matter profile
Matter number: LEG-2024-0044. Responsible lawyer: Nadia Petrova. Status date: 2023-06-15.

## Assessment
Claimed or estimated exposure: USD 795,000. Probability classification: probable.

Preservation hold applies to custodians Nadia Petrova and Elena Park. No admission is made.
