---
document_id: NG-DD-0468
category: 08_legal_compliance
title: Settlement Agreement — Matter 39
document_date: 2023-09-08
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 39

## Matter profile
Matter number: LEG-2024-0039. Responsible lawyer: Nadia Petrova. Status date: 2023-09-08.

## Assessment
Claimed or estimated exposure: USD 707,500. Probability classification: remote.

Preservation hold applies to custodians Jonah Reed and Liam Walsh. No admission is made.
