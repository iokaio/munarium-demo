---
document_id: NG-DD-0442
category: 08_legal_compliance
title: Litigation Report — Matter 13
document_date: 2020-08-26
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 13

## Matter profile
Matter number: LEG-2023-0013. Responsible lawyer: Nadia Petrova. Status date: 2020-08-26.

## Assessment
Claimed or estimated exposure: USD 252,500. Probability classification: possible.

Preservation hold applies to custodians Marcus Bell and Derek Cho. No admission is made.
