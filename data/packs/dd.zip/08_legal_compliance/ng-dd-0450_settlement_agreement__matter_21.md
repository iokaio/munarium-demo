---
document_id: NG-DD-0450
category: 08_legal_compliance
title: Settlement Agreement — Matter 21
document_date: 2020-04-12
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Settlement Agreement — Matter 21

## Matter profile
Matter number: LEG-2021-0021. Responsible lawyer: Nadia Petrova. Status date: 2020-04-12.

## Privacy investigation
The California Attorney General opened an inquiry into delayed notice of the VectorPay incident affecting 84,216 individuals. The company has reserved USD 100,000; outside counsel's range is USD 600,000 to USD 2,100,000.
