---
document_id: NG-DD-0455
category: 08_legal_compliance
title: Demand Letter — Matter 26
document_date: 2020-01-18
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Demand Letter — Matter 26

## Matter profile
Matter number: LEG-2021-0026. Responsible lawyer: Nadia Petrova. Status date: 2020-01-18.

## Assessment
Claimed or estimated exposure: USD 480,000. Probability classification: probable.

Preservation hold applies to custodians Priya Nair and Amara Okafor. No admission is made.
