---
document_id: NG-DD-0436
category: 08_legal_compliance
title: Litigation Report — Matter 07
document_date: 2020-12-06
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Litigation Report — Matter 07

## Matter profile
Matter number: LEG-2022-0007. Responsible lawyer: Nadia Petrova. Status date: 2020-12-06.

## Assessment
Claimed or estimated exposure: USD 147,500. Probability classification: possible.

Preservation hold applies to custodians Liam Walsh and Caleb Stone. No admission is made.
