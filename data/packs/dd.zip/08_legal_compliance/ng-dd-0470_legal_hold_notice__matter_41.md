---
document_id: NG-DD-0470
category: 08_legal_compliance
title: Legal Hold Notice — Matter 41
document_date: 2023-08-05
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 41

## Matter profile
Matter number: LEG-2021-0041. Responsible lawyer: Nadia Petrova. Status date: 2023-08-05.

## Assessment
Claimed or estimated exposure: USD 742,500. Probability classification: probable.

Preservation hold applies to custodians Derek Cho and Evan Brooks. No admission is made.
