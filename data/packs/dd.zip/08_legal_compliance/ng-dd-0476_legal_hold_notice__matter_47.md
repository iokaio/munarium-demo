---
document_id: NG-DD-0476
category: 08_legal_compliance
title: Legal Hold Notice — Matter 47
document_date: 2023-04-25
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Legal Hold Notice — Matter 47

## Matter profile
Matter number: LEG-2022-0047. Responsible lawyer: Nadia Petrova. Status date: 2023-04-25.

## Assessment
Claimed or estimated exposure: USD 847,500. Probability classification: probable.

Preservation hold applies to custodians Caleb Stone and Jonah Reed. No admission is made.
