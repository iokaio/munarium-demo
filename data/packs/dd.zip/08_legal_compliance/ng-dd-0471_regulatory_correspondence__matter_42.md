---
document_id: NG-DD-0471
category: 08_legal_compliance
title: Regulatory Correspondence — Matter 42
document_date: 2023-07-19
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Regulatory Correspondence — Matter 42

## Matter profile
Matter number: LEG-2022-0042. Responsible lawyer: Nadia Petrova. Status date: 2023-07-19.

## Assessment
Claimed or estimated exposure: USD 760,000. Probability classification: remote.

Preservation hold applies to custodians Amara Okafor and Mei Tan. No admission is made.
