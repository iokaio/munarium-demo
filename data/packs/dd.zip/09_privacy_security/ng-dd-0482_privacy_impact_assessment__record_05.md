---
document_id: NG-DD-0482
category: 09_privacy_security
title: Privacy Impact Assessment — Record 05
document_date: 2023-01-13
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Privacy Impact Assessment — Record 05

## Control record
Security ticket: SEC-00005. System: ng-production-6. Control owner: Mei Tan.

## Finding
Severity: moderate. Affected records estimate: 2,185. Remediation due: 2023-02-17.

Evidence reference: log bundle SHA-a1e697dbff94. Status: open past due.
