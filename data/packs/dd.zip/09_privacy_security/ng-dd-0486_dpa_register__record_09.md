---
document_id: NG-DD-0486
category: 09_privacy_security
title: DPA Register — Record 09
document_date: 2022-11-06
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# DPA Register — Record 09

## Control record
Security ticket: SEC-00009. System: ng-production-4. Control owner: Mei Tan.

## Notice decision
Counsel advised notification in California and six other states. Management delayed notices for 113 days while negotiating with VectorPay, exceeding several statutory deadlines.
