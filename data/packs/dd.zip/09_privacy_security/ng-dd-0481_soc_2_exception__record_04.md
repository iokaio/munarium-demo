---
document_id: NG-DD-0481
category: 09_privacy_security
title: SOC 2 Exception — Record 04
document_date: 2023-01-30
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# SOC 2 Exception — Record 04

## Control record
Security ticket: SEC-00004. System: ng-production-5. Control owner: Mei Tan.

## Finding
Severity: low. Affected records estimate: 1,848. Remediation due: 2023-03-05.

Evidence reference: log bundle SHA-9ec4db3fd820. Status: closed.
