---
document_id: NG-DD-0498
category: 09_privacy_security
title: DPA Register — Record 21
document_date: 2022-04-16
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# DPA Register — Record 21

## Control record
Security ticket: SEC-00021. System: ng-production-4. Control owner: Mei Tan.

## Finding
Severity: moderate. Affected records estimate: 7,577. Remediation due: 2022-06-06.

Evidence reference: log bundle SHA-e5d191397924. Status: closed.
