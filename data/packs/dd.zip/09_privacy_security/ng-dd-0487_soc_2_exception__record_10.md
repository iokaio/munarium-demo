---
document_id: NG-DD-0487
category: 09_privacy_security
title: SOC 2 Exception — Record 10
document_date: 2022-10-20
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# SOC 2 Exception — Record 10

## Control record
Security ticket: SEC-00010. System: ng-production-5. Control owner: Mei Tan.

## Finding
Severity: high. Affected records estimate: 3,870. Remediation due: 2022-11-29.

Evidence reference: log bundle SHA-aacb3007d113. Status: open past due.
