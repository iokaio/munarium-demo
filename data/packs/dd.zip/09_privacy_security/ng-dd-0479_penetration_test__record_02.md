---
document_id: NG-DD-0479
category: 09_privacy_security
title: Penetration Test — Record 02
document_date: 2023-03-05
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Penetration Test — Record 02

## Control record
Security ticket: SEC-00002. System: ng-production-3. Control owner: Mei Tan.

## Finding
Severity: high. Affected records estimate: 1,174. Remediation due: 2023-04-06.

Evidence reference: log bundle SHA-07c37bf49fe0. Status: closed.
