---
document_id: NG-DD-0488
category: 09_privacy_security
title: Privacy Impact Assessment — Record 11
document_date: 2022-10-03
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Privacy Impact Assessment — Record 11

## Control record
Security ticket: SEC-00011. System: ng-production-6. Control owner: Mei Tan.

## Finding
Severity: critical. Affected records estimate: 4,207. Remediation due: 2022-11-13.

Evidence reference: log bundle SHA-696f17015c0c. Status: closed.
