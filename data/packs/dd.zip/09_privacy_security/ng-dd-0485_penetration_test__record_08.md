---
document_id: NG-DD-0485
category: 09_privacy_security
title: Penetration Test — Record 08
document_date: 2022-11-23
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Penetration Test — Record 08

## Control record
Security ticket: SEC-00008. System: ng-production-3. Control owner: Mei Tan.

## Finding
Severity: low. Affected records estimate: 3,196. Remediation due: 2022-12-31.

Evidence reference: log bundle SHA-f86aecb9116a. Status: closed.
