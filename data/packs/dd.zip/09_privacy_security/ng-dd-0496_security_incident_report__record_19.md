---
document_id: NG-DD-0496
category: 09_privacy_security
title: Security Incident Report — Record 19
document_date: 2022-05-20
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Security Incident Report — Record 19

## Control record
Security ticket: SEC-00019. System: ng-production-2. Control owner: Mei Tan.

## Finding
Severity: critical. Affected records estimate: 6,903. Remediation due: 2022-07-08.

Evidence reference: log bundle SHA-ce798c186437. Status: closed.
