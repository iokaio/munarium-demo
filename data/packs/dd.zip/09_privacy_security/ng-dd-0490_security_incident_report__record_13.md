---
document_id: NG-DD-0490
category: 09_privacy_security
title: Security Incident Report — Record 13
document_date: 2022-08-30
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Security Incident Report — Record 13

## Control record
Security ticket: SEC-00013. System: ng-production-2. Control owner: Mei Tan.

## Finding
Severity: moderate. Affected records estimate: 4,881. Remediation due: 2022-10-12.

Evidence reference: log bundle SHA-85bba4ee7ff4. Status: closed.
