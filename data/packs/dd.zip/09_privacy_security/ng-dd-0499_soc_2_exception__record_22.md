---
document_id: NG-DD-0499
category: 09_privacy_security
title: SOC 2 Exception — Record 22
document_date: 2022-03-30
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# SOC 2 Exception — Record 22

## Control record
Security ticket: SEC-00022. System: ng-production-5. Control owner: Mei Tan.

## Finding
Severity: high. Affected records estimate: 7,914. Remediation due: 2022-05-21.

Evidence reference: log bundle SHA-b896a2bc36d7. Status: closed.
