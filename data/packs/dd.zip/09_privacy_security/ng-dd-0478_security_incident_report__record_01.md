---
document_id: NG-DD-0478
category: 09_privacy_security
title: Security Incident Report — Record 01
document_date: 2023-03-22
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Security Incident Report — Record 01

## Control record
Security ticket: SEC-00001. System: ng-production-2. Control owner: Mei Tan.

## VectorPay incident
On September 14, 2022, a compromised service account exposed names, contact data, member identifiers, and limited claims data for 84,216 individuals. The incident register initially recorded 12,400 affected individuals.
