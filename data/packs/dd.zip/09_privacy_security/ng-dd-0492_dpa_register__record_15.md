---
document_id: NG-DD-0492
category: 09_privacy_security
title: DPA Register — Record 15
document_date: 2022-07-27
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# DPA Register — Record 15

## Control record
Security ticket: SEC-00015. System: ng-production-4. Control owner: Mei Tan.

## Finding
Severity: critical. Affected records estimate: 5,555. Remediation due: 2022-09-10.

Evidence reference: log bundle SHA-16736e4d2da2. Status: open past due.
