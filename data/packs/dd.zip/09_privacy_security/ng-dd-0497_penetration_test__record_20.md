---
document_id: NG-DD-0497
category: 09_privacy_security
title: Penetration Test — Record 20
document_date: 2022-05-03
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Penetration Test — Record 20

## Control record
Security ticket: SEC-00020. System: ng-production-3. Control owner: Mei Tan.

## Finding
Severity: low. Affected records estimate: 7,240. Remediation due: 2022-06-22.

Evidence reference: log bundle SHA-e2d1fe1056b6. Status: open past due.
