---
document_id: NG-DD-0484
category: 09_privacy_security
title: Security Incident Report — Record 07
document_date: 2022-12-10
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Security Incident Report — Record 07

## Control record
Security ticket: SEC-00007. System: ng-production-2. Control owner: Mei Tan.

## Finding
Severity: critical. Affected records estimate: 2,859. Remediation due: 2023-01-16.

Evidence reference: log bundle SHA-6bde54df9cf5. Status: closed.
