---
document_id: NG-DD-0493
category: 09_privacy_security
title: SOC 2 Exception — Record 16
document_date: 2022-07-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# SOC 2 Exception — Record 16

## Control record
Security ticket: SEC-00016. System: ng-production-5. Control owner: Mei Tan.

## Finding
Severity: low. Affected records estimate: 5,892. Remediation due: 2022-08-25.

Evidence reference: log bundle SHA-7ab8ef3a8ab2. Status: closed.
