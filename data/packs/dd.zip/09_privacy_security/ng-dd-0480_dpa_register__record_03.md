---
document_id: NG-DD-0480
category: 09_privacy_security
title: DPA Register — Record 03
document_date: 2023-02-16
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# DPA Register — Record 03

## Control record
Security ticket: SEC-00003. System: ng-production-4. Control owner: Mei Tan.

## Finding
Severity: critical. Affected records estimate: 1,511. Remediation due: 2023-03-21.

Evidence reference: log bundle SHA-a776c803a134. Status: closed.
