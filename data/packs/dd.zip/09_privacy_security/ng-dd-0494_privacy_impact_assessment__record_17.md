---
document_id: NG-DD-0494
category: 09_privacy_security
title: Privacy Impact Assessment — Record 17
document_date: 2022-06-23
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Privacy Impact Assessment — Record 17

## Control record
Security ticket: SEC-00017. System: ng-production-6. Control owner: Mei Tan.

## SOC 2 exception
The 2023 SOC 2 report excluded the legacy Meridian environment from scope. That environment processes approximately 41% of production transactions and lacks enforced multifactor authentication for privileged users.
