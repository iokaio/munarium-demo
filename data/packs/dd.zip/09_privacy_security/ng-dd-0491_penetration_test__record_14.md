---
document_id: NG-DD-0491
category: 09_privacy_security
title: Penetration Test — Record 14
document_date: 2022-08-13
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Penetration Test — Record 14

## Control record
Security ticket: SEC-00014. System: ng-production-3. Control owner: Mei Tan.

## Finding
Severity: high. Affected records estimate: 5,218. Remediation due: 2022-09-26.

Evidence reference: log bundle SHA-a4c081e8647e. Status: closed.
