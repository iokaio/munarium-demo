---
document_id: NG-DD-0400
category: 07_intellectual_property
title: Patent Schedule — Asset 25
document_date: 2022-08-10
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 25

## Asset record
Internal asset identifier: IP-00025. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-03-03.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-025.
