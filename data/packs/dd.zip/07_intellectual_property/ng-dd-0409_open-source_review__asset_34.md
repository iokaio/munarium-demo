---
document_id: NG-DD-0409
category: 07_intellectual_property
title: Open-Source Review — Asset 34
document_date: 2022-03-10
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 34

## Asset record
Internal asset identifier: IP-00034. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-10-10.

Diligence status: clear. Repository reference: repo/ng-flow-6/tag-034.
