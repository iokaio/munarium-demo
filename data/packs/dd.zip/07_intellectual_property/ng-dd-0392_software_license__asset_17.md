---
document_id: NG-DD-0392
category: 07_intellectual_property
title: Software License — Asset 17
document_date: 2022-12-24
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 17

## Asset record
Internal asset identifier: IP-00017. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-07-09.

Diligence status: clear. Repository reference: repo/ng-flow-3/tag-017.
