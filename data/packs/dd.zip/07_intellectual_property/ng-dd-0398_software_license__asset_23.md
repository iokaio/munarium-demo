---
document_id: NG-DD-0398
category: 07_intellectual_property
title: Software License — Asset 23
document_date: 2022-09-13
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 23

## Asset record
Internal asset identifier: IP-00023. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-04-04.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-023.
