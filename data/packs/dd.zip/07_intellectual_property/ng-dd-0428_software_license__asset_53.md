---
document_id: NG-DD-0428
category: 07_intellectual_property
title: Software License — Asset 53
document_date: 2021-04-21
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 53

## Asset record
Internal asset identifier: IP-00053. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2021-12-10.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-053.
