---
document_id: NG-DD-0402
category: 07_intellectual_property
title: Invention Assignment — Asset 27
document_date: 2022-07-07
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 27

## Asset record
Internal asset identifier: IP-00027. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Copyleft dependency
The appliance image statically links a modified AGPL-3.0 component. The source-offer process has not been implemented for 214 distributed appliances.
