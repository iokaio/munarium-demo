---
document_id: NG-DD-0410
category: 07_intellectual_property
title: Software License — Asset 35
document_date: 2022-02-21
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 35

## Asset record
Internal asset identifier: IP-00035. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-09-24.

Diligence status: clear. Repository reference: repo/ng-flow-0/tag-035.
