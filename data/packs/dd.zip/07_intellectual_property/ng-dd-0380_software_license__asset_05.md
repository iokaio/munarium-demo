---
document_id: NG-DD-0380
category: 07_intellectual_property
title: Software License — Asset 05
document_date: 2023-07-16
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 05

## Asset record
Internal asset identifier: IP-00005. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2024-01-17.

Diligence status: clear. Repository reference: repo/ng-flow-5/tag-005.
