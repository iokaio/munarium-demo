---
document_id: NG-DD-0423
category: 07_intellectual_property
title: Domain Register — Asset 48
document_date: 2021-07-15
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 48

## Asset record
Internal asset identifier: IP-00048. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Analytics LLC. Renewal or maintenance deadline: 2022-02-28.

Diligence status: supporting assignment missing. Repository reference: repo/ng-flow-6/tag-048.
