---
document_id: NG-DD-0417
category: 07_intellectual_property
title: Domain Register — Asset 42
document_date: 2021-10-25
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 42

## Asset record
Internal asset identifier: IP-00042. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-06-04.

Diligence status: supporting assignment missing. Repository reference: repo/ng-flow-0/tag-042.
