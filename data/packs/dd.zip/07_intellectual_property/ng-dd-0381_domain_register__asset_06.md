---
document_id: NG-DD-0381
category: 07_intellectual_property
title: Domain Register — Asset 06
document_date: 2023-06-29
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 06

## Asset record
Internal asset identifier: IP-00006. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Founder code
Core scheduling engine commits from 2018 were authored by Elena Park before Northgate's incorporation. No written assignment from Elena to Northgate was located; the employment agreement assigns only future inventions.
