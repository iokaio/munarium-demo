---
document_id: NG-DD-0412
category: 07_intellectual_property
title: Patent Schedule — Asset 37
document_date: 2022-01-18
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 37

## Asset record
Internal asset identifier: IP-00037. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-08-23.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-037.
