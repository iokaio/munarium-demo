---
document_id: NG-DD-0386
category: 07_intellectual_property
title: Software License — Asset 11
document_date: 2023-04-05
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 11

## Asset record
Internal asset identifier: IP-00011. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-10-13.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-011.
