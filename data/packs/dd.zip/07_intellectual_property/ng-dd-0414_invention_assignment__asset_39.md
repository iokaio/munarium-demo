---
document_id: NG-DD-0414
category: 07_intellectual_property
title: Invention Assignment — Asset 39
document_date: 2021-12-15
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 39

## Asset record
Internal asset identifier: IP-00039. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-07-22.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-039.
