---
document_id: NG-DD-0394
category: 07_intellectual_property
title: Patent Schedule — Asset 19
document_date: 2022-11-20
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 19

## Asset record
Internal asset identifier: IP-00019. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-06-07.

Diligence status: clear. Repository reference: repo/ng-flow-5/tag-019.
