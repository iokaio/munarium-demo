---
document_id: NG-DD-0397
category: 07_intellectual_property
title: Open-Source Review — Asset 22
document_date: 2022-09-30
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 22

## Asset record
Internal asset identifier: IP-00022. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-04-20.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-022.
