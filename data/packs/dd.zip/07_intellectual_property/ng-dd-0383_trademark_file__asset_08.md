---
document_id: NG-DD-0383
category: 07_intellectual_property
title: Trademark File — Asset 08
document_date: 2023-05-26
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 08

## Asset record
Internal asset identifier: IP-00008. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Analytics LLC. Renewal or maintenance deadline: 2023-11-30.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-008.
