---
document_id: NG-DD-0406
category: 07_intellectual_property
title: Patent Schedule — Asset 31
document_date: 2022-04-30
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 31

## Asset record
Internal asset identifier: IP-00031. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-11-27.

Diligence status: clear. Repository reference: repo/ng-flow-3/tag-031.
