---
document_id: NG-DD-0416
category: 07_intellectual_property
title: Software License — Asset 41
document_date: 2021-11-11
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 41

## Asset record
Internal asset identifier: IP-00041. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-06-20.

Diligence status: clear. Repository reference: repo/ng-flow-6/tag-041.
