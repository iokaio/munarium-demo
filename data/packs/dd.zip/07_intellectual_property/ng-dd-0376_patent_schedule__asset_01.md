---
document_id: NG-DD-0376
category: 07_intellectual_property
title: Patent Schedule — Asset 01
document_date: 2023-09-22
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 01

## Asset record
Internal asset identifier: IP-00001. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2024-03-21.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-001.
