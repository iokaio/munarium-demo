---
document_id: NG-DD-0403
category: 07_intellectual_property
title: Open-Source Review — Asset 28
document_date: 2022-06-20
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 28

## Asset record
Internal asset identifier: IP-00028. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-01-14.

Diligence status: clear. Repository reference: repo/ng-flow-0/tag-028.
