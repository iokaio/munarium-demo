---
document_id: NG-DD-0377
category: 07_intellectual_property
title: Trademark File — Asset 02
document_date: 2023-09-05
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 02

## Asset record
Internal asset identifier: IP-00002. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2024-03-05.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-002.
