---
document_id: NG-DD-0424
category: 07_intellectual_property
title: Patent Schedule — Asset 49
document_date: 2021-06-28
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 49

## Asset record
Internal asset identifier: IP-00049. Product family: Northgate Flow 2. Review owner: Derek Cho.

## License assignment
The Ironwood terminology database license prohibits assignment, including by merger or change of control, without written consent. It is embedded in every production deployment.
