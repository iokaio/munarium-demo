---
document_id: NG-DD-0421
category: 07_intellectual_property
title: Open-Source Review — Asset 46
document_date: 2021-08-18
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 46

## Asset record
Internal asset identifier: IP-00046. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-04-01.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-046.
