---
document_id: NG-DD-0393
category: 07_intellectual_property
title: Domain Register — Asset 18
document_date: 2022-12-07
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 18

## Asset record
Internal asset identifier: IP-00018. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Contractor chain of title
SableWorks developers created the claims-rules module. The services agreement grants Northgate a perpetual license but does not assign ownership. The product roadmap describes the module as proprietary Northgate IP.
