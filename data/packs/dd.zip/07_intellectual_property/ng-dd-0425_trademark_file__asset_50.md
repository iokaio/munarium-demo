---
document_id: NG-DD-0425
category: 07_intellectual_property
title: Trademark File — Asset 50
document_date: 2021-06-11
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 50

## Asset record
Internal asset identifier: IP-00050. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-01-27.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-050.
