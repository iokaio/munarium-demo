---
document_id: NG-DD-0408
category: 07_intellectual_property
title: Invention Assignment — Asset 33
document_date: 2022-03-27
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 33

## Asset record
Internal asset identifier: IP-00033. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-10-26.

Diligence status: clear. Repository reference: repo/ng-flow-5/tag-033.
