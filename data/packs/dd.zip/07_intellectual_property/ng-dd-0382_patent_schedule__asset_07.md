---
document_id: NG-DD-0382
category: 07_intellectual_property
title: Patent Schedule — Asset 07
document_date: 2023-06-12
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 07

## Asset record
Internal asset identifier: IP-00007. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-12-16.

Diligence status: clear. Repository reference: repo/ng-flow-0/tag-007.
