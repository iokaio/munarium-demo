---
document_id: NG-DD-0399
category: 07_intellectual_property
title: Domain Register — Asset 24
document_date: 2022-08-27
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 24

## Asset record
Internal asset identifier: IP-00024. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Analytics LLC. Renewal or maintenance deadline: 2023-03-19.

Diligence status: supporting assignment missing. Repository reference: repo/ng-flow-3/tag-024.
