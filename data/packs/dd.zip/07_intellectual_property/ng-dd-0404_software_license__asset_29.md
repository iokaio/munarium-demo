---
document_id: NG-DD-0404
category: 07_intellectual_property
title: Software License — Asset 29
document_date: 2022-06-03
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 29

## Asset record
Internal asset identifier: IP-00029. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-12-29.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-029.
