---
document_id: NG-DD-0426
category: 07_intellectual_property
title: Invention Assignment — Asset 51
document_date: 2021-05-25
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 51

## Asset record
Internal asset identifier: IP-00051. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-01-11.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-051.
