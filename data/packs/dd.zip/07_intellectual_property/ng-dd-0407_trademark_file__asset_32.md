---
document_id: NG-DD-0407
category: 07_intellectual_property
title: Trademark File — Asset 32
document_date: 2022-04-13
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 32

## Asset record
Internal asset identifier: IP-00032. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Analytics LLC. Renewal or maintenance deadline: 2022-11-11.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-032.
