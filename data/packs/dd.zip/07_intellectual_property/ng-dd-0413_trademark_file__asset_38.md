---
document_id: NG-DD-0413
category: 07_intellectual_property
title: Trademark File — Asset 38
document_date: 2022-01-01
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 38

## Asset record
Internal asset identifier: IP-00038. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-08-07.

Diligence status: clear. Repository reference: repo/ng-flow-3/tag-038.
