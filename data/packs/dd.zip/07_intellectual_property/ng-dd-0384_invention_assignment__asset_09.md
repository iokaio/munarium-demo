---
document_id: NG-DD-0384
category: 07_intellectual_property
title: Invention Assignment — Asset 09
document_date: 2023-05-09
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 09

## Asset record
Internal asset identifier: IP-00009. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-11-14.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-009.
