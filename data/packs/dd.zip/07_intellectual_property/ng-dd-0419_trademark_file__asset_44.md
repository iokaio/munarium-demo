---
document_id: NG-DD-0419
category: 07_intellectual_property
title: Trademark File — Asset 44
document_date: 2021-09-21
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 44

## Asset record
Internal asset identifier: IP-00044. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-05-03.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-044.
