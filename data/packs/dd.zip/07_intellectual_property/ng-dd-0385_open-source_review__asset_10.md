---
document_id: NG-DD-0385
category: 07_intellectual_property
title: Open-Source Review — Asset 10
document_date: 2023-04-22
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 10

## Asset record
Internal asset identifier: IP-00010. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-10-29.

Diligence status: clear. Repository reference: repo/ng-flow-3/tag-010.
