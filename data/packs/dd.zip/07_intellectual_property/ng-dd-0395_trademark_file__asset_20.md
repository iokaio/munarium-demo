---
document_id: NG-DD-0395
category: 07_intellectual_property
title: Trademark File — Asset 20
document_date: 2022-11-03
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 20

## Asset record
Internal asset identifier: IP-00020. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-05-22.

Diligence status: clear. Repository reference: repo/ng-flow-6/tag-020.
