---
document_id: NG-DD-0415
category: 07_intellectual_property
title: Open-Source Review — Asset 40
document_date: 2021-11-28
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 40

## Asset record
Internal asset identifier: IP-00040. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Analytics LLC. Renewal or maintenance deadline: 2022-07-06.

Diligence status: clear. Repository reference: repo/ng-flow-5/tag-040.
