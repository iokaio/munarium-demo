---
document_id: NG-DD-0379
category: 07_intellectual_property
title: Open-Source Review — Asset 04
document_date: 2023-08-02
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 04

## Asset record
Internal asset identifier: IP-00004. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2024-02-02.

Diligence status: clear. Repository reference: repo/ng-flow-4/tag-004.
