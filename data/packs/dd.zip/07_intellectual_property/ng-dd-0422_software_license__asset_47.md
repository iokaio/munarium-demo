---
document_id: NG-DD-0422
category: 07_intellectual_property
title: Software License — Asset 47
document_date: 2021-08-01
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Software License — Asset 47

## Asset record
Internal asset identifier: IP-00047. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-03-16.

Diligence status: clear. Repository reference: repo/ng-flow-5/tag-047.
