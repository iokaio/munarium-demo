---
document_id: NG-DD-0391
category: 07_intellectual_property
title: Open-Source Review — Asset 16
document_date: 2023-01-10
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 16

## Asset record
Internal asset identifier: IP-00016. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Analytics LLC. Renewal or maintenance deadline: 2023-07-25.

Diligence status: clear. Repository reference: repo/ng-flow-2/tag-016.
