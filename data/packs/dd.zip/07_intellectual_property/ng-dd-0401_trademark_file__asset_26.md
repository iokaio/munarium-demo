---
document_id: NG-DD-0401
category: 07_intellectual_property
title: Trademark File — Asset 26
document_date: 2022-07-24
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Trademark File — Asset 26

## Asset record
Internal asset identifier: IP-00026. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-02-15.

Diligence status: clear. Repository reference: repo/ng-flow-5/tag-026.
