---
document_id: NG-DD-0405
category: 07_intellectual_property
title: Domain Register — Asset 30
document_date: 2022-05-17
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 30

## Asset record
Internal asset identifier: IP-00030. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-12-13.

Diligence status: supporting assignment missing. Repository reference: repo/ng-flow-2/tag-030.
