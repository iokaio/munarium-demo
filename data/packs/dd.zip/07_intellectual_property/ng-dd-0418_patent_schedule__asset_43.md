---
document_id: NG-DD-0418
category: 07_intellectual_property
title: Patent Schedule — Asset 43
document_date: 2021-10-08
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 43

## Asset record
Internal asset identifier: IP-00043. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-05-19.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-043.
