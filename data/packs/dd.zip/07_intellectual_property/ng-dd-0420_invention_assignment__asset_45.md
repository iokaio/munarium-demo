---
document_id: NG-DD-0420
category: 07_intellectual_property
title: Invention Assignment — Asset 45
document_date: 2021-09-04
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 45

## Asset record
Internal asset identifier: IP-00045. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2022-04-17.

Diligence status: clear. Repository reference: repo/ng-flow-3/tag-045.
