---
document_id: NG-DD-0390
category: 07_intellectual_property
title: Invention Assignment — Asset 15
document_date: 2023-01-27
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 15

## Asset record
Internal asset identifier: IP-00015. Product family: Northgate Flow 4. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-08-10.

Diligence status: clear. Repository reference: repo/ng-flow-1/tag-015.
