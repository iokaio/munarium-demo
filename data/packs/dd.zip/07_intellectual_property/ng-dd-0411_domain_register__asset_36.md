---
document_id: NG-DD-0411
category: 07_intellectual_property
title: Domain Register — Asset 36
document_date: 2022-02-04
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 36

## Asset record
Internal asset identifier: IP-00036. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Patent dispute
Competitor Ardent Logic sent a claim chart alleging that Northgate Flow infringes U.S. Patent 10,884,211. Outside counsel estimates defense costs of USD 1,500,000 through summary judgment.
