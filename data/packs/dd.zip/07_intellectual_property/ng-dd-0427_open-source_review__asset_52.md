---
document_id: NG-DD-0427
category: 07_intellectual_property
title: Open-Source Review — Asset 52
document_date: 2021-05-08
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Open-Source Review — Asset 52

## Asset record
Internal asset identifier: IP-00052. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2021-12-26.

Diligence status: clear. Repository reference: repo/ng-flow-3/tag-052.
