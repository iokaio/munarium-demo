---
document_id: NG-DD-0429
category: 07_intellectual_property
title: Domain Register — Asset 54
document_date: 2021-04-04
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 54

## Asset record
Internal asset identifier: IP-00054. Product family: Northgate Flow 3. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2021-11-24.

Diligence status: supporting assignment missing. Repository reference: repo/ng-flow-5/tag-054.
