---
document_id: NG-DD-0387
category: 07_intellectual_property
title: Domain Register — Asset 12
document_date: 2023-03-19
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Domain Register — Asset 12

## Asset record
Internal asset identifier: IP-00012. Product family: Northgate Flow 1. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-09-27.

Diligence status: supporting assignment missing. Repository reference: repo/ng-flow-5/tag-012.
