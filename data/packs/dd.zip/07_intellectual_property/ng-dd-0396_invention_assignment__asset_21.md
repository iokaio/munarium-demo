---
document_id: NG-DD-0396
category: 07_intellectual_property
title: Invention Assignment — Asset 21
document_date: 2022-10-17
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Invention Assignment — Asset 21

## Asset record
Internal asset identifier: IP-00021. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-05-06.

Diligence status: clear. Repository reference: repo/ng-flow-0/tag-021.
