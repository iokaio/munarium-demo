---
document_id: NG-DD-0388
category: 07_intellectual_property
title: Patent Schedule — Asset 13
document_date: 2023-03-02
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Patent Schedule — Asset 13

## Asset record
Internal asset identifier: IP-00013. Product family: Northgate Flow 2. Review owner: Derek Cho.

## Ownership and restrictions
Recorded owner: Northgate Systems Ltd.. Renewal or maintenance deadline: 2023-09-11.

Diligence status: clear. Repository reference: repo/ng-flow-6/tag-013.
