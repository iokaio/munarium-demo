---
document_id: NG-DD-0047
category: 02_equity
title: Warrant Register — Item 05
document_date: 2022-01-23
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 05

## Capital record
Record date: 2022-01-23. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Derek Cho is recorded as holding 46,250 common shares or options under grant EQ-0005. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
