---
document_id: NG-DD-0061
category: 02_equity
title: Capitalization Schedule — Item 19
document_date: 2021-05-30
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 19

## Capital record
Record date: 2021-05-30. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Liam Walsh is recorded as holding 63,750 common shares or options under grant EQ-0019. Exercise price: USD 2.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
