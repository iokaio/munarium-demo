---
document_id: NG-DD-0067
category: 02_equity
title: Capitalization Schedule — Item 25
document_date: 2021-02-17
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 25

## Capital record
Record date: 2021-02-17. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Holder detail
Marcus Bell is recorded as holding 71,250 common shares or options under grant EQ-0025. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
