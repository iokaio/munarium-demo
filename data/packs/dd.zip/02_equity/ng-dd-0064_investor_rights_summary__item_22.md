---
document_id: NG-DD-0064
category: 02_equity
title: Investor Rights Summary — Item 22
document_date: 2021-04-09
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 22

## Capital record
Record date: 2021-04-09. Common shares shown as issued and outstanding: 8,025,000. Authorized common shares: 12,000,000.

## Holder detail
Mei Tan is recorded as holding 67,500 common shares or options under grant EQ-0022. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
