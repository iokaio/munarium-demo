---
document_id: NG-DD-0082
category: 02_equity
title: Investor Rights Summary — Item 40
document_date: 2020-06-07
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 40

## Capital record
Record date: 2020-06-07. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Sofia Alvarez is recorded as holding 90,000 common shares or options under grant EQ-0040. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
