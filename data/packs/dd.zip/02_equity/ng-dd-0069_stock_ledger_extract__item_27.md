---
document_id: NG-DD-0069
category: 02_equity
title: Stock Ledger Extract — Item 27
document_date: 2021-01-14
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 27

## Capital record
Record date: 2021-01-14. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Holder detail
Jonah Reed is recorded as holding 73,750 common shares or options under grant EQ-0027. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
