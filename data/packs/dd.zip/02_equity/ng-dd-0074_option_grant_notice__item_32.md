---
document_id: NG-DD-0074
category: 02_equity
title: Option Grant Notice — Item 32
document_date: 2020-10-21
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 32

## Capital record
Record date: 2020-10-21. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Holder detail
Nadia Petrova is recorded as holding 80,000 common shares or options under grant EQ-0032. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
