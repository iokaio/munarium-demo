---
document_id: NG-DD-0049
category: 02_equity
title: Capitalization Schedule — Item 07
document_date: 2021-12-20
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 07

## Capital record
Record date: 2021-12-20. Common shares shown as issued and outstanding: 8,000,000. Authorized common shares: 12,000,000.

## Holder detail
Liam Walsh is recorded as holding 48,750 common shares or options under grant EQ-0007. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
