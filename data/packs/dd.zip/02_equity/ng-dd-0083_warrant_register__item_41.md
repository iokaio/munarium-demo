---
document_id: NG-DD-0083
category: 02_equity
title: Warrant Register — Item 41
document_date: 2020-05-21
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 41

## Capital record
Record date: 2020-05-21. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Repurchase right
Founder Elena Park's remaining 240,000 restricted shares are subject to a company repurchase right. The right lapses on a double-trigger basis; the draft transaction model assumes single-trigger acceleration.
