---
document_id: NG-DD-0088
category: 02_equity
title: Investor Rights Summary — Item 46
document_date: 2020-02-26
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 46

## Capital record
Record date: 2020-02-26. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Holder detail
Mei Tan is recorded as holding 97,500 common shares or options under grant EQ-0046. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
