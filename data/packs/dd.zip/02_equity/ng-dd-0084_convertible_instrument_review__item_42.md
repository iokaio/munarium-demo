---
document_id: NG-DD-0084
category: 02_equity
title: Convertible Instrument Review — Item 42
document_date: 2020-05-04
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Convertible Instrument Review — Item 42

## Capital record
Record date: 2020-05-04. Common shares shown as issued and outstanding: 8,000,000. Authorized common shares: 12,000,000.

## Holder detail
Amara Okafor is recorded as holding 92,500 common shares or options under grant EQ-0042. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
