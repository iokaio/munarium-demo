---
document_id: NG-DD-0065
category: 02_equity
title: Warrant Register — Item 23
document_date: 2021-03-23
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 23

## Capital record
Record date: 2021-03-23. Common shares shown as issued and outstanding: 8,050,000. Authorized common shares: 12,000,000.

## Holder detail
Caleb Stone is recorded as holding 68,750 common shares or options under grant EQ-0023. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
