---
document_id: NG-DD-0090
category: 02_equity
title: Convertible Instrument Review — Item 48
document_date: 2020-01-23
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Convertible Instrument Review — Item 48

## Capital record
Record date: 2020-01-23. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Holder detail
Elena Park is recorded as holding 100,000 common shares or options under grant EQ-0048. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
