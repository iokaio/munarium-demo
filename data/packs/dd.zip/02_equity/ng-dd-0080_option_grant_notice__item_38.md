---
document_id: NG-DD-0080
category: 02_equity
title: Option Grant Notice — Item 38
document_date: 2020-07-11
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 38

## Capital record
Record date: 2020-07-11. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Holder detail
Priya Nair is recorded as holding 87,500 common shares or options under grant EQ-0038. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
