---
document_id: NG-DD-0055
category: 02_equity
title: Capitalization Schedule — Item 13
document_date: 2021-09-09
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 13

## Capital record
Record date: 2021-09-09. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Holder detail
Marcus Bell is recorded as holding 56,250 common shares or options under grant EQ-0013. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
