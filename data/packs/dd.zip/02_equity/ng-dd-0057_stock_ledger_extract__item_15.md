---
document_id: NG-DD-0057
category: 02_equity
title: Stock Ledger Extract — Item 15
document_date: 2021-08-06
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 15

## Capital record
Record date: 2021-08-06. Common shares shown as issued and outstanding: 8,025,000. Authorized common shares: 12,000,000.

## Holder detail
Jonah Reed is recorded as holding 58,750 common shares or options under grant EQ-0015. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
