---
document_id: NG-DD-0066
category: 02_equity
title: Convertible Instrument Review — Item 24
document_date: 2021-03-06
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Convertible Instrument Review — Item 24

## Capital record
Record date: 2021-03-06. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Holder detail
Elena Park is recorded as holding 70,000 common shares or options under grant EQ-0024. Exercise price: USD 2.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
