---
document_id: NG-DD-0053
category: 02_equity
title: Warrant Register — Item 11
document_date: 2021-10-13
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 11

## Capital record
Record date: 2021-10-13. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Holder detail
Caleb Stone is recorded as holding 53,750 common shares or options under grant EQ-0011. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
