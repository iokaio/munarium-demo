---
document_id: NG-DD-0089
category: 02_equity
title: Warrant Register — Item 47
document_date: 2020-02-09
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 47

## Capital record
Record date: 2020-02-09. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Caleb Stone is recorded as holding 98,750 common shares or options under grant EQ-0047. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
