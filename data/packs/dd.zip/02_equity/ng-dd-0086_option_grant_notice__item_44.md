---
document_id: NG-DD-0086
category: 02_equity
title: Option Grant Notice — Item 44
document_date: 2020-03-31
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 44

## Capital record
Record date: 2020-03-31. Common shares shown as issued and outstanding: 8,050,000. Authorized common shares: 12,000,000.

## Holder detail
Nadia Petrova is recorded as holding 95,000 common shares or options under grant EQ-0044. Exercise price: USD 2.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
