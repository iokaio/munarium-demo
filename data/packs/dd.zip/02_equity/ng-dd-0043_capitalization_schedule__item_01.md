---
document_id: NG-DD-0043
category: 02_equity
title: Capitalization Schedule — Item 01
document_date: 2022-04-01
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 01

## Capital record
Record date: 2022-04-01. Common shares shown as issued and outstanding: 8,025,000. Authorized common shares: 12,000,000.

## Holder detail
Marcus Bell is recorded as holding 41,250 common shares or options under grant EQ-0001. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
