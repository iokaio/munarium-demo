---
document_id: NG-DD-0052
category: 02_equity
title: Investor Rights Summary — Item 10
document_date: 2021-10-30
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 10

## Capital record
Record date: 2021-10-30. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Holder detail
Mei Tan is recorded as holding 52,500 common shares or options under grant EQ-0010. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
