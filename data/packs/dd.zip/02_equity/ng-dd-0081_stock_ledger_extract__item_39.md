---
document_id: NG-DD-0081
category: 02_equity
title: Stock Ledger Extract — Item 39
document_date: 2020-06-24
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 39

## Capital record
Record date: 2020-06-24. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Holder detail
Jonah Reed is recorded as holding 88,750 common shares or options under grant EQ-0039. Exercise price: USD 2.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
