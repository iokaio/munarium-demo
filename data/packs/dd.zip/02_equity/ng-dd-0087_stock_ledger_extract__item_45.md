---
document_id: NG-DD-0087
category: 02_equity
title: Stock Ledger Extract — Item 45
document_date: 2020-03-14
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 45

## Capital record
Record date: 2020-03-14. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Holder detail
Evan Brooks is recorded as holding 96,250 common shares or options under grant EQ-0045. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
