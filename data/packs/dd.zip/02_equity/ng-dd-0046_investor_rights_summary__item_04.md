---
document_id: NG-DD-0046
category: 02_equity
title: Investor Rights Summary — Item 04
document_date: 2022-02-09
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 04

## Capital record
Record date: 2022-02-09. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Management capitalization
The transaction capitalization table states 8,125,000 common shares outstanding and 775,000 options outstanding, of which 510,000 are vested.
