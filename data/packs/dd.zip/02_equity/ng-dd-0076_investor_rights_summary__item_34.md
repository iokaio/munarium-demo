---
document_id: NG-DD-0076
category: 02_equity
title: Investor Rights Summary — Item 34
document_date: 2020-09-17
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 34

## Capital record
Record date: 2020-09-17. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Holder detail
Mei Tan is recorded as holding 82,500 common shares or options under grant EQ-0034. Exercise price: USD 2.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
