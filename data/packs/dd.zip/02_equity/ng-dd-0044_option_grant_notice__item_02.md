---
document_id: NG-DD-0044
category: 02_equity
title: Option Grant Notice — Item 02
document_date: 2022-03-15
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 02

## Capital record
Record date: 2022-03-15. Common shares shown as issued and outstanding: 8,050,000. Authorized common shares: 12,000,000.

## Holder detail
Priya Nair is recorded as holding 42,500 common shares or options under grant EQ-0002. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
