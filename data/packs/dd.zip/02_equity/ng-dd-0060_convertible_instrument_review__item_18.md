---
document_id: NG-DD-0060
category: 02_equity
title: Convertible Instrument Review — Item 18
document_date: 2021-06-16
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Convertible Instrument Review — Item 18

## Capital record
Record date: 2021-06-16. Common shares shown as issued and outstanding: 8,100,000. Authorized common shares: 12,000,000.

## Holder detail
Amara Okafor is recorded as holding 62,500 common shares or options under grant EQ-0018. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
