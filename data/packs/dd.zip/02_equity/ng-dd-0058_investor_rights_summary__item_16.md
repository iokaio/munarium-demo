---
document_id: NG-DD-0058
category: 02_equity
title: Investor Rights Summary — Item 16
document_date: 2021-07-20
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 16

## Capital record
Record date: 2021-07-20. Common shares shown as issued and outstanding: 8,050,000. Authorized common shares: 12,000,000.

## Holder detail
Sofia Alvarez is recorded as holding 60,000 common shares or options under grant EQ-0016. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
