---
document_id: NG-DD-0048
category: 02_equity
title: Convertible Instrument Review — Item 06
document_date: 2022-01-06
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Convertible Instrument Review — Item 06

## Capital record
Record date: 2022-01-06. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Holder detail
Amara Okafor is recorded as holding 47,500 common shares or options under grant EQ-0006. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
