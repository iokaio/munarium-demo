---
document_id: NG-DD-0077
category: 02_equity
title: Warrant Register — Item 35
document_date: 2020-08-31
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 35

## Capital record
Record date: 2020-08-31. Common shares shown as issued and outstanding: 8,000,000. Authorized common shares: 12,000,000.

## Holder detail
Caleb Stone is recorded as holding 83,750 common shares or options under grant EQ-0035. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
