---
document_id: NG-DD-0073
category: 02_equity
title: Capitalization Schedule — Item 31
document_date: 2020-11-07
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 31

## Capital record
Record date: 2020-11-07. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Holder detail
Liam Walsh is recorded as holding 78,750 common shares or options under grant EQ-0031. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
