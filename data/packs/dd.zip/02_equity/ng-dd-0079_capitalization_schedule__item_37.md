---
document_id: NG-DD-0079
category: 02_equity
title: Capitalization Schedule — Item 37
document_date: 2020-07-28
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 37

## Capital record
Record date: 2020-07-28. Common shares shown as issued and outstanding: 8,050,000. Authorized common shares: 12,000,000.

## Holder detail
Marcus Bell is recorded as holding 86,250 common shares or options under grant EQ-0037. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
