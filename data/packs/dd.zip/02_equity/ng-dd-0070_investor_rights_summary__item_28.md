---
document_id: NG-DD-0070
category: 02_equity
title: Investor Rights Summary — Item 28
document_date: 2020-12-28
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Investor Rights Summary — Item 28

## Capital record
Record date: 2020-12-28. Common shares shown as issued and outstanding: 8,000,000. Authorized common shares: 12,000,000.

## Holder detail
Sofia Alvarez is recorded as holding 75,000 common shares or options under grant EQ-0028. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
