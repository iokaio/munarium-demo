---
document_id: NG-DD-0050
category: 02_equity
title: Option Grant Notice — Item 08
document_date: 2021-12-03
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 08

## Capital record
Record date: 2021-12-03. Common shares shown as issued and outstanding: 8,025,000. Authorized common shares: 12,000,000.

## Holder detail
Nadia Petrova is recorded as holding 50,000 common shares or options under grant EQ-0008. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
