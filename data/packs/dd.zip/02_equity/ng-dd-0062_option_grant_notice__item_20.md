---
document_id: NG-DD-0062
category: 02_equity
title: Option Grant Notice — Item 20
document_date: 2021-05-13
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 20

## Capital record
Record date: 2021-05-13. Common shares shown as issued and outstanding: 8,150,000. Authorized common shares: 12,000,000.

## Holder detail
Nadia Petrova is recorded as holding 65,000 common shares or options under grant EQ-0020. Exercise price: USD 1.00.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
