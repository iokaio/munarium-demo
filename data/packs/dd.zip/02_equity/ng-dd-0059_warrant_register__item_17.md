---
document_id: NG-DD-0059
category: 02_equity
title: Warrant Register — Item 17
document_date: 2021-07-03
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 17

## Capital record
Record date: 2021-07-03. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Unrecorded SAFE
A USD 750,000 post-money SAFE issued to Raven Ridge Ventures on November 18, 2022 converts immediately before a change of control at the greater of principal or the as-converted amount. The instrument is absent from the management capitalization table.
