---
document_id: NG-DD-0045
category: 02_equity
title: Stock Ledger Extract — Item 03
document_date: 2022-02-26
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 03

## Capital record
Record date: 2022-02-26. Common shares shown as issued and outstanding: 8,075,000. Authorized common shares: 12,000,000.

## Holder detail
Jonah Reed is recorded as holding 43,750 common shares or options under grant EQ-0003. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
