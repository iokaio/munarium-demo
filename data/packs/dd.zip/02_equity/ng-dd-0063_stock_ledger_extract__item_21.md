---
document_id: NG-DD-0063
category: 02_equity
title: Stock Ledger Extract — Item 21
document_date: 2021-04-26
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 21

## Capital record
Record date: 2021-04-26. Common shares shown as issued and outstanding: 8,000,000. Authorized common shares: 12,000,000.

## Holder detail
Evan Brooks is recorded as holding 66,250 common shares or options under grant EQ-0021. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
