---
document_id: NG-DD-0068
category: 02_equity
title: Option Grant Notice — Item 26
document_date: 2021-01-31
custodian: Elena Park
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Option Grant Notice — Item 26

## Capital record
Record date: 2021-01-31. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Priya Nair is recorded as holding 72,500 common shares or options under grant EQ-0026. Exercise price: USD 1.25.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
