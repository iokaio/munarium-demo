---
document_id: NG-DD-0071
category: 02_equity
title: Warrant Register — Item 29
document_date: 2020-12-11
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Warrant Register — Item 29

## Capital record
Record date: 2020-12-11. Common shares shown as issued and outstanding: 8,025,000. Authorized common shares: 12,000,000.

## Warrant discrepancy
Granite Bank holds a warrant for 180,000 common shares at USD 0.01 per share. The warrant expires in 2028 and accelerates on a sale. The stock ledger marks it cancelled, but no cancellation agreement is attached.
