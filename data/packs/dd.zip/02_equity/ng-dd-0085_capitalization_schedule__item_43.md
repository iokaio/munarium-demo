---
document_id: NG-DD-0085
category: 02_equity
title: Capitalization Schedule — Item 43
document_date: 2020-04-17
custodian: Jonah Reed
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Capitalization Schedule — Item 43

## Capital record
Record date: 2020-04-17. Common shares shown as issued and outstanding: 8,025,000. Authorized common shares: 12,000,000.

## Holder detail
Liam Walsh is recorded as holding 93,750 common shares or options under grant EQ-0043. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
