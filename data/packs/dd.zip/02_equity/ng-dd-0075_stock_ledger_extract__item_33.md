---
document_id: NG-DD-0075
category: 02_equity
title: Stock Ledger Extract — Item 33
document_date: 2020-10-04
custodian: Evan Brooks
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Stock Ledger Extract — Item 33

## Capital record
Record date: 2020-10-04. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Evan Brooks is recorded as holding 81,250 common shares or options under grant EQ-0033. Exercise price: USD 1.75.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
