---
document_id: NG-DD-0054
category: 02_equity
title: Convertible Instrument Review — Item 12
document_date: 2021-09-26
custodian: Amara Okafor
confidentiality: Confidential
target: Northgate Systems Ltd.
transaction: Proposed acquisition by Aster Peak Holdings, Inc.
synthetic: true
---

# Convertible Instrument Review — Item 12

## Capital record
Record date: 2021-09-26. Common shares shown as issued and outstanding: 8,125,000. Authorized common shares: 12,000,000.

## Holder detail
Elena Park is recorded as holding 55,000 common shares or options under grant EQ-0012. Exercise price: USD 1.50.

Change-of-control treatment is subject to the 2019 Equity Incentive Plan and any individual acceleration letter.
