# Nimbara Sync 4.1 — Release Notes

**Product:** Nimbara Sync
**Version:** 4.1
**Released:** 2024-12-30

## Fixed issues

- NB-1022: export scheduler truncates names containing accented characters (resolved)
- NB-1073: sandbox mode jobs hang after the nightly window (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
