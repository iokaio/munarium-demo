# Nimbara Portal 3.0 — Release Notes

**Product:** Nimbara Portal
**Version:** 3.0
**Released:** 2024-03-03

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Portal builds.
