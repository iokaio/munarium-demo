# Nimbara Vault 4.3 — Release Notes

**Product:** Nimbara Vault
**Version:** 4.3
**Released:** 2025-05-20

## Fixed issues

- NB-1007: audit log shows the previous day's data after midnight UTC (resolved)
- NB-1015: template library operations fail with a timeout (resolved)
- NB-1032: delta sync entries are duplicated in the activity view (resolved)
- NB-1058: usage reports loses its schedule after daylight-saving changes (resolved)
- NB-1078: usage reports returns stale results under load (resolved)
- NB-1098: mobile approvals entries are duplicated in the activity view (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
