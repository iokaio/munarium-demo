# Nimbara Vault 3.5 — Release Notes

**Product:** Nimbara Vault
**Version:** 3.5
**Released:** 2024-08-09

## Fixed issues

- NB-1028: digest emails settings reset after a restart (resolved)
- NB-1103: audit log rejects valid configuration files (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
