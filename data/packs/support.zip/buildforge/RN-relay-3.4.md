# Nimbara Relay 3.4 — Release Notes

**Product:** Nimbara Relay
**Version:** 3.4
**Released:** 2024-08-31

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Relay builds.
