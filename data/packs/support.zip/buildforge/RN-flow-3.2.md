# Nimbara Flow 3.2 — Release Notes

**Product:** Nimbara Flow
**Version:** 3.2
**Released:** 2024-05-29

## Fixed issues

- NB-1017: usage reports shows the previous day's data after midnight UTC (resolved)

## Notes

This release supersedes all earlier Nimbara Flow builds.
