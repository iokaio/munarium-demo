# Nimbara Relay 4.0 — Release Notes

**Product:** Nimbara Relay
**Version:** 4.0
**Released:** 2024-12-24

## Fixed issues

- NB-1069: template library silently drops records over 10 MB (resolved)

## Notes

This release supersedes all earlier Nimbara Relay builds.
