# Nimbara Relay 4.3 — Release Notes

**Product:** Nimbara Relay
**Version:** 4.3
**Released:** 2025-07-20

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Relay builds.
