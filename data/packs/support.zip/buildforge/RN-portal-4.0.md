# Nimbara Portal 4.0 — Release Notes

**Product:** Nimbara Portal
**Version:** 4.0
**Released:** 2025-01-09

## Fixed issues

- NB-1097: access reviews loses its schedule after daylight-saving changes (resolved)

## Notes

This release supersedes all earlier Nimbara Portal builds.
