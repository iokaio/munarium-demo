# Nimbara Flow 4.2 — Release Notes

**Product:** Nimbara Flow
**Version:** 4.2
**Released:** 2025-03-24

## Fixed issues

- NB-1018: access reviews truncates names containing accented characters (resolved)
- NB-1037: template library truncates names containing accented characters (resolved)
- NB-1038: usage reports sends repeated notifications for one event (resolved)
- NB-1094: usage reports truncates names containing accented characters (resolved)
- NB-1119: API tokens returns stale results under load (resolved)

## Notes

This release supersedes all earlier Nimbara Flow builds.
