# Nimbara Flow 3.4 — Release Notes

**Product:** Nimbara Flow
**Version:** 3.4
**Released:** 2024-07-06

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Flow builds.
