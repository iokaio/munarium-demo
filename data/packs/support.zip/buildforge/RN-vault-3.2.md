# Nimbara Vault 3.2 — Release Notes

**Product:** Nimbara Vault
**Version:** 3.2
**Released:** 2024-05-12

## Fixed issues

- NB-1046: audit log shows the previous day's data after midnight UTC (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
