# Nimbara Insight 4.2.1 — Release Notes

**Product:** Nimbara Insight
**Version:** 4.2.1
**Released:** 2025-05-04

## Fixed issues

- NB-1082: export scheduler rejects valid configuration files (resolved)
- NB-1091: access reviews entries are duplicated in the activity view (resolved)
- NB-1105: usage reports settings reset after a restart (resolved)

## Notes

This release supersedes all earlier Nimbara Insight builds.
