# Nimbara Portal 4.1 — Release Notes

**Product:** Nimbara Portal
**Version:** 4.1
**Released:** 2025-03-21

## Fixed issues

- NB-1003: access reviews settings reset after a restart (resolved)
- NB-1061: delta sync jobs hang after the nightly window (resolved)

## Notes

This release supersedes all earlier Nimbara Portal builds.
