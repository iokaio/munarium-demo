# Nimbara Relay 3.2 — Release Notes

**Product:** Nimbara Relay
**Version:** 3.2
**Released:** 2024-07-04

## Fixed issues

- NB-1012: bulk import truncates names containing accented characters (resolved)

## Notes

This release supersedes all earlier Nimbara Relay builds.
