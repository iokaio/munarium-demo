# Nimbara Portal 3.1 — Release Notes

**Product:** Nimbara Portal
**Version:** 3.1
**Released:** 2024-05-09

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Portal builds.
