# Nimbara Relay 3.0 — Release Notes

**Product:** Nimbara Relay
**Version:** 3.0
**Released:** 2024-02-21

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Relay builds.
