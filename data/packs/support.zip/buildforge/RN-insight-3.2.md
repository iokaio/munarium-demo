# Nimbara Insight 3.2 — Release Notes

**Product:** Nimbara Insight
**Version:** 3.2
**Released:** 2024-06-10

## Fixed issues

- NB-1084: custom dashboards sends repeated notifications for one event (resolved)

## Notes

This release supersedes all earlier Nimbara Insight builds.
