# Nimbara Relay 4.1 — Release Notes

**Product:** Nimbara Relay
**Version:** 4.1
**Released:** 2025-02-28

## Fixed issues

- NB-1025: bulk import truncates names containing accented characters (resolved)

## Notes

This release supersedes all earlier Nimbara Relay builds.
