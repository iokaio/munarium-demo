# Nimbara Portal 3.4 — Release Notes

**Product:** Nimbara Portal
**Version:** 3.4
**Released:** 2024-08-30

## Fixed issues

- NB-1057: workspace themes rejects valid configuration files (resolved)

## Notes

This release supersedes all earlier Nimbara Portal builds.
