# Nimbara Sync 3.0 — Release Notes

**Product:** Nimbara Sync
**Version:** 3.0
**Released:** 2024-01-08

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Sync builds.
