# Nimbara Sync 3.2 — Release Notes

**Product:** Nimbara Sync
**Version:** 3.2
**Released:** 2024-05-11

## Fixed issues

- NB-1060: workspace themes returns stale results under load (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
