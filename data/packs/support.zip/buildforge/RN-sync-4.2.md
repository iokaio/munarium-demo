# Nimbara Sync 4.2 — Release Notes

**Product:** Nimbara Sync
**Version:** 4.2
**Released:** 2025-02-26

## Fixed issues

- NB-1001: digest emails jobs hang after the nightly window (resolved)
- NB-1062: API tokens loses its schedule after daylight-saving changes (resolved)
- NB-1093: API tokens sends repeated notifications for one event (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
