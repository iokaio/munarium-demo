# Nimbara Flow 3.5 — Release Notes

**Product:** Nimbara Flow
**Version:** 3.5
**Released:** 2024-09-15

## Fixed issues

- NB-1045: webhook triggers returns stale results under load (resolved)
- NB-1110: template library silently drops records over 10 MB (resolved)

## Notes

This release supersedes all earlier Nimbara Flow builds.
