# Nimbara Sync 4.0 — Release Notes

**Product:** Nimbara Sync
**Version:** 4.0
**Released:** 2024-11-01

## Fixed issues

- NB-1033: bulk import settings reset after a restart (resolved)
- NB-1108: access reviews entries are duplicated in the activity view (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
