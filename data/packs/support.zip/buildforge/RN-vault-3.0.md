# Nimbara Vault 3.0 — Release Notes

**Product:** Nimbara Vault
**Version:** 3.0
**Released:** 2024-01-19

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Vault builds.
