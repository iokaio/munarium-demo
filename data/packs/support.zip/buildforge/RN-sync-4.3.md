# Nimbara Sync 4.3 — Release Notes

**Product:** Nimbara Sync
**Version:** 4.3
**Released:** 2025-06-10

## Fixed issues

- NB-1080: data residency rejects valid configuration files (resolved)
- NB-1115: SSO login settings reset after a restart (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
