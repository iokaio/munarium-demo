# Nimbara Insight 4.3 — Release Notes

**Product:** Nimbara Insight
**Version:** 4.3
**Released:** 2025-06-19

## Fixed issues

- NB-1075: access reviews returns stale results under load (resolved)
- NB-1092: sandbox mode operations fail with a timeout (resolved)

## Notes

This release supersedes all earlier Nimbara Insight builds.
