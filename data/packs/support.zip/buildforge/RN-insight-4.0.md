# Nimbara Insight 4.0 — Release Notes

**Product:** Nimbara Insight
**Version:** 4.0
**Released:** 2024-11-10

## Fixed issues

- NB-1019: audit log settings reset after a restart (resolved)
- NB-1055: audit log operations fail with a timeout (resolved)
- NB-1056: workspace themes sends repeated notifications for one event (resolved)
- NB-1089: event streams operations fail with a timeout (resolved)

## Notes

This release supersedes all earlier Nimbara Insight builds.
