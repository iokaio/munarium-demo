# Nimbara Vault 4.2.1 — Release Notes

**Product:** Nimbara Vault
**Version:** 4.2.1
**Released:** 2025-03-02

## Fixed issues

- NB-1079: audit log silently drops records over 10 MB (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
