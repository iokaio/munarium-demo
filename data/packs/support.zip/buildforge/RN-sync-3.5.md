# Nimbara Sync 3.5 — Release Notes

**Product:** Nimbara Sync
**Version:** 3.5
**Released:** 2024-09-17

## Fixed issues

- NB-1008: data residency entries are duplicated in the activity view (resolved)
- NB-1024: API tokens stops responding when a workspace is renamed (resolved)
- NB-1050: data residency rejects valid configuration files (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
