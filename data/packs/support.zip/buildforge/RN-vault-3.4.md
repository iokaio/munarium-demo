# Nimbara Vault 3.4 — Release Notes

**Product:** Nimbara Vault
**Version:** 3.4
**Released:** 2024-06-18

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Vault builds.
