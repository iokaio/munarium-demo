# Nimbara Relay 3.5 — Release Notes

**Product:** Nimbara Relay
**Version:** 3.5
**Released:** 2024-11-04

## Fixed issues

- NB-1016: alert rules sends repeated notifications for one event (resolved)
- NB-1113: custom fields returns stale results under load (resolved)

## Notes

This release supersedes all earlier Nimbara Relay builds.
