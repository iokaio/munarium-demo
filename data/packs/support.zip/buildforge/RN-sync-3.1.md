# Nimbara Sync 3.1 — Release Notes

**Product:** Nimbara Sync
**Version:** 3.1
**Released:** 2024-03-02

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Sync builds.
