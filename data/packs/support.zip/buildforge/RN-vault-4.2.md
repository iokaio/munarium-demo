# Nimbara Vault 4.2 — Release Notes

**Product:** Nimbara Vault
**Version:** 4.2
**Released:** 2025-01-04

## Fixed issues

- NB-1002: template library loses its schedule after daylight-saving changes (resolved)
- NB-1014: export scheduler stops responding when a workspace is renamed (resolved)
- NB-1043: export scheduler stops responding when a workspace is renamed (resolved)
- NB-1070: mobile approvals sends repeated notifications for one event (resolved)
- NB-1085: usage reports rejects valid configuration files (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
