# Nimbara Flow 4.0 — Release Notes

**Product:** Nimbara Flow
**Version:** 4.0
**Released:** 2024-12-02

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Flow builds.
