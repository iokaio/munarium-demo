# Nimbara Portal 4.3 — Release Notes

**Product:** Nimbara Portal
**Version:** 4.3
**Released:** 2025-09-14

## Fixed issues

- NB-1039: audit log operations fail with a timeout (resolved)

## Notes

This release supersedes all earlier Nimbara Portal builds.
