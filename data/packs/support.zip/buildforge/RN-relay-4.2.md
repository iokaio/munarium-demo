# Nimbara Relay 4.2 — Release Notes

**Product:** Nimbara Relay
**Version:** 4.2
**Released:** 2025-04-13

## Fixed issues

- NB-1034: digest emails settings reset after a restart (resolved)
- NB-1104: backup restore settings reset after a restart (resolved)

## Notes

This release supersedes all earlier Nimbara Relay builds.
