# Nimbara Insight 3.0 — Release Notes

**Product:** Nimbara Insight
**Version:** 3.0
**Released:** 2024-02-10

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Insight builds.
