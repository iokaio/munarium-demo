# Nimbara Portal 4.2 — Release Notes

**Product:** Nimbara Portal
**Version:** 4.2
**Released:** 2025-05-23

## Fixed issues

- NB-1044: digest emails shows the previous day's data after midnight UTC (resolved)
- NB-1048: mobile approvals entries are duplicated in the activity view (resolved)
- NB-1076: digest emails shows the previous day's data after midnight UTC (resolved)

## Notes

This release supersedes all earlier Nimbara Portal builds.
