# Nimbara Insight 4.1 — Release Notes

**Product:** Nimbara Insight
**Version:** 4.1
**Released:** 2025-01-10

## Fixed issues

- NB-1090: workspace themes entries are duplicated in the activity view (resolved)
- NB-1096: audit log entries are duplicated in the activity view (resolved)

## Notes

This release supersedes all earlier Nimbara Insight builds.
