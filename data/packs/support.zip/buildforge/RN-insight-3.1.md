# Nimbara Insight 3.1 — Release Notes

**Product:** Nimbara Insight
**Version:** 3.1
**Released:** 2024-03-23

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Insight builds.
