# Nimbara Sync 3.4 — Release Notes

**Product:** Nimbara Sync
**Version:** 3.4
**Released:** 2024-07-24

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Sync builds.
