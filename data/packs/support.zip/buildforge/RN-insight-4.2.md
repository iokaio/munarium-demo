# Nimbara Insight 4.2 — Release Notes

**Product:** Nimbara Insight
**Version:** 4.2
**Released:** 2025-03-27

## Fixed issues

- NB-1042: audit log loses its schedule after daylight-saving changes (resolved)
- NB-1086: workspace themes shows the previous day's data after midnight UTC (resolved)

## Notes

This release supersedes all earlier Nimbara Insight builds.
