# Nimbara Vault 4.1 — Release Notes

**Product:** Nimbara Vault
**Version:** 4.1
**Released:** 2024-11-25

## Fixed issues

- NB-1054: usage reports operations fail with a timeout (resolved)
- NB-1059: template library shows the previous day's data after midnight UTC (resolved)
- NB-1100: webhook triggers stops responding when a workspace is renamed (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
