# Nimbara Relay 4.2.1 — Release Notes

**Product:** Nimbara Relay
**Version:** 4.2.1
**Released:** 2025-05-29

## Fixed issues

- NB-1074: guest sharing rejects valid configuration files (resolved)
- NB-1114: guest sharing stops responding when a workspace is renamed (resolved)

## Notes

This release supersedes all earlier Nimbara Relay builds.
