# Nimbara Portal 3.2 — Release Notes

**Product:** Nimbara Portal
**Version:** 3.2
**Released:** 2024-06-29

## Fixed issues

- NB-1116: audit log stops responding when a workspace is renamed (resolved)

## Notes

This release supersedes all earlier Nimbara Portal builds.
