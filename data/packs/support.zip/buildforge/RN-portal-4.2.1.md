# Nimbara Portal 4.2.1 — Release Notes

**Product:** Nimbara Portal
**Version:** 4.2.1
**Released:** 2025-07-11

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Portal builds.
