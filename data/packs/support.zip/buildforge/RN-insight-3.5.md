# Nimbara Insight 3.5 — Release Notes

**Product:** Nimbara Insight
**Version:** 3.5
**Released:** 2024-09-20

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Insight builds.
