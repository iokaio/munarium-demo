# Nimbara Sync 4.2.1 — Release Notes

**Product:** Nimbara Sync
**Version:** 4.2.1
**Released:** 2025-04-10

## Fixed issues

- NB-1013: digest emails returns stale results under load (resolved)
- NB-1026: saved filters rejects valid configuration files (resolved)
- NB-1067: bulk import truncates names containing accented characters (resolved)
- NB-1071: workspace themes returns stale results under load (resolved)
- NB-1072: API tokens stops responding when a workspace is renamed (resolved)
- NB-1107: workspace themes loses its schedule after daylight-saving changes (resolved)

## Notes

This release supersedes all earlier Nimbara Sync builds.
