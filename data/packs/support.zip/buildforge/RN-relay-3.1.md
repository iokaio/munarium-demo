# Nimbara Relay 3.1 — Release Notes

**Product:** Nimbara Relay
**Version:** 3.1
**Released:** 2024-04-22

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Relay builds.
