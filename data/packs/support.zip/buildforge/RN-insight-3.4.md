# Nimbara Insight 3.4 — Release Notes

**Product:** Nimbara Insight
**Version:** 3.4
**Released:** 2024-07-18

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Insight builds.
