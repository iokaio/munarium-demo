# Nimbara Portal 3.5 — Release Notes

**Product:** Nimbara Portal
**Version:** 3.5
**Released:** 2024-10-30

## Fixed issues

- No customer-reported defects were closed in this release.

## Notes

This release supersedes all earlier Nimbara Portal builds.
