# Nimbara Vault 3.1 — Release Notes

**Product:** Nimbara Vault
**Version:** 3.1
**Released:** 2024-04-05

## Fixed issues

- NB-1021: export scheduler shows the previous day's data after midnight UTC (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
