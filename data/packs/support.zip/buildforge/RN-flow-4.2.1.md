# Nimbara Flow 4.2.1 — Release Notes

**Product:** Nimbara Flow
**Version:** 4.2.1
**Released:** 2025-05-06

## Fixed issues

- NB-1005: custom fields entries are duplicated in the activity view (resolved)
- NB-1023: usage reports silently drops records over 10 MB (resolved)

## Notes

This release supersedes all earlier Nimbara Flow builds.
