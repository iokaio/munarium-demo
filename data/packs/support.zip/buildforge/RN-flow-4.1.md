# Nimbara Flow 4.1 — Release Notes

**Product:** Nimbara Flow
**Version:** 4.1
**Released:** 2025-01-13

## Fixed issues

- NB-1087: webhook triggers silently drops records over 10 MB (resolved)

## Notes

This release supersedes all earlier Nimbara Flow builds.
