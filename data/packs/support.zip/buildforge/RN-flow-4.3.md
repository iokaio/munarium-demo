# Nimbara Flow 4.3 — Release Notes

**Product:** Nimbara Flow
**Version:** 4.3
**Released:** 2025-07-15

## Fixed issues

- NB-1011: webhook triggers sends repeated notifications for one event (resolved)
- NB-1047: access reviews loses its schedule after daylight-saving changes (resolved)
- NB-1051: webhook triggers sends repeated notifications for one event (resolved)
- NB-1095: usage reports settings reset after a restart (resolved)
- NB-1118: data residency rejects valid configuration files (resolved)

## Notes

This release supersedes all earlier Nimbara Flow builds.
