# Nimbara Vault 4.0 — Release Notes

**Product:** Nimbara Vault
**Version:** 4.0
**Released:** 2024-10-05

## Fixed issues

- NB-1010: audit log shows the previous day's data after midnight UTC (resolved)

## Notes

This release supersedes all earlier Nimbara Vault builds.
